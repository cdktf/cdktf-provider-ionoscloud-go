/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudInmemorydbReplicasetConfig extends cdktf.TerraformMetaArguments {
    /**
    * The display name of the InMemoryDB Replicaset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#display_name DataIonoscloudInmemorydbReplicaset#display_name}
    */
    readonly displayName?: string;
    /**
    * The ID of the InMemoryDB Replicaset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#id DataIonoscloudInmemorydbReplicaset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The replica set location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#location DataIonoscloudInmemorydbReplicaset#location}
    */
    readonly location?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#timeouts DataIonoscloudInmemorydbReplicaset#timeouts}
    */
    readonly timeouts?: DataIonoscloudInmemorydbReplicasetTimeouts;
}
export interface DataIonoscloudInmemorydbReplicasetConnections {
}
export declare function dataIonoscloudInmemorydbReplicasetConnectionsToTerraform(struct?: DataIonoscloudInmemorydbReplicasetConnections): any;
export declare function dataIonoscloudInmemorydbReplicasetConnectionsToHclTerraform(struct?: DataIonoscloudInmemorydbReplicasetConnections): any;
export declare class DataIonoscloudInmemorydbReplicasetConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudInmemorydbReplicasetConnections | undefined;
    set internalValue(value: DataIonoscloudInmemorydbReplicasetConnections | undefined);
    get cidr(): string;
    get datacenterId(): string;
    get lanId(): string;
}
export declare class DataIonoscloudInmemorydbReplicasetConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudInmemorydbReplicasetConnectionsOutputReference;
}
export interface DataIonoscloudInmemorydbReplicasetCredentials {
}
export declare function dataIonoscloudInmemorydbReplicasetCredentialsToTerraform(struct?: DataIonoscloudInmemorydbReplicasetCredentials): any;
export declare function dataIonoscloudInmemorydbReplicasetCredentialsToHclTerraform(struct?: DataIonoscloudInmemorydbReplicasetCredentials): any;
export declare class DataIonoscloudInmemorydbReplicasetCredentialsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudInmemorydbReplicasetCredentials | undefined;
    set internalValue(value: DataIonoscloudInmemorydbReplicasetCredentials | undefined);
    get username(): string;
}
export declare class DataIonoscloudInmemorydbReplicasetCredentialsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudInmemorydbReplicasetCredentialsOutputReference;
}
export interface DataIonoscloudInmemorydbReplicasetMaintenanceWindow {
}
export declare function dataIonoscloudInmemorydbReplicasetMaintenanceWindowToTerraform(struct?: DataIonoscloudInmemorydbReplicasetMaintenanceWindow): any;
export declare function dataIonoscloudInmemorydbReplicasetMaintenanceWindowToHclTerraform(struct?: DataIonoscloudInmemorydbReplicasetMaintenanceWindow): any;
export declare class DataIonoscloudInmemorydbReplicasetMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudInmemorydbReplicasetMaintenanceWindow | undefined;
    set internalValue(value: DataIonoscloudInmemorydbReplicasetMaintenanceWindow | undefined);
    get dayOfTheWeek(): string;
    get time(): string;
}
export declare class DataIonoscloudInmemorydbReplicasetMaintenanceWindowList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudInmemorydbReplicasetMaintenanceWindowOutputReference;
}
export interface DataIonoscloudInmemorydbReplicasetResources {
}
export declare function dataIonoscloudInmemorydbReplicasetResourcesToTerraform(struct?: DataIonoscloudInmemorydbReplicasetResources): any;
export declare function dataIonoscloudInmemorydbReplicasetResourcesToHclTerraform(struct?: DataIonoscloudInmemorydbReplicasetResources): any;
export declare class DataIonoscloudInmemorydbReplicasetResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudInmemorydbReplicasetResources | undefined;
    set internalValue(value: DataIonoscloudInmemorydbReplicasetResources | undefined);
    get cores(): number;
    get ram(): number;
    get storage(): number;
}
export declare class DataIonoscloudInmemorydbReplicasetResourcesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudInmemorydbReplicasetResourcesOutputReference;
}
export interface DataIonoscloudInmemorydbReplicasetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#create DataIonoscloudInmemorydbReplicaset#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#default DataIonoscloudInmemorydbReplicaset#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#delete DataIonoscloudInmemorydbReplicaset#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#update DataIonoscloudInmemorydbReplicaset#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudInmemorydbReplicasetTimeoutsToTerraform(struct?: DataIonoscloudInmemorydbReplicasetTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudInmemorydbReplicasetTimeoutsToHclTerraform(struct?: DataIonoscloudInmemorydbReplicasetTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudInmemorydbReplicasetTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudInmemorydbReplicasetTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudInmemorydbReplicasetTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset ionoscloud_inmemorydb_replicaset}
*/
export declare class DataIonoscloudInmemorydbReplicaset extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_inmemorydb_replicaset";
    /**
    * Generates CDKTF code for importing a DataIonoscloudInmemorydbReplicaset resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudInmemorydbReplicaset to import
    * @param importFromId The id of the existing DataIonoscloudInmemorydbReplicaset that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudInmemorydbReplicaset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_replicaset ionoscloud_inmemorydb_replicaset} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudInmemorydbReplicasetConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudInmemorydbReplicasetConfig);
    private _connections;
    get connections(): DataIonoscloudInmemorydbReplicasetConnectionsList;
    private _credentials;
    get credentials(): DataIonoscloudInmemorydbReplicasetCredentialsList;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get dnsName(): string;
    get evictionPolicy(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataIonoscloudInmemorydbReplicasetMaintenanceWindowList;
    get persistenceMode(): string;
    get replicas(): number;
    private _resources;
    get resources(): DataIonoscloudInmemorydbReplicasetResourcesList;
    get version(): string;
    private _timeouts;
    get timeouts(): DataIonoscloudInmemorydbReplicasetTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudInmemorydbReplicasetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudInmemorydbReplicasetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
