/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudApigatewayConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID (UUID) of the API Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway#id DataIonoscloudApigateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the API Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway#name DataIonoscloudApigateway#name}
    */
    readonly name?: string;
    /**
    * Whether partial matching is allowed or not when using the name filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway#partial_match DataIonoscloudApigateway#partial_match}
    */
    readonly partialMatch?: boolean | cdktf.IResolvable;
}
export interface DataIonoscloudApigatewayCustomDomains {
}
export declare function dataIonoscloudApigatewayCustomDomainsToTerraform(struct?: DataIonoscloudApigatewayCustomDomains): any;
export declare function dataIonoscloudApigatewayCustomDomainsToHclTerraform(struct?: DataIonoscloudApigatewayCustomDomains): any;
export declare class DataIonoscloudApigatewayCustomDomainsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudApigatewayCustomDomains | undefined;
    set internalValue(value: DataIonoscloudApigatewayCustomDomains | undefined);
    get certificateId(): string;
    get name(): string;
}
export declare class DataIonoscloudApigatewayCustomDomainsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudApigatewayCustomDomainsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway ionoscloud_apigateway}
*/
export declare class DataIonoscloudApigateway extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_apigateway";
    /**
    * Generates CDKTF code for importing a DataIonoscloudApigateway resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudApigateway to import
    * @param importFromId The id of the existing DataIonoscloudApigateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudApigateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway ionoscloud_apigateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudApigatewayConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudApigatewayConfig);
    private _customDomains;
    get customDomains(): DataIonoscloudApigatewayCustomDomainsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get logs(): cdktf.IResolvable;
    get metrics(): cdktf.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _partialMatch?;
    get partialMatch(): boolean | cdktf.IResolvable;
    set partialMatch(value: boolean | cdktf.IResolvable);
    resetPartialMatch(): void;
    get partialMatchInput(): boolean | cdktf.IResolvable | undefined;
    get publicEndpoint(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
