/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApigatewayConfig extends cdktf.TerraformMetaArguments {
    /**
    * Enable or disable logging. NOTE: Central Logging must be enabled through the Logging API to enable this feature.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#logs Apigateway#logs}
    */
    readonly logs?: boolean | cdktf.IResolvable;
    /**
    * Enable or disable metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#metrics Apigateway#metrics}
    */
    readonly metrics?: boolean | cdktf.IResolvable;
    /**
    * The name of the API Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#name Apigateway#name}
    */
    readonly name: string;
    /**
    * custom_domains block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#custom_domains Apigateway#custom_domains}
    */
    readonly customDomains?: ApigatewayCustomDomains[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#timeouts Apigateway#timeouts}
    */
    readonly timeouts?: ApigatewayTimeouts;
}
export interface ApigatewayCustomDomains {
    /**
    * The certificate ID for the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#certificate_id Apigateway#certificate_id}
    */
    readonly certificateId?: string;
    /**
    * The domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#name Apigateway#name}
    */
    readonly name: string;
}
export declare function apigatewayCustomDomainsToTerraform(struct?: ApigatewayCustomDomains | cdktf.IResolvable): any;
export declare function apigatewayCustomDomainsToHclTerraform(struct?: ApigatewayCustomDomains | cdktf.IResolvable): any;
export declare class ApigatewayCustomDomainsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayCustomDomains | cdktf.IResolvable | undefined;
    set internalValue(value: ApigatewayCustomDomains | cdktf.IResolvable | undefined);
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    resetCertificateId(): void;
    get certificateIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ApigatewayCustomDomainsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigatewayCustomDomains[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayCustomDomainsOutputReference;
}
export interface ApigatewayTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#create Apigateway#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#default Apigateway#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#delete Apigateway#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#update Apigateway#update}
    */
    readonly update?: string;
}
export declare function apigatewayTimeoutsToTerraform(struct?: ApigatewayTimeouts | cdktf.IResolvable): any;
export declare function apigatewayTimeoutsToHclTerraform(struct?: ApigatewayTimeouts | cdktf.IResolvable): any;
export declare class ApigatewayTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ApigatewayTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway ionoscloud_apigateway}
*/
export declare class Apigateway extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_apigateway";
    /**
    * Generates CDKTF code for importing a Apigateway resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Apigateway to import
    * @param importFromId The id of the existing Apigateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Apigateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway ionoscloud_apigateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayConfig
    */
    constructor(scope: Construct, id: string, config: ApigatewayConfig);
    get id(): string;
    private _logs?;
    get logs(): boolean | cdktf.IResolvable;
    set logs(value: boolean | cdktf.IResolvable);
    resetLogs(): void;
    get logsInput(): boolean | cdktf.IResolvable | undefined;
    private _metrics?;
    get metrics(): boolean | cdktf.IResolvable;
    set metrics(value: boolean | cdktf.IResolvable);
    resetMetrics(): void;
    get metricsInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicEndpoint(): string;
    private _customDomains;
    get customDomains(): ApigatewayCustomDomainsList;
    putCustomDomains(value: ApigatewayCustomDomains[] | cdktf.IResolvable): void;
    resetCustomDomains(): void;
    get customDomainsInput(): cdktf.IResolvable | ApigatewayCustomDomains[] | undefined;
    private _timeouts;
    get timeouts(): ApigatewayTimeoutsOutputReference;
    putTimeouts(value: ApigatewayTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ApigatewayTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
