/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IonoscloudProviderConfig {
    /**
    * To be set only for reseller accounts. Allows to run terraform on a contract number under a reseller account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#contract_number IonoscloudProvider#contract_number}
    */
    readonly contractNumber?: string;
    /**
    * IonosCloud REST API URL. Usually not necessary to be set, SDKs know internally how to route requests to the API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#endpoint IonoscloudProvider#endpoint}
    */
    readonly endpoint?: string;
    /**
    * This field is to be set only for testing purposes. It is not recommended to set this field in production environments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#insecure IonoscloudProvider#insecure}
    */
    readonly insecure?: boolean | cdktf.IResolvable;
    /**
    * IonosCloud password for API operations. If token is provided, token is preferred
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#password IonoscloudProvider#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#retries IonoscloudProvider#retries}
    */
    readonly retries?: number;
    /**
    * Access key for IONOS Object Storage operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#s3_access_key IonoscloudProvider#s3_access_key}
    */
    readonly s3AccessKey?: string;
    /**
    * Region for IONOS Object Storage operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#s3_region IonoscloudProvider#s3_region}
    */
    readonly s3Region?: string;
    /**
    * Secret key for IONOS Object Storage operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#s3_secret_key IonoscloudProvider#s3_secret_key}
    */
    readonly s3SecretKey?: string;
    /**
    * IonosCloud bearer token for API operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#token IonoscloudProvider#token}
    */
    readonly token?: string;
    /**
    * IonosCloud username for API operations. If token is provided, token is preferred
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#username IonoscloudProvider#username}
    */
    readonly username?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#alias IonoscloudProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs ionoscloud}
*/
export declare class IonoscloudProvider extends cdktf.TerraformProvider {
    static readonly tfResourceType = "ionoscloud";
    /**
    * Generates CDKTF code for importing a IonoscloudProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IonoscloudProvider to import
    * @param importFromId The id of the existing IonoscloudProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IonoscloudProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs ionoscloud} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IonoscloudProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: IonoscloudProviderConfig);
    private _contractNumber?;
    get contractNumber(): string | undefined;
    set contractNumber(value: string | undefined);
    resetContractNumber(): void;
    get contractNumberInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string | undefined;
    set endpoint(value: string | undefined);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _insecure?;
    get insecure(): boolean | cdktf.IResolvable | undefined;
    set insecure(value: boolean | cdktf.IResolvable | undefined);
    resetInsecure(): void;
    get insecureInput(): boolean | cdktf.IResolvable | undefined;
    private _password?;
    get password(): string | undefined;
    set password(value: string | undefined);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _retries?;
    get retries(): number | undefined;
    set retries(value: number | undefined);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _s3AccessKey?;
    get s3AccessKey(): string | undefined;
    set s3AccessKey(value: string | undefined);
    resetS3AccessKey(): void;
    get s3AccessKeyInput(): string | undefined;
    private _s3Region?;
    get s3Region(): string | undefined;
    set s3Region(value: string | undefined);
    resetS3Region(): void;
    get s3RegionInput(): string | undefined;
    private _s3SecretKey?;
    get s3SecretKey(): string | undefined;
    set s3SecretKey(value: string | undefined);
    resetS3SecretKey(): void;
    get s3SecretKeyInput(): string | undefined;
    private _token?;
    get token(): string | undefined;
    set token(value: string | undefined);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _username?;
    get username(): string | undefined;
    set username(value: string | undefined);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
