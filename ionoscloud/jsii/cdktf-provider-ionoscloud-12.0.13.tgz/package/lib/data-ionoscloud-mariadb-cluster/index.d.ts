/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudMariadbClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The friendly name of your cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_cluster#display_name DataIonoscloudMariadbCluster#display_name}
    */
    readonly displayName?: string;
    /**
    * The id of your cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_cluster#id DataIonoscloudMariadbCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The cluster location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_cluster#location DataIonoscloudMariadbCluster#location}
    */
    readonly location?: string;
}
export interface DataIonoscloudMariadbClusterBackup {
}
export declare function dataIonoscloudMariadbClusterBackupToTerraform(struct?: DataIonoscloudMariadbClusterBackup): any;
export declare function dataIonoscloudMariadbClusterBackupToHclTerraform(struct?: DataIonoscloudMariadbClusterBackup): any;
export declare class DataIonoscloudMariadbClusterBackupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudMariadbClusterBackup | undefined;
    set internalValue(value: DataIonoscloudMariadbClusterBackup | undefined);
    get location(): string;
}
export declare class DataIonoscloudMariadbClusterBackupList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudMariadbClusterBackupOutputReference;
}
export interface DataIonoscloudMariadbClusterConnections {
}
export declare function dataIonoscloudMariadbClusterConnectionsToTerraform(struct?: DataIonoscloudMariadbClusterConnections): any;
export declare function dataIonoscloudMariadbClusterConnectionsToHclTerraform(struct?: DataIonoscloudMariadbClusterConnections): any;
export declare class DataIonoscloudMariadbClusterConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudMariadbClusterConnections | undefined;
    set internalValue(value: DataIonoscloudMariadbClusterConnections | undefined);
    get cidr(): string;
    get datacenterId(): string;
    get lanId(): string;
}
export declare class DataIonoscloudMariadbClusterConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudMariadbClusterConnectionsOutputReference;
}
export interface DataIonoscloudMariadbClusterMaintenanceWindow {
}
export declare function dataIonoscloudMariadbClusterMaintenanceWindowToTerraform(struct?: DataIonoscloudMariadbClusterMaintenanceWindow): any;
export declare function dataIonoscloudMariadbClusterMaintenanceWindowToHclTerraform(struct?: DataIonoscloudMariadbClusterMaintenanceWindow): any;
export declare class DataIonoscloudMariadbClusterMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudMariadbClusterMaintenanceWindow | undefined;
    set internalValue(value: DataIonoscloudMariadbClusterMaintenanceWindow | undefined);
    get dayOfTheWeek(): string;
    get time(): string;
}
export declare class DataIonoscloudMariadbClusterMaintenanceWindowList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudMariadbClusterMaintenanceWindowOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_cluster ionoscloud_mariadb_cluster}
*/
export declare class DataIonoscloudMariadbCluster extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_mariadb_cluster";
    /**
    * Generates CDKTF code for importing a DataIonoscloudMariadbCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudMariadbCluster to import
    * @param importFromId The id of the existing DataIonoscloudMariadbCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudMariadbCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_cluster ionoscloud_mariadb_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudMariadbClusterConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudMariadbClusterConfig);
    private _backup;
    get backup(): DataIonoscloudMariadbClusterBackupList;
    private _connections;
    get connections(): DataIonoscloudMariadbClusterConnectionsList;
    get cores(): number;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get dnsName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instances(): number;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataIonoscloudMariadbClusterMaintenanceWindowList;
    get mariadbVersion(): string;
    get ram(): number;
    get storageSize(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
