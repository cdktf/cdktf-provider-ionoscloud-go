/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpnWireguardGatewayConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#description VpnWireguardGateway#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#gateway_ip VpnWireguardGateway#gateway_ip}
    */
    readonly gatewayIp: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#id VpnWireguardGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The IPV4 address (with CIDR mask) to be assigned to the WireGuard interface.
    * 							 __Note__: either interfaceIPv4CIDR or interfaceIPv6CIDR is __required__.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#interface_ipv4_cidr VpnWireguardGateway#interface_ipv4_cidr}
    */
    readonly interfaceIpv4Cidr?: string;
    /**
    * The IPV6 address (with CIDR mask) to be assigned to the WireGuard interface.
    * 							 __Note__: either interfaceIPv6CIDR or interfaceIPv4CIDR is __required__.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#interface_ipv6_cidr VpnWireguardGateway#interface_ipv6_cidr}
    */
    readonly interfaceIpv6Cidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#listen_port VpnWireguardGateway#listen_port}
    */
    readonly listenPort?: number;
    /**
    * The location of the WireGuard Gateway. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/bhx, gb/lhr, us/ewr, us/las, us/mci, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#location VpnWireguardGateway#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#name VpnWireguardGateway#name}
    */
    readonly name: string;
    /**
    * PrivateKey used for WireGuard Server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#private_key VpnWireguardGateway#private_key}
    */
    readonly privateKey: string;
    /**
    * Gateway performance options. See the documentation for the available options
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#tier VpnWireguardGateway#tier}
    */
    readonly tier?: string;
    /**
    * connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#connections VpnWireguardGateway#connections}
    */
    readonly connections: VpnWireguardGatewayConnections[] | cdktf.IResolvable;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#maintenance_window VpnWireguardGateway#maintenance_window}
    */
    readonly maintenanceWindow?: VpnWireguardGatewayMaintenanceWindow;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#timeouts VpnWireguardGateway#timeouts}
    */
    readonly timeouts?: VpnWireguardGatewayTimeouts;
}
export interface VpnWireguardGatewayConnections {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#datacenter_id VpnWireguardGateway#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * A LAN IPv4 address in CIDR notation that will be assigned to the VPN Gateway. This will be the private gateway address for LAN clients to route traffic over the VPN Gateway, this should be within the subnet already assigned to the LAN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#ipv4_cidr VpnWireguardGateway#ipv4_cidr}
    */
    readonly ipv4Cidr?: string;
    /**
    * A LAN IPv6 address in CIDR notation that will be assigned to the VPN Gateway. This will be the private gateway address for LAN clients to route traffic over the VPN Gateway, this should be within the subnet already assigned to the LAN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#ipv6_cidr VpnWireguardGateway#ipv6_cidr}
    */
    readonly ipv6Cidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#lan_id VpnWireguardGateway#lan_id}
    */
    readonly lanId: string;
}
export declare function vpnWireguardGatewayConnectionsToTerraform(struct?: VpnWireguardGatewayConnections | cdktf.IResolvable): any;
export declare function vpnWireguardGatewayConnectionsToHclTerraform(struct?: VpnWireguardGatewayConnections | cdktf.IResolvable): any;
export declare class VpnWireguardGatewayConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpnWireguardGatewayConnections | cdktf.IResolvable | undefined;
    set internalValue(value: VpnWireguardGatewayConnections | cdktf.IResolvable | undefined);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _ipv4Cidr?;
    get ipv4Cidr(): string;
    set ipv4Cidr(value: string);
    resetIpv4Cidr(): void;
    get ipv4CidrInput(): string | undefined;
    private _ipv6Cidr?;
    get ipv6Cidr(): string;
    set ipv6Cidr(value: string);
    resetIpv6Cidr(): void;
    get ipv6CidrInput(): string | undefined;
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
}
export declare class VpnWireguardGatewayConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VpnWireguardGatewayConnections[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpnWireguardGatewayConnectionsOutputReference;
}
export interface VpnWireguardGatewayMaintenanceWindow {
    /**
    * The name of the week day
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#day_of_the_week VpnWireguardGateway#day_of_the_week}
    */
    readonly dayOfTheWeek: string;
    /**
    * Start of the maintenance window in UTC time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#time VpnWireguardGateway#time}
    */
    readonly time: string;
}
export declare function vpnWireguardGatewayMaintenanceWindowToTerraform(struct?: VpnWireguardGatewayMaintenanceWindowOutputReference | VpnWireguardGatewayMaintenanceWindow): any;
export declare function vpnWireguardGatewayMaintenanceWindowToHclTerraform(struct?: VpnWireguardGatewayMaintenanceWindowOutputReference | VpnWireguardGatewayMaintenanceWindow): any;
export declare class VpnWireguardGatewayMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnWireguardGatewayMaintenanceWindow | undefined;
    set internalValue(value: VpnWireguardGatewayMaintenanceWindow | undefined);
    private _dayOfTheWeek?;
    get dayOfTheWeek(): string;
    set dayOfTheWeek(value: string);
    get dayOfTheWeekInput(): string | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
}
export interface VpnWireguardGatewayTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#create VpnWireguardGateway#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#default VpnWireguardGateway#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#delete VpnWireguardGateway#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#update VpnWireguardGateway#update}
    */
    readonly update?: string;
}
export declare function vpnWireguardGatewayTimeoutsToTerraform(struct?: VpnWireguardGatewayTimeouts | cdktf.IResolvable): any;
export declare function vpnWireguardGatewayTimeoutsToHclTerraform(struct?: VpnWireguardGatewayTimeouts | cdktf.IResolvable): any;
export declare class VpnWireguardGatewayTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnWireguardGatewayTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VpnWireguardGatewayTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway ionoscloud_vpn_wireguard_gateway}
*/
export declare class VpnWireguardGateway extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_vpn_wireguard_gateway";
    /**
    * Generates CDKTF code for importing a VpnWireguardGateway resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpnWireguardGateway to import
    * @param importFromId The id of the existing VpnWireguardGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpnWireguardGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_gateway ionoscloud_vpn_wireguard_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpnWireguardGatewayConfig
    */
    constructor(scope: Construct, id: string, config: VpnWireguardGatewayConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _gatewayIp?;
    get gatewayIp(): string;
    set gatewayIp(value: string);
    get gatewayIpInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interfaceIpv4Cidr?;
    get interfaceIpv4Cidr(): string;
    set interfaceIpv4Cidr(value: string);
    resetInterfaceIpv4Cidr(): void;
    get interfaceIpv4CidrInput(): string | undefined;
    private _interfaceIpv6Cidr?;
    get interfaceIpv6Cidr(): string;
    set interfaceIpv6Cidr(value: string);
    resetInterfaceIpv6Cidr(): void;
    get interfaceIpv6CidrInput(): string | undefined;
    private _listenPort?;
    get listenPort(): number;
    set listenPort(value: number);
    resetListenPort(): void;
    get listenPortInput(): number | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    get publicKey(): string;
    get status(): string;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    private _connections;
    get connections(): VpnWireguardGatewayConnectionsList;
    putConnections(value: VpnWireguardGatewayConnections[] | cdktf.IResolvable): void;
    get connectionsInput(): cdktf.IResolvable | VpnWireguardGatewayConnections[] | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): VpnWireguardGatewayMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: VpnWireguardGatewayMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): VpnWireguardGatewayMaintenanceWindow | undefined;
    private _timeouts;
    get timeouts(): VpnWireguardGatewayTimeoutsOutputReference;
    putTimeouts(value: VpnWireguardGatewayTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VpnWireguardGatewayTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
