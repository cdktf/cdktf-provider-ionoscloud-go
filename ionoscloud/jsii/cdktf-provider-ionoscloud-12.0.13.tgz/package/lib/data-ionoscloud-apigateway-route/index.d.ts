/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudApigatewayRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the API Gateway that the route belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway_route#gateway_id DataIonoscloudApigatewayRoute#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * The ID (UUID) of the API Gateway Route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway_route#id DataIonoscloudApigatewayRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the API Gateway Route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway_route#name DataIonoscloudApigatewayRoute#name}
    */
    readonly name?: string;
    /**
    * Whether partial matching is allowed or not when using the name filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway_route#partial_match DataIonoscloudApigatewayRoute#partial_match}
    */
    readonly partialMatch?: boolean | cdktf.IResolvable;
}
export interface DataIonoscloudApigatewayRouteUpstreams {
}
export declare function dataIonoscloudApigatewayRouteUpstreamsToTerraform(struct?: DataIonoscloudApigatewayRouteUpstreams): any;
export declare function dataIonoscloudApigatewayRouteUpstreamsToHclTerraform(struct?: DataIonoscloudApigatewayRouteUpstreams): any;
export declare class DataIonoscloudApigatewayRouteUpstreamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudApigatewayRouteUpstreams | undefined;
    set internalValue(value: DataIonoscloudApigatewayRouteUpstreams | undefined);
    get host(): string;
    get loadbalancer(): string;
    get port(): number;
    get scheme(): string;
    get weight(): number;
}
export declare class DataIonoscloudApigatewayRouteUpstreamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudApigatewayRouteUpstreamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway_route ionoscloud_apigateway_route}
*/
export declare class DataIonoscloudApigatewayRoute extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_apigateway_route";
    /**
    * Generates CDKTF code for importing a DataIonoscloudApigatewayRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudApigatewayRoute to import
    * @param importFromId The id of the existing DataIonoscloudApigatewayRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudApigatewayRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/apigateway_route ionoscloud_apigateway_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudApigatewayRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudApigatewayRouteConfig);
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get methods(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _partialMatch?;
    get partialMatch(): boolean | cdktf.IResolvable;
    set partialMatch(value: boolean | cdktf.IResolvable);
    resetPartialMatch(): void;
    get partialMatchInput(): boolean | cdktf.IResolvable | undefined;
    get paths(): string[];
    get type(): string;
    private _upstreams;
    get upstreams(): DataIonoscloudApigatewayRouteUpstreamsList;
    get websocket(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
