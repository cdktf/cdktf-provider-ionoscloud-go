/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SnapshotConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#cpu_hot_plug Snapshot#cpu_hot_plug}
    */
    readonly cpuHotPlug?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#datacenter_id Snapshot#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Human readable description
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#description Snapshot#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#disc_virtio_hot_plug Snapshot#disc_virtio_hot_plug}
    */
    readonly discVirtioHotPlug?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#disc_virtio_hot_unplug Snapshot#disc_virtio_hot_unplug}
    */
    readonly discVirtioHotUnplug?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#id Snapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * OS type of this Snapshot
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#licence_type Snapshot#licence_type}
    */
    readonly licenceType?: string;
    /**
    * A name of that resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#name Snapshot#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#nic_hot_plug Snapshot#nic_hot_plug}
    */
    readonly nicHotPlug?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#nic_hot_unplug Snapshot#nic_hot_unplug}
    */
    readonly nicHotUnplug?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#ram_hot_plug Snapshot#ram_hot_plug}
    */
    readonly ramHotPlug?: boolean | cdktf.IResolvable;
    /**
    * Boolean value representing if the snapshot requires extra protection e.g. two factor protection
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#sec_auth_protection Snapshot#sec_auth_protection}
    */
    readonly secAuthProtection?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#volume_id Snapshot#volume_id}
    */
    readonly volumeId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#timeouts Snapshot#timeouts}
    */
    readonly timeouts?: SnapshotTimeouts;
}
export interface SnapshotTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#create Snapshot#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#default Snapshot#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#delete Snapshot#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#update Snapshot#update}
    */
    readonly update?: string;
}
export declare function snapshotTimeoutsToTerraform(struct?: SnapshotTimeouts | cdktf.IResolvable): any;
export declare function snapshotTimeoutsToHclTerraform(struct?: SnapshotTimeouts | cdktf.IResolvable): any;
export declare class SnapshotTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SnapshotTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: SnapshotTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot ionoscloud_snapshot}
*/
export declare class Snapshot extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_snapshot";
    /**
    * Generates CDKTF code for importing a Snapshot resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Snapshot to import
    * @param importFromId The id of the existing Snapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Snapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/snapshot ionoscloud_snapshot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SnapshotConfig
    */
    constructor(scope: Construct, id: string, config: SnapshotConfig);
    private _cpuHotPlug?;
    get cpuHotPlug(): boolean | cdktf.IResolvable;
    set cpuHotPlug(value: boolean | cdktf.IResolvable);
    resetCpuHotPlug(): void;
    get cpuHotPlugInput(): boolean | cdktf.IResolvable | undefined;
    get cpuHotUnplug(): cdktf.IResolvable;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get discScsiHotPlug(): cdktf.IResolvable;
    get discScsiHotUnplug(): cdktf.IResolvable;
    private _discVirtioHotPlug?;
    get discVirtioHotPlug(): boolean | cdktf.IResolvable;
    set discVirtioHotPlug(value: boolean | cdktf.IResolvable);
    resetDiscVirtioHotPlug(): void;
    get discVirtioHotPlugInput(): boolean | cdktf.IResolvable | undefined;
    private _discVirtioHotUnplug?;
    get discVirtioHotUnplug(): boolean | cdktf.IResolvable;
    set discVirtioHotUnplug(value: boolean | cdktf.IResolvable);
    resetDiscVirtioHotUnplug(): void;
    get discVirtioHotUnplugInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _licenceType?;
    get licenceType(): string;
    set licenceType(value: string);
    resetLicenceType(): void;
    get licenceTypeInput(): string | undefined;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nicHotPlug?;
    get nicHotPlug(): boolean | cdktf.IResolvable;
    set nicHotPlug(value: boolean | cdktf.IResolvable);
    resetNicHotPlug(): void;
    get nicHotPlugInput(): boolean | cdktf.IResolvable | undefined;
    private _nicHotUnplug?;
    get nicHotUnplug(): boolean | cdktf.IResolvable;
    set nicHotUnplug(value: boolean | cdktf.IResolvable);
    resetNicHotUnplug(): void;
    get nicHotUnplugInput(): boolean | cdktf.IResolvable | undefined;
    private _ramHotPlug?;
    get ramHotPlug(): boolean | cdktf.IResolvable;
    set ramHotPlug(value: boolean | cdktf.IResolvable);
    resetRamHotPlug(): void;
    get ramHotPlugInput(): boolean | cdktf.IResolvable | undefined;
    get ramHotUnplug(): cdktf.IResolvable;
    private _secAuthProtection?;
    get secAuthProtection(): boolean | cdktf.IResolvable;
    set secAuthProtection(value: boolean | cdktf.IResolvable);
    resetSecAuthProtection(): void;
    get secAuthProtectionInput(): boolean | cdktf.IResolvable | undefined;
    get size(): number;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): SnapshotTimeoutsOutputReference;
    putTimeouts(value: SnapshotTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | SnapshotTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
