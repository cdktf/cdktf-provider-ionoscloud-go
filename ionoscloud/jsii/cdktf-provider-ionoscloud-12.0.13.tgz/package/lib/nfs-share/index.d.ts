/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NfsShareConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Network File Storage Cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#cluster_id NfsShare#cluster_id}
    */
    readonly clusterId: string;
    /**
    * The group ID that will own the exported directory. If not set, **anonymous** (`512`) will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#gid NfsShare#gid}
    */
    readonly gid?: number;
    /**
    * The location of the Network File Storage Cluster. Available locations: 'de/fra, 'de/fra/2, 'de/txl, 'fr-par, 'gb-lhr, 'es/vit, 'us/las, 'us/ewr, 'us/mci'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#location NfsShare#location}
    */
    readonly location?: string;
    /**
    * The directory being exported
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#name NfsShare#name}
    */
    readonly name: string;
    /**
    * The quota in MiB for the export. The quota can restrict the amount of data that can be stored within the export. The quota can be disabled using `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#quota NfsShare#quota}
    */
    readonly quota?: number;
    /**
    * The user ID that will own the exported directory. If not set, **anonymous** (`512`) will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#uid NfsShare#uid}
    */
    readonly uid?: number;
    /**
    * client_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#client_groups NfsShare#client_groups}
    */
    readonly clientGroups: NfsShareClientGroups[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#timeouts NfsShare#timeouts}
    */
    readonly timeouts?: NfsShareTimeouts;
}
export interface NfsShareClientGroupsNfs {
    /**
    * The squash mode for the export. The squash mode can be: none - No squash mode. no mapping, root-anonymous - Map root user to anonymous uid, all-anonymous - Map all users to anonymous uid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#squash NfsShare#squash}
    */
    readonly squash?: string;
}
export declare function nfsShareClientGroupsNfsToTerraform(struct?: NfsShareClientGroupsNfsOutputReference | NfsShareClientGroupsNfs): any;
export declare function nfsShareClientGroupsNfsToHclTerraform(struct?: NfsShareClientGroupsNfsOutputReference | NfsShareClientGroupsNfs): any;
export declare class NfsShareClientGroupsNfsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NfsShareClientGroupsNfs | undefined;
    set internalValue(value: NfsShareClientGroupsNfs | undefined);
    private _squash?;
    get squash(): string;
    set squash(value: string);
    resetSquash(): void;
    get squashInput(): string | undefined;
}
export interface NfsShareClientGroups {
    /**
    * Optional description for the clients groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#description NfsShare#description}
    */
    readonly description?: string;
    /**
    * A singular host allowed to connect to the share. The host can be specified as IP address and can be either IPv4 or IPv6.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#hosts NfsShare#hosts}
    */
    readonly hosts: string[];
    /**
    * The allowed host or network to which the export is being shared. The IP address can be either IPv4 or IPv6 and has to be given with CIDR notation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#ip_networks NfsShare#ip_networks}
    */
    readonly ipNetworks: string[];
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#nfs NfsShare#nfs}
    */
    readonly nfs?: NfsShareClientGroupsNfs;
}
export declare function nfsShareClientGroupsToTerraform(struct?: NfsShareClientGroups | cdktf.IResolvable): any;
export declare function nfsShareClientGroupsToHclTerraform(struct?: NfsShareClientGroups | cdktf.IResolvable): any;
export declare class NfsShareClientGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NfsShareClientGroups | cdktf.IResolvable | undefined;
    set internalValue(value: NfsShareClientGroups | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hosts?;
    get hosts(): string[];
    set hosts(value: string[]);
    get hostsInput(): string[] | undefined;
    private _ipNetworks?;
    get ipNetworks(): string[];
    set ipNetworks(value: string[]);
    get ipNetworksInput(): string[] | undefined;
    private _nfs;
    get nfs(): NfsShareClientGroupsNfsOutputReference;
    putNfs(value: NfsShareClientGroupsNfs): void;
    resetNfs(): void;
    get nfsInput(): NfsShareClientGroupsNfs | undefined;
}
export declare class NfsShareClientGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NfsShareClientGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NfsShareClientGroupsOutputReference;
}
export interface NfsShareTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#create NfsShare#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#default NfsShare#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#delete NfsShare#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#update NfsShare#update}
    */
    readonly update?: string;
}
export declare function nfsShareTimeoutsToTerraform(struct?: NfsShareTimeouts | cdktf.IResolvable): any;
export declare function nfsShareTimeoutsToHclTerraform(struct?: NfsShareTimeouts | cdktf.IResolvable): any;
export declare class NfsShareTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NfsShareTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: NfsShareTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share ionoscloud_nfs_share}
*/
export declare class NfsShare extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_nfs_share";
    /**
    * Generates CDKTF code for importing a NfsShare resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NfsShare to import
    * @param importFromId The id of the existing NfsShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NfsShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_share ionoscloud_nfs_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NfsShareConfig
    */
    constructor(scope: Construct, id: string, config: NfsShareConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _gid?;
    get gid(): number;
    set gid(value: number);
    resetGid(): void;
    get gidInput(): number | undefined;
    get id(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nfsPath(): string;
    private _quota?;
    get quota(): number;
    set quota(value: number);
    resetQuota(): void;
    get quotaInput(): number | undefined;
    private _uid?;
    get uid(): number;
    set uid(value: number);
    resetUid(): void;
    get uidInput(): number | undefined;
    private _clientGroups;
    get clientGroups(): NfsShareClientGroupsList;
    putClientGroups(value: NfsShareClientGroups[] | cdktf.IResolvable): void;
    get clientGroupsInput(): cdktf.IResolvable | NfsShareClientGroups[] | undefined;
    private _timeouts;
    get timeouts(): NfsShareTimeoutsOutputReference;
    putTimeouts(value: NfsShareTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | NfsShareTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
