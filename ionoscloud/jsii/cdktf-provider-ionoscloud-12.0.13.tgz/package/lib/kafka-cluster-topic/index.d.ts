/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KafkaClusterTopicConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Kafka Cluster to which the topic belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#cluster_id KafkaClusterTopic#cluster_id}
    */
    readonly clusterId: string;
    /**
    * The location of your Kafka Cluster Topic. Supported locations: de/fra, de/fra/2, de/txl, fr/par, es/vit, gb/lhr, gb/bhx, us/las, us/mci, us/ewr
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#location KafkaClusterTopic#location}
    */
    readonly location?: string;
    /**
    * The name of your Kafka Cluster Topic. Must be 63 characters or less and must begin and end with an alphanumeric character (`[a-z0-9A-Z]`) with dashes (`-`), underscores (`_`), dots (`.`), and alphanumerics between.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#name KafkaClusterTopic#name}
    */
    readonly name: string;
    /**
    * The number of partitions of the topic. Partitions allow for parallel processing of messages. The partition count must be greater than or equal to the replication factor.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#number_of_partitions KafkaClusterTopic#number_of_partitions}
    */
    readonly numberOfPartitions?: number;
    /**
    * The number of replicas of the topic. The replication factor determines how many copies of the topic are stored on different brokers. The replication factor must be less than or equal to the number of brokers in the Kafka Cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#replication_factor KafkaClusterTopic#replication_factor}
    */
    readonly replicationFactor?: number;
    /**
    * This configuration controls the maximum time we will retain a log before we will discard old log segments to free up space. This represents an SLA on how soon consumers must read their data. If set to -1, no time limit is applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#retention_time KafkaClusterTopic#retention_time}
    */
    readonly retentionTime?: number;
    /**
    * This configuration controls the segment file size for the log. Retention and cleaning is always done a file at a time so a larger segment size means fewer files but less granular control over retention.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#segment_bytes KafkaClusterTopic#segment_bytes}
    */
    readonly segmentBytes?: number;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#timeouts KafkaClusterTopic#timeouts}
    */
    readonly timeouts?: KafkaClusterTopicTimeouts;
}
export interface KafkaClusterTopicTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#create KafkaClusterTopic#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#default KafkaClusterTopic#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#delete KafkaClusterTopic#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#update KafkaClusterTopic#update}
    */
    readonly update?: string;
}
export declare function kafkaClusterTopicTimeoutsToTerraform(struct?: KafkaClusterTopicTimeouts | cdktf.IResolvable): any;
export declare function kafkaClusterTopicTimeoutsToHclTerraform(struct?: KafkaClusterTopicTimeouts | cdktf.IResolvable): any;
export declare class KafkaClusterTopicTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KafkaClusterTopicTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: KafkaClusterTopicTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic ionoscloud_kafka_cluster_topic}
*/
export declare class KafkaClusterTopic extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_kafka_cluster_topic";
    /**
    * Generates CDKTF code for importing a KafkaClusterTopic resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KafkaClusterTopic to import
    * @param importFromId The id of the existing KafkaClusterTopic that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KafkaClusterTopic to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster_topic ionoscloud_kafka_cluster_topic} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KafkaClusterTopicConfig
    */
    constructor(scope: Construct, id: string, config: KafkaClusterTopicConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get id(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _numberOfPartitions?;
    get numberOfPartitions(): number;
    set numberOfPartitions(value: number);
    resetNumberOfPartitions(): void;
    get numberOfPartitionsInput(): number | undefined;
    private _replicationFactor?;
    get replicationFactor(): number;
    set replicationFactor(value: number);
    resetReplicationFactor(): void;
    get replicationFactorInput(): number | undefined;
    private _retentionTime?;
    get retentionTime(): number;
    set retentionTime(value: number);
    resetRetentionTime(): void;
    get retentionTimeInput(): number | undefined;
    private _segmentBytes?;
    get segmentBytes(): number;
    set segmentBytes(value: number);
    resetSegmentBytes(): void;
    get segmentBytesInput(): number | undefined;
    private _timeouts;
    get timeouts(): KafkaClusterTopicTimeoutsOutputReference;
    putTimeouts(value: KafkaClusterTopicTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | KafkaClusterTopicTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
