/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface S3BucketVersioningConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_bucket_versioning#bucket S3BucketVersioning#bucket}
    */
    readonly bucket: string;
    /**
    * versioning_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_bucket_versioning#versioning_configuration S3BucketVersioning#versioning_configuration}
    */
    readonly versioningConfiguration?: S3BucketVersioningVersioningConfiguration;
}
export interface S3BucketVersioningVersioningConfiguration {
    /**
    * The MFA delete status of the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_bucket_versioning#mfa_delete S3BucketVersioning#mfa_delete}
    */
    readonly mfaDelete?: string;
    /**
    * The versioning status of the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_bucket_versioning#status S3BucketVersioning#status}
    */
    readonly status: string;
}
export declare function s3BucketVersioningVersioningConfigurationToTerraform(struct?: S3BucketVersioningVersioningConfiguration | cdktf.IResolvable): any;
export declare function s3BucketVersioningVersioningConfigurationToHclTerraform(struct?: S3BucketVersioningVersioningConfiguration | cdktf.IResolvable): any;
export declare class S3BucketVersioningVersioningConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): S3BucketVersioningVersioningConfiguration | cdktf.IResolvable | undefined;
    set internalValue(value: S3BucketVersioningVersioningConfiguration | cdktf.IResolvable | undefined);
    private _mfaDelete?;
    get mfaDelete(): string;
    set mfaDelete(value: string);
    resetMfaDelete(): void;
    get mfaDeleteInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_bucket_versioning ionoscloud_s3_bucket_versioning}
*/
export declare class S3BucketVersioning extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_s3_bucket_versioning";
    /**
    * Generates CDKTF code for importing a S3BucketVersioning resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the S3BucketVersioning to import
    * @param importFromId The id of the existing S3BucketVersioning that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_bucket_versioning#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the S3BucketVersioning to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_bucket_versioning ionoscloud_s3_bucket_versioning} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options S3BucketVersioningConfig
    */
    constructor(scope: Construct, id: string, config: S3BucketVersioningConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _versioningConfiguration;
    get versioningConfiguration(): S3BucketVersioningVersioningConfigurationOutputReference;
    putVersioningConfiguration(value: S3BucketVersioningVersioningConfiguration): void;
    resetVersioningConfiguration(): void;
    get versioningConfigurationInput(): cdktf.IResolvable | S3BucketVersioningVersioningConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
