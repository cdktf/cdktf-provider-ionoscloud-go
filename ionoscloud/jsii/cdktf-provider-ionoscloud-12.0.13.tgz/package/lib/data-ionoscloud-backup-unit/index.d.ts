/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudBackupUnitConfig extends cdktf.TerraformMetaArguments {
    /**
    * Id of the backup unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#id DataIonoscloudBackupUnit#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Alphanumeric name you want assigned to the backup unit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#name DataIonoscloudBackupUnit#name}
    */
    readonly name?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#timeouts DataIonoscloudBackupUnit#timeouts}
    */
    readonly timeouts?: DataIonoscloudBackupUnitTimeouts;
}
export interface DataIonoscloudBackupUnitTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#create DataIonoscloudBackupUnit#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#default DataIonoscloudBackupUnit#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#delete DataIonoscloudBackupUnit#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#update DataIonoscloudBackupUnit#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudBackupUnitTimeoutsToTerraform(struct?: DataIonoscloudBackupUnitTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudBackupUnitTimeoutsToHclTerraform(struct?: DataIonoscloudBackupUnitTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudBackupUnitTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudBackupUnitTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudBackupUnitTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit ionoscloud_backup_unit}
*/
export declare class DataIonoscloudBackupUnit extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_backup_unit";
    /**
    * Generates CDKTF code for importing a DataIonoscloudBackupUnit resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudBackupUnit to import
    * @param importFromId The id of the existing DataIonoscloudBackupUnit that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudBackupUnit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/backup_unit ionoscloud_backup_unit} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudBackupUnitConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudBackupUnitConfig);
    get email(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get login(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataIonoscloudBackupUnitTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudBackupUnitTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudBackupUnitTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
