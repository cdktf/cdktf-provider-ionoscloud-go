/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudVpnIpsecGatewayConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the IPSec Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_gateway#id DataIonoscloudVpnIpsecGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the IPSec Gateway. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/bhx, gb/lhr, us/ewr, us/las, us/mci, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_gateway#location DataIonoscloudVpnIpsecGateway#location}
    */
    readonly location?: string;
    /**
    * The human readable name of your IPSec Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_gateway#name DataIonoscloudVpnIpsecGateway#name}
    */
    readonly name?: string;
    /**
    * The IKE version that is permitted for the VPN tunnels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_gateway#version DataIonoscloudVpnIpsecGateway#version}
    */
    readonly version?: string;
}
export interface DataIonoscloudVpnIpsecGatewayConnections {
}
export declare function dataIonoscloudVpnIpsecGatewayConnectionsToTerraform(struct?: DataIonoscloudVpnIpsecGatewayConnections): any;
export declare function dataIonoscloudVpnIpsecGatewayConnectionsToHclTerraform(struct?: DataIonoscloudVpnIpsecGatewayConnections): any;
export declare class DataIonoscloudVpnIpsecGatewayConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudVpnIpsecGatewayConnections | undefined;
    set internalValue(value: DataIonoscloudVpnIpsecGatewayConnections | undefined);
    get datacenterId(): string;
    get ipv4Cidr(): string;
    get ipv6Cidr(): string;
    get lanId(): string;
}
export declare class DataIonoscloudVpnIpsecGatewayConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudVpnIpsecGatewayConnectionsOutputReference;
}
export interface DataIonoscloudVpnIpsecGatewayMaintenanceWindow {
}
export declare function dataIonoscloudVpnIpsecGatewayMaintenanceWindowToTerraform(struct?: DataIonoscloudVpnIpsecGatewayMaintenanceWindow): any;
export declare function dataIonoscloudVpnIpsecGatewayMaintenanceWindowToHclTerraform(struct?: DataIonoscloudVpnIpsecGatewayMaintenanceWindow): any;
export declare class DataIonoscloudVpnIpsecGatewayMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudVpnIpsecGatewayMaintenanceWindow | undefined;
    set internalValue(value: DataIonoscloudVpnIpsecGatewayMaintenanceWindow | undefined);
    get dayOfTheWeek(): string;
    get time(): string;
}
export declare class DataIonoscloudVpnIpsecGatewayMaintenanceWindowList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudVpnIpsecGatewayMaintenanceWindowOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_gateway ionoscloud_vpn_ipsec_gateway}
*/
export declare class DataIonoscloudVpnIpsecGateway extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_vpn_ipsec_gateway";
    /**
    * Generates CDKTF code for importing a DataIonoscloudVpnIpsecGateway resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudVpnIpsecGateway to import
    * @param importFromId The id of the existing DataIonoscloudVpnIpsecGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudVpnIpsecGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_gateway ionoscloud_vpn_ipsec_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudVpnIpsecGatewayConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudVpnIpsecGatewayConfig);
    private _connections;
    get connections(): DataIonoscloudVpnIpsecGatewayConnectionsList;
    get description(): string;
    get gatewayIp(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataIonoscloudVpnIpsecGatewayMaintenanceWindowList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get tier(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
