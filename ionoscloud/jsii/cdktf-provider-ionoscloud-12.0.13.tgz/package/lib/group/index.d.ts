/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_activity_log Group#access_activity_log}
    */
    readonly accessActivityLog?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage AiModelHub.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_ai_model_hub Group#access_and_manage_ai_model_hub}
    */
    readonly accessAndManageAiModelHub?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage ApiGateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_api_gateway Group#access_and_manage_api_gateway}
    */
    readonly accessAndManageApiGateway?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage Cdn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_cdn Group#access_and_manage_cdn}
    */
    readonly accessAndManageCdn?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_certificates Group#access_and_manage_certificates}
    */
    readonly accessAndManageCertificates?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage dns records.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_dns Group#access_and_manage_dns}
    */
    readonly accessAndManageDns?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage IamResources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_iam_resources Group#access_and_manage_iam_resources}
    */
    readonly accessAndManageIamResources?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage Kaas.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_kaas Group#access_and_manage_kaas}
    */
    readonly accessAndManageKaas?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_logging Group#access_and_manage_logging}
    */
    readonly accessAndManageLogging?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage monitoring related functionality (access metrics, CRUD on alarms, alarm-actions etc) using Monotoring-as-a-Service (MaaS).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_monitoring Group#access_and_manage_monitoring}
    */
    readonly accessAndManageMonitoring?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage NetworkFileStorage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_network_file_storage Group#access_and_manage_network_file_storage}
    */
    readonly accessAndManageNetworkFileStorage?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to access and manage Vpn.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#access_and_manage_vpn Group#access_and_manage_vpn}
    */
    readonly accessAndManageVpn?: boolean | cdktf.IResolvable;
    /**
    * Create backup unit privilege.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_backup_unit Group#create_backup_unit}
    */
    readonly createBackupUnit?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_datacenter Group#create_datacenter}
    */
    readonly createDatacenter?: boolean | cdktf.IResolvable;
    /**
    * Create Flow Logs privilege.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_flow_log Group#create_flow_log}
    */
    readonly createFlowLog?: boolean | cdktf.IResolvable;
    /**
    * Create internet access privilege.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_internet_access Group#create_internet_access}
    */
    readonly createInternetAccess?: boolean | cdktf.IResolvable;
    /**
    * Create Kubernetes cluster privilege.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_k8s_cluster Group#create_k8s_cluster}
    */
    readonly createK8SCluster?: boolean | cdktf.IResolvable;
    /**
    * Create Network Security groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_network_security_groups Group#create_network_security_groups}
    */
    readonly createNetworkSecurityGroups?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_pcc Group#create_pcc}
    */
    readonly createPcc?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create_snapshot Group#create_snapshot}
    */
    readonly createSnapshot?: boolean | cdktf.IResolvable;
    /**
    * When set to true, information about users will be stored in state
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#get_users_data Group#get_users_data}
    */
    readonly fetchUsersData?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#id Group#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Privilege for a group to access and manage the Data Platform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#manage_dataplatform Group#manage_dataplatform}
    */
    readonly manageDataplatform?: boolean | cdktf.IResolvable;
    /**
    * Privilege for a group to manage DBaaS related functionality
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#manage_dbaas Group#manage_dbaas}
    */
    readonly manageDbaas?: boolean | cdktf.IResolvable;
    /**
    * Privilege for group accessing container registry related functionality.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#manage_registry Group#manage_registry}
    */
    readonly manageRegistry?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#name Group#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#reserve_ip Group#reserve_ip}
    */
    readonly reserveIp?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#s3_privilege Group#s3_privilege}
    */
    readonly s3Privilege?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#user_id Group#user_id}
    */
    readonly userId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#user_ids Group#user_ids}
    */
    readonly userIds?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#timeouts Group#timeouts}
    */
    readonly timeouts?: GroupTimeouts;
}
export interface GroupUsers {
}
export declare function groupUsersToTerraform(struct?: GroupUsers): any;
export declare function groupUsersToHclTerraform(struct?: GroupUsers): any;
export declare class GroupUsersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupUsers | undefined;
    set internalValue(value: GroupUsers | undefined);
    get administrator(): cdktf.IResolvable;
    get email(): string;
    get firstName(): string;
    get forceSecAuth(): cdktf.IResolvable;
    get id(): string;
    get lastName(): string;
    get password(): string;
}
export declare class GroupUsersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupUsersOutputReference;
}
export interface GroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#create Group#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#default Group#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#delete Group#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#update Group#update}
    */
    readonly update?: string;
}
export declare function groupTimeoutsToTerraform(struct?: GroupTimeouts | cdktf.IResolvable): any;
export declare function groupTimeoutsToHclTerraform(struct?: GroupTimeouts | cdktf.IResolvable): any;
export declare class GroupTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: GroupTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group ionoscloud_group}
*/
export declare class Group extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_group";
    /**
    * Generates CDKTF code for importing a Group resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Group to import
    * @param importFromId The id of the existing Group that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Group to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/group ionoscloud_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupConfig
    */
    constructor(scope: Construct, id: string, config: GroupConfig);
    private _accessActivityLog?;
    get accessActivityLog(): boolean | cdktf.IResolvable;
    set accessActivityLog(value: boolean | cdktf.IResolvable);
    resetAccessActivityLog(): void;
    get accessActivityLogInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageAiModelHub?;
    get accessAndManageAiModelHub(): boolean | cdktf.IResolvable;
    set accessAndManageAiModelHub(value: boolean | cdktf.IResolvable);
    resetAccessAndManageAiModelHub(): void;
    get accessAndManageAiModelHubInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageApiGateway?;
    get accessAndManageApiGateway(): boolean | cdktf.IResolvable;
    set accessAndManageApiGateway(value: boolean | cdktf.IResolvable);
    resetAccessAndManageApiGateway(): void;
    get accessAndManageApiGatewayInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageCdn?;
    get accessAndManageCdn(): boolean | cdktf.IResolvable;
    set accessAndManageCdn(value: boolean | cdktf.IResolvable);
    resetAccessAndManageCdn(): void;
    get accessAndManageCdnInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageCertificates?;
    get accessAndManageCertificates(): boolean | cdktf.IResolvable;
    set accessAndManageCertificates(value: boolean | cdktf.IResolvable);
    resetAccessAndManageCertificates(): void;
    get accessAndManageCertificatesInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageDns?;
    get accessAndManageDns(): boolean | cdktf.IResolvable;
    set accessAndManageDns(value: boolean | cdktf.IResolvable);
    resetAccessAndManageDns(): void;
    get accessAndManageDnsInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageIamResources?;
    get accessAndManageIamResources(): boolean | cdktf.IResolvable;
    set accessAndManageIamResources(value: boolean | cdktf.IResolvable);
    resetAccessAndManageIamResources(): void;
    get accessAndManageIamResourcesInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageKaas?;
    get accessAndManageKaas(): boolean | cdktf.IResolvable;
    set accessAndManageKaas(value: boolean | cdktf.IResolvable);
    resetAccessAndManageKaas(): void;
    get accessAndManageKaasInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageLogging?;
    get accessAndManageLogging(): boolean | cdktf.IResolvable;
    set accessAndManageLogging(value: boolean | cdktf.IResolvable);
    resetAccessAndManageLogging(): void;
    get accessAndManageLoggingInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageMonitoring?;
    get accessAndManageMonitoring(): boolean | cdktf.IResolvable;
    set accessAndManageMonitoring(value: boolean | cdktf.IResolvable);
    resetAccessAndManageMonitoring(): void;
    get accessAndManageMonitoringInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageNetworkFileStorage?;
    get accessAndManageNetworkFileStorage(): boolean | cdktf.IResolvable;
    set accessAndManageNetworkFileStorage(value: boolean | cdktf.IResolvable);
    resetAccessAndManageNetworkFileStorage(): void;
    get accessAndManageNetworkFileStorageInput(): boolean | cdktf.IResolvable | undefined;
    private _accessAndManageVpn?;
    get accessAndManageVpn(): boolean | cdktf.IResolvable;
    set accessAndManageVpn(value: boolean | cdktf.IResolvable);
    resetAccessAndManageVpn(): void;
    get accessAndManageVpnInput(): boolean | cdktf.IResolvable | undefined;
    private _createBackupUnit?;
    get createBackupUnit(): boolean | cdktf.IResolvable;
    set createBackupUnit(value: boolean | cdktf.IResolvable);
    resetCreateBackupUnit(): void;
    get createBackupUnitInput(): boolean | cdktf.IResolvable | undefined;
    private _createDatacenter?;
    get createDatacenter(): boolean | cdktf.IResolvable;
    set createDatacenter(value: boolean | cdktf.IResolvable);
    resetCreateDatacenter(): void;
    get createDatacenterInput(): boolean | cdktf.IResolvable | undefined;
    private _createFlowLog?;
    get createFlowLog(): boolean | cdktf.IResolvable;
    set createFlowLog(value: boolean | cdktf.IResolvable);
    resetCreateFlowLog(): void;
    get createFlowLogInput(): boolean | cdktf.IResolvable | undefined;
    private _createInternetAccess?;
    get createInternetAccess(): boolean | cdktf.IResolvable;
    set createInternetAccess(value: boolean | cdktf.IResolvable);
    resetCreateInternetAccess(): void;
    get createInternetAccessInput(): boolean | cdktf.IResolvable | undefined;
    private _createK8SCluster?;
    get createK8SCluster(): boolean | cdktf.IResolvable;
    set createK8SCluster(value: boolean | cdktf.IResolvable);
    resetCreateK8SCluster(): void;
    get createK8SClusterInput(): boolean | cdktf.IResolvable | undefined;
    private _createNetworkSecurityGroups?;
    get createNetworkSecurityGroups(): boolean | cdktf.IResolvable;
    set createNetworkSecurityGroups(value: boolean | cdktf.IResolvable);
    resetCreateNetworkSecurityGroups(): void;
    get createNetworkSecurityGroupsInput(): boolean | cdktf.IResolvable | undefined;
    private _createPcc?;
    get createPcc(): boolean | cdktf.IResolvable;
    set createPcc(value: boolean | cdktf.IResolvable);
    resetCreatePcc(): void;
    get createPccInput(): boolean | cdktf.IResolvable | undefined;
    private _createSnapshot?;
    get createSnapshot(): boolean | cdktf.IResolvable;
    set createSnapshot(value: boolean | cdktf.IResolvable);
    resetCreateSnapshot(): void;
    get createSnapshotInput(): boolean | cdktf.IResolvable | undefined;
    private _getUsersData?;
    get fetchUsersData(): boolean | cdktf.IResolvable;
    set fetchUsersData(value: boolean | cdktf.IResolvable);
    resetFetchUsersData(): void;
    get fetchUsersDataInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _manageDataplatform?;
    get manageDataplatform(): boolean | cdktf.IResolvable;
    set manageDataplatform(value: boolean | cdktf.IResolvable);
    resetManageDataplatform(): void;
    get manageDataplatformInput(): boolean | cdktf.IResolvable | undefined;
    private _manageDbaas?;
    get manageDbaas(): boolean | cdktf.IResolvable;
    set manageDbaas(value: boolean | cdktf.IResolvable);
    resetManageDbaas(): void;
    get manageDbaasInput(): boolean | cdktf.IResolvable | undefined;
    private _manageRegistry?;
    get manageRegistry(): boolean | cdktf.IResolvable;
    set manageRegistry(value: boolean | cdktf.IResolvable);
    resetManageRegistry(): void;
    get manageRegistryInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _reserveIp?;
    get reserveIp(): boolean | cdktf.IResolvable;
    set reserveIp(value: boolean | cdktf.IResolvable);
    resetReserveIp(): void;
    get reserveIpInput(): boolean | cdktf.IResolvable | undefined;
    private _s3Privilege?;
    get s3Privilege(): boolean | cdktf.IResolvable;
    set s3Privilege(value: boolean | cdktf.IResolvable);
    resetS3Privilege(): void;
    get s3PrivilegeInput(): boolean | cdktf.IResolvable | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    private _userIds?;
    get userIds(): string[];
    set userIds(value: string[]);
    resetUserIds(): void;
    get userIdsInput(): string[] | undefined;
    private _users;
    get users(): GroupUsersList;
    private _timeouts;
    get timeouts(): GroupTimeoutsOutputReference;
    putTimeouts(value: GroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | GroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
