/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudObjectStorageRegionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The id of the region
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_region#id DataIonoscloudObjectStorageRegion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataIonoscloudObjectStorageRegionCapability {
}
export declare function dataIonoscloudObjectStorageRegionCapabilityToTerraform(struct?: DataIonoscloudObjectStorageRegionCapability): any;
export declare function dataIonoscloudObjectStorageRegionCapabilityToHclTerraform(struct?: DataIonoscloudObjectStorageRegionCapability): any;
export declare class DataIonoscloudObjectStorageRegionCapabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudObjectStorageRegionCapability | undefined;
    set internalValue(value: DataIonoscloudObjectStorageRegionCapability | undefined);
    get iam(): cdktf.IResolvable;
    get s3Select(): cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_region ionoscloud_object_storage_region}
*/
export declare class DataIonoscloudObjectStorageRegion extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_object_storage_region";
    /**
    * Generates CDKTF code for importing a DataIonoscloudObjectStorageRegion resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudObjectStorageRegion to import
    * @param importFromId The id of the existing DataIonoscloudObjectStorageRegion that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_region#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudObjectStorageRegion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_region ionoscloud_object_storage_region} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudObjectStorageRegionConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudObjectStorageRegionConfig);
    private _capability;
    get capability(): DataIonoscloudObjectStorageRegionCapabilityOutputReference;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get location(): string;
    get storageClasses(): string[];
    get version(): number;
    get website(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
