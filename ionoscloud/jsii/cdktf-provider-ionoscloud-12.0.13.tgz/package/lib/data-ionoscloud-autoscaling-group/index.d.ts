/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudAutoscalingGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * UUID of the Autoscaling Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#id DataIonoscloudAutoscalingGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * User-defined name for the Autoscaling Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#name DataIonoscloudAutoscalingGroup#name}
    */
    readonly name?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#timeouts DataIonoscloudAutoscalingGroup#timeouts}
    */
    readonly timeouts?: DataIonoscloudAutoscalingGroupTimeouts;
}
export interface DataIonoscloudAutoscalingGroupPolicyScaleInAction {
}
export declare function dataIonoscloudAutoscalingGroupPolicyScaleInActionToTerraform(struct?: DataIonoscloudAutoscalingGroupPolicyScaleInAction): any;
export declare function dataIonoscloudAutoscalingGroupPolicyScaleInActionToHclTerraform(struct?: DataIonoscloudAutoscalingGroupPolicyScaleInAction): any;
export declare class DataIonoscloudAutoscalingGroupPolicyScaleInActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupPolicyScaleInAction | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupPolicyScaleInAction | undefined);
    get amount(): number;
    get amountType(): string;
    get cooldownPeriod(): string;
    get deleteVolumes(): cdktf.IResolvable;
    get terminationPolicyType(): string;
}
export declare class DataIonoscloudAutoscalingGroupPolicyScaleInActionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupPolicyScaleInActionOutputReference;
}
export interface DataIonoscloudAutoscalingGroupPolicyScaleOutAction {
}
export declare function dataIonoscloudAutoscalingGroupPolicyScaleOutActionToTerraform(struct?: DataIonoscloudAutoscalingGroupPolicyScaleOutAction): any;
export declare function dataIonoscloudAutoscalingGroupPolicyScaleOutActionToHclTerraform(struct?: DataIonoscloudAutoscalingGroupPolicyScaleOutAction): any;
export declare class DataIonoscloudAutoscalingGroupPolicyScaleOutActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupPolicyScaleOutAction | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupPolicyScaleOutAction | undefined);
    get amount(): number;
    get amountType(): string;
    get cooldownPeriod(): string;
}
export declare class DataIonoscloudAutoscalingGroupPolicyScaleOutActionList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupPolicyScaleOutActionOutputReference;
}
export interface DataIonoscloudAutoscalingGroupPolicy {
}
export declare function dataIonoscloudAutoscalingGroupPolicyToTerraform(struct?: DataIonoscloudAutoscalingGroupPolicy): any;
export declare function dataIonoscloudAutoscalingGroupPolicyToHclTerraform(struct?: DataIonoscloudAutoscalingGroupPolicy): any;
export declare class DataIonoscloudAutoscalingGroupPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupPolicy | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupPolicy | undefined);
    get metric(): string;
    get range(): string;
    private _scaleInAction;
    get scaleInAction(): DataIonoscloudAutoscalingGroupPolicyScaleInActionList;
    get scaleInThreshold(): number;
    private _scaleOutAction;
    get scaleOutAction(): DataIonoscloudAutoscalingGroupPolicyScaleOutActionList;
    get scaleOutThreshold(): number;
    get unit(): string;
}
export declare class DataIonoscloudAutoscalingGroupPolicyList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupPolicyOutputReference;
}
export interface DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRule {
}
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRuleToTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRule): any;
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRuleToHclTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRule): any;
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRule | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRule | undefined);
    get icmpCode(): number;
    get icmpType(): number;
    get name(): string;
    get portRangeEnd(): number;
    get portRangeStart(): number;
    get protocol(): string;
    get sourceIp(): string;
    get sourceMac(): string;
    get targetIp(): string;
    get type(): string;
}
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRuleOutputReference;
}
export interface DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLog {
}
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLogToTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLog): any;
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLogToHclTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLog): any;
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLog | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLog | undefined);
    get action(): string;
    get bucket(): string;
    get direction(): string;
    get id(): string;
    get name(): string;
}
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLogList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLogOutputReference;
}
export interface DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroup {
}
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroupToTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroup): any;
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroupToHclTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroup): any;
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroup | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroup | undefined);
    get port(): number;
    get targetGroupId(): string;
    get weight(): number;
}
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroupList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroupOutputReference;
}
export interface DataIonoscloudAutoscalingGroupReplicaConfigurationNic {
}
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicToTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNic): any;
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationNicToHclTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationNic): any;
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupReplicaConfigurationNic | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupReplicaConfigurationNic | undefined);
    get dhcp(): cdktf.IResolvable;
    get firewallActive(): cdktf.IResolvable;
    private _firewallRule;
    get firewallRule(): DataIonoscloudAutoscalingGroupReplicaConfigurationNicFirewallRuleList;
    get firewallType(): string;
    private _flowLog;
    get flowLog(): DataIonoscloudAutoscalingGroupReplicaConfigurationNicFlowLogList;
    get lan(): number;
    get name(): string;
    private _targetGroup;
    get targetGroup(): DataIonoscloudAutoscalingGroupReplicaConfigurationNicTargetGroupList;
}
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationNicList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupReplicaConfigurationNicOutputReference;
}
export interface DataIonoscloudAutoscalingGroupReplicaConfigurationVolume {
}
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationVolumeToTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationVolume): any;
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationVolumeToHclTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfigurationVolume): any;
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupReplicaConfigurationVolume | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupReplicaConfigurationVolume | undefined);
    get backupUnitId(): string;
    get bootOrder(): string;
    get bus(): string;
    get image(): string;
    get imageAlias(): string;
    get name(): string;
    get size(): number;
    get sshKeys(): string[];
    get type(): string;
}
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationVolumeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupReplicaConfigurationVolumeOutputReference;
}
export interface DataIonoscloudAutoscalingGroupReplicaConfiguration {
}
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationToTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfiguration): any;
export declare function dataIonoscloudAutoscalingGroupReplicaConfigurationToHclTerraform(struct?: DataIonoscloudAutoscalingGroupReplicaConfiguration): any;
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoscalingGroupReplicaConfiguration | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupReplicaConfiguration | undefined);
    get availabilityZone(): string;
    get cores(): number;
    get cpuFamily(): string;
    private _nic;
    get nic(): DataIonoscloudAutoscalingGroupReplicaConfigurationNicList;
    get ram(): number;
    private _volume;
    get volume(): DataIonoscloudAutoscalingGroupReplicaConfigurationVolumeList;
}
export declare class DataIonoscloudAutoscalingGroupReplicaConfigurationList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoscalingGroupReplicaConfigurationOutputReference;
}
export interface DataIonoscloudAutoscalingGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#create DataIonoscloudAutoscalingGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#default DataIonoscloudAutoscalingGroup#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#delete DataIonoscloudAutoscalingGroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#update DataIonoscloudAutoscalingGroup#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudAutoscalingGroupTimeoutsToTerraform(struct?: DataIonoscloudAutoscalingGroupTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudAutoscalingGroupTimeoutsToHclTerraform(struct?: DataIonoscloudAutoscalingGroupTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudAutoscalingGroupTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudAutoscalingGroupTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudAutoscalingGroupTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group ionoscloud_autoscaling_group}
*/
export declare class DataIonoscloudAutoscalingGroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_autoscaling_group";
    /**
    * Generates CDKTF code for importing a DataIonoscloudAutoscalingGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudAutoscalingGroup to import
    * @param importFromId The id of the existing DataIonoscloudAutoscalingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudAutoscalingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/autoscaling_group ionoscloud_autoscaling_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudAutoscalingGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudAutoscalingGroupConfig);
    get datacenterId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get location(): string;
    get maxReplicaCount(): number;
    get minReplicaCount(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _policy;
    get policy(): DataIonoscloudAutoscalingGroupPolicyList;
    private _replicaConfiguration;
    get replicaConfiguration(): DataIonoscloudAutoscalingGroupReplicaConfigurationList;
    get targetReplicaCount(): number;
    private _timeouts;
    get timeouts(): DataIonoscloudAutoscalingGroupTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudAutoscalingGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudAutoscalingGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
