/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudObjectStorageAccesskeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Access key metadata is a string of 92 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_accesskey#accesskey DataIonoscloudObjectStorageAccesskey#accesskey}
    */
    readonly accesskey?: string;
    /**
    * Description of the Access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_accesskey#description DataIonoscloudObjectStorageAccesskey#description}
    */
    readonly description?: string;
    /**
    * The ID (UUID) of the AccessKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_accesskey#id DataIonoscloudObjectStorageAccesskey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_accesskey ionoscloud_object_storage_accesskey}
*/
export declare class DataIonoscloudObjectStorageAccesskey extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_object_storage_accesskey";
    /**
    * Generates CDKTF code for importing a DataIonoscloudObjectStorageAccesskey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudObjectStorageAccesskey to import
    * @param importFromId The id of the existing DataIonoscloudObjectStorageAccesskey that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_accesskey#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudObjectStorageAccesskey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/object_storage_accesskey ionoscloud_object_storage_accesskey} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudObjectStorageAccesskeyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudObjectStorageAccesskeyConfig);
    private _accesskey?;
    get accesskey(): string;
    set accesskey(value: string);
    resetAccesskey(): void;
    get accesskeyInput(): string | undefined;
    get canonicalUserId(): string;
    get contractUserId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
