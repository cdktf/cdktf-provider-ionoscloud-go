/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AutoscalingGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Unique identifier for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#datacenter_id AutoscalingGroup#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#id AutoscalingGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The maximum value for the number of replicas on a VM Auto Scaling Group. Must be >= 0 and <= 200. Will be enforced for both automatic and manual changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#max_replica_count AutoscalingGroup#max_replica_count}
    */
    readonly maxReplicaCount: number;
    /**
    * The minimum value for the number of replicas on a VM Auto Scaling Group. Must be >= 0 and <= 200. Will be enforced for both automatic and manual changes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#min_replica_count AutoscalingGroup#min_replica_count}
    */
    readonly minReplicaCount: number;
    /**
    * User-defined name for the Autoscaling Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#name AutoscalingGroup#name}
    */
    readonly name: string;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#policy AutoscalingGroup#policy}
    */
    readonly policy: AutoscalingGroupPolicy;
    /**
    * replica_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#replica_configuration AutoscalingGroup#replica_configuration}
    */
    readonly replicaConfiguration: AutoscalingGroupReplicaConfiguration;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#timeouts AutoscalingGroup#timeouts}
    */
    readonly timeouts?: AutoscalingGroupTimeouts;
}
export interface AutoscalingGroupPolicyScaleInAction {
    /**
    * When 'amountType=ABSOLUTE' specifies the absolute number of VMs that are removed. The value must be between 1 to 10. 'amountType=PERCENTAGE' specifies the percentage value that is applied to the current number of replicas of the VM Auto Scaling Group. The value must be between 1 to 200. At least one VM is always removed. Note that for 'SCALE_IN' operations, volumes are not deleted after the server is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#amount AutoscalingGroup#amount}
    */
    readonly amount: number;
    /**
    * The type for the given amount. Possible values are: [ABSOLUTE, PERCENTAGE].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#amount_type AutoscalingGroup#amount_type}
    */
    readonly amountType: string;
    /**
    * The minimum time that elapses after the start of this scaling action until the following scaling action is started. While a scaling action is in progress, no second action is initiated for the same VM Auto Scaling Group. Instead, the metric is re-evaluated after the current scaling action completes (either successfully or with errors). This is currently validated with a minimum value of 2 minutes and a maximum of 24 hours. The default value is 5 minutes if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#cooldown_period AutoscalingGroup#cooldown_period}
    */
    readonly cooldownPeriod?: string;
    /**
    * If set to 'true', when deleting an replica during scale in, any attached volume will also be deleted. When set to 'false', all volumes remain in the datacenter and must be deleted manually. Note that every scale-out creates new volumes. When they are not deleted, they will eventually use all of your contracts resource limits. At this point, scaling out would not be possible anymore.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#delete_volumes AutoscalingGroup#delete_volumes}
    */
    readonly deleteVolumes: boolean | cdktf.IResolvable;
    /**
    * The type of termination policy for the VM Auto Scaling Group to follow a specific pattern for scaling-in replicas. The default termination policy is 'OLDEST_SERVER_FIRST'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#termination_policy_type AutoscalingGroup#termination_policy_type}
    */
    readonly terminationPolicyType?: string;
}
export declare function autoscalingGroupPolicyScaleInActionToTerraform(struct?: AutoscalingGroupPolicyScaleInActionOutputReference | AutoscalingGroupPolicyScaleInAction): any;
export declare function autoscalingGroupPolicyScaleInActionToHclTerraform(struct?: AutoscalingGroupPolicyScaleInActionOutputReference | AutoscalingGroupPolicyScaleInAction): any;
export declare class AutoscalingGroupPolicyScaleInActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingGroupPolicyScaleInAction | undefined;
    set internalValue(value: AutoscalingGroupPolicyScaleInAction | undefined);
    private _amount?;
    get amount(): number;
    set amount(value: number);
    get amountInput(): number | undefined;
    private _amountType?;
    get amountType(): string;
    set amountType(value: string);
    get amountTypeInput(): string | undefined;
    private _cooldownPeriod?;
    get cooldownPeriod(): string;
    set cooldownPeriod(value: string);
    resetCooldownPeriod(): void;
    get cooldownPeriodInput(): string | undefined;
    private _deleteVolumes?;
    get deleteVolumes(): boolean | cdktf.IResolvable;
    set deleteVolumes(value: boolean | cdktf.IResolvable);
    get deleteVolumesInput(): boolean | cdktf.IResolvable | undefined;
    private _terminationPolicyType?;
    get terminationPolicyType(): string;
    set terminationPolicyType(value: string);
    resetTerminationPolicyType(): void;
    get terminationPolicyTypeInput(): string | undefined;
}
export interface AutoscalingGroupPolicyScaleOutAction {
    /**
    * When 'amountType=ABSOLUTE' specifies the absolute number of VMs that are added. The value must be between 1 to 10. 'amountType=PERCENTAGE' specifies the percentage value that is applied to the current number of replicas of the VM Auto Scaling Group. The value must be between 1 to 200. At least one VM is always added or removed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#amount AutoscalingGroup#amount}
    */
    readonly amount: number;
    /**
    * The type for the given amount. Possible values are: [ABSOLUTE, PERCENTAGE].
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#amount_type AutoscalingGroup#amount_type}
    */
    readonly amountType: string;
    /**
    * The minimum time that elapses after the start of this scaling action until the following scaling action is started. While a scaling action is in progress, no second action is initiated for the same VM Auto Scaling Group. Instead, the metric is re-evaluated after the current scaling action completes (either successfully or with errors). This is currently validated with a minimum value of 2 minutes and a maximum of 24 hours. The default value is 5 minutes if not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#cooldown_period AutoscalingGroup#cooldown_period}
    */
    readonly cooldownPeriod?: string;
}
export declare function autoscalingGroupPolicyScaleOutActionToTerraform(struct?: AutoscalingGroupPolicyScaleOutActionOutputReference | AutoscalingGroupPolicyScaleOutAction): any;
export declare function autoscalingGroupPolicyScaleOutActionToHclTerraform(struct?: AutoscalingGroupPolicyScaleOutActionOutputReference | AutoscalingGroupPolicyScaleOutAction): any;
export declare class AutoscalingGroupPolicyScaleOutActionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingGroupPolicyScaleOutAction | undefined;
    set internalValue(value: AutoscalingGroupPolicyScaleOutAction | undefined);
    private _amount?;
    get amount(): number;
    set amount(value: number);
    get amountInput(): number | undefined;
    private _amountType?;
    get amountType(): string;
    set amountType(value: string);
    get amountTypeInput(): string | undefined;
    private _cooldownPeriod?;
    get cooldownPeriod(): string;
    set cooldownPeriod(value: string);
    resetCooldownPeriod(): void;
    get cooldownPeriodInput(): string | undefined;
}
export interface AutoscalingGroupPolicy {
    /**
    * The Metric that should trigger the scaling actions. Metric values are checked at fixed intervals.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#metric AutoscalingGroup#metric}
    */
    readonly metric: string;
    /**
    * Specifies the time range for which the samples are to be aggregated. Must be >= 2 minutes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#range AutoscalingGroup#range}
    */
    readonly range?: string;
    /**
    * The upper threshold for the value of the 'metric'. Used with the 'greater than' (>) operator. A scale-out action is triggered when this value is exceeded, specified by the 'scale_out_action' property. The value must have a lower minimum delta to the 'scale_in_threshold', depending on the metric, to avoid competing for actions simultaneously. If 'properties.policy.unit=TOTAL', a value >= 40 must be chosen.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#scale_in_threshold AutoscalingGroup#scale_in_threshold}
    */
    readonly scaleInThreshold: number;
    /**
    * The upper threshold for the value of the 'metric'. Used with the 'greater than' (>) operator. A scale-out action is triggered when this value is exceeded, specified by the 'scaleOutAction' property. The value must have a lower minimum delta to the 'scaleInThreshold', depending on the metric, to avoid competing for actions simultaneously. If 'properties.policy.unit=TOTAL', a value >= 40 must be chosen.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#scale_out_threshold AutoscalingGroup#scale_out_threshold}
    */
    readonly scaleOutThreshold: number;
    /**
    * Units of the applied Metric. Possible values are: PER_HOUR, PER_MINUTE, PER_SECOND, TOTAL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#unit AutoscalingGroup#unit}
    */
    readonly unit: string;
    /**
    * scale_in_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#scale_in_action AutoscalingGroup#scale_in_action}
    */
    readonly scaleInAction: AutoscalingGroupPolicyScaleInAction;
    /**
    * scale_out_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#scale_out_action AutoscalingGroup#scale_out_action}
    */
    readonly scaleOutAction: AutoscalingGroupPolicyScaleOutAction;
}
export declare function autoscalingGroupPolicyToTerraform(struct?: AutoscalingGroupPolicyOutputReference | AutoscalingGroupPolicy): any;
export declare function autoscalingGroupPolicyToHclTerraform(struct?: AutoscalingGroupPolicyOutputReference | AutoscalingGroupPolicy): any;
export declare class AutoscalingGroupPolicyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingGroupPolicy | undefined;
    set internalValue(value: AutoscalingGroupPolicy | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _range?;
    get range(): string;
    set range(value: string);
    resetRange(): void;
    get rangeInput(): string | undefined;
    private _scaleInThreshold?;
    get scaleInThreshold(): number;
    set scaleInThreshold(value: number);
    get scaleInThresholdInput(): number | undefined;
    private _scaleOutThreshold?;
    get scaleOutThreshold(): number;
    set scaleOutThreshold(value: number);
    get scaleOutThresholdInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
    private _scaleInAction;
    get scaleInAction(): AutoscalingGroupPolicyScaleInActionOutputReference;
    putScaleInAction(value: AutoscalingGroupPolicyScaleInAction): void;
    get scaleInActionInput(): AutoscalingGroupPolicyScaleInAction | undefined;
    private _scaleOutAction;
    get scaleOutAction(): AutoscalingGroupPolicyScaleOutActionOutputReference;
    putScaleOutAction(value: AutoscalingGroupPolicyScaleOutAction): void;
    get scaleOutActionInput(): AutoscalingGroupPolicyScaleOutAction | undefined;
}
export interface AutoscalingGroupReplicaConfigurationNicFirewallRule {
    /**
    * Sets the allowed code (from 0 to 254) when ICMP protocol is selected. The value 'null' allows all codes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#icmp_code AutoscalingGroup#icmp_code}
    */
    readonly icmpCode?: number;
    /**
    * Sets the allowed type (from 0 to 254) if the protocol ICMP is selected. The value 'null' allows all types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#icmp_type AutoscalingGroup#icmp_type}
    */
    readonly icmpType?: number;
    /**
    * The name of the firewall rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#name AutoscalingGroup#name}
    */
    readonly name?: string;
    /**
    * Sets the end range of the allowed port (from 1 to 65535) if the protocol TCP or UDP is selected. The value 'null' for 'port_range_start' and 'port_range_end' allows all ports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#port_range_end AutoscalingGroup#port_range_end}
    */
    readonly portRangeEnd?: number;
    /**
    * Sets the initial range of the allowed port (from 1 to 65535) if the protocol TCP or UDP is selected. The value 'null' for 'port_range_start' and 'port_range_end' allows all ports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#port_range_start AutoscalingGroup#port_range_start}
    */
    readonly portRangeStart?: number;
    /**
    * The protocol for the rule. The property cannot be modified after its creation (not allowed in update requests).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#protocol AutoscalingGroup#protocol}
    */
    readonly protocol: string;
    /**
    * Only traffic originating from the respective IPv4 address is permitted. The value 'null' allows traffic from any IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#source_ip AutoscalingGroup#source_ip}
    */
    readonly sourceIp?: string;
    /**
    * Only traffic originating from the respective MAC address is permitted. Valid format: 'aa:bb:cc:dd:ee:ff'. The value 'null' allows traffic from any MAC address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#source_mac AutoscalingGroup#source_mac}
    */
    readonly sourceMac?: string;
    /**
    * If the target NIC has multiple IP addresses, only the traffic directed to the respective IP address of the NIC is allowed. The value 'null' allows traffic to any target IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#target_ip AutoscalingGroup#target_ip}
    */
    readonly targetIp?: string;
    /**
    * The firewall rule type. If not specified, the default value 'INGRESS' is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#type AutoscalingGroup#type}
    */
    readonly type?: string;
}
export declare function autoscalingGroupReplicaConfigurationNicFirewallRuleToTerraform(struct?: AutoscalingGroupReplicaConfigurationNicFirewallRule | cdktf.IResolvable): any;
export declare function autoscalingGroupReplicaConfigurationNicFirewallRuleToHclTerraform(struct?: AutoscalingGroupReplicaConfigurationNicFirewallRule | cdktf.IResolvable): any;
export declare class AutoscalingGroupReplicaConfigurationNicFirewallRuleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingGroupReplicaConfigurationNicFirewallRule | cdktf.IResolvable | undefined;
    set internalValue(value: AutoscalingGroupReplicaConfigurationNicFirewallRule | cdktf.IResolvable | undefined);
    private _icmpCode?;
    get icmpCode(): number;
    set icmpCode(value: number);
    resetIcmpCode(): void;
    get icmpCodeInput(): number | undefined;
    private _icmpType?;
    get icmpType(): number;
    set icmpType(value: number);
    resetIcmpType(): void;
    get icmpTypeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _portRangeEnd?;
    get portRangeEnd(): number;
    set portRangeEnd(value: number);
    resetPortRangeEnd(): void;
    get portRangeEndInput(): number | undefined;
    private _portRangeStart?;
    get portRangeStart(): number;
    set portRangeStart(value: number);
    resetPortRangeStart(): void;
    get portRangeStartInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _sourceIp?;
    get sourceIp(): string;
    set sourceIp(value: string);
    resetSourceIp(): void;
    get sourceIpInput(): string | undefined;
    private _sourceMac?;
    get sourceMac(): string;
    set sourceMac(value: string);
    resetSourceMac(): void;
    get sourceMacInput(): string | undefined;
    private _targetIp?;
    get targetIp(): string;
    set targetIp(value: string);
    resetTargetIp(): void;
    get targetIpInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class AutoscalingGroupReplicaConfigurationNicFirewallRuleList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AutoscalingGroupReplicaConfigurationNicFirewallRule[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingGroupReplicaConfigurationNicFirewallRuleOutputReference;
}
export interface AutoscalingGroupReplicaConfigurationNicFlowLog {
    /**
    * Specifies the traffic direction pattern. Valid values: ACCEPTED, REJECTED, ALL. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#action AutoscalingGroup#action}
    */
    readonly action: string;
    /**
    * The bucket name of an existing IONOS Object Storage bucket. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#bucket AutoscalingGroup#bucket}
    */
    readonly bucket: string;
    /**
    * Specifies the traffic direction pattern. Valid values: INGRESS, EGRESS, BIDIRECTIONAL. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#direction AutoscalingGroup#direction}
    */
    readonly direction: string;
    /**
    * The resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#name AutoscalingGroup#name}
    */
    readonly name: string;
}
export declare function autoscalingGroupReplicaConfigurationNicFlowLogToTerraform(struct?: AutoscalingGroupReplicaConfigurationNicFlowLog | cdktf.IResolvable): any;
export declare function autoscalingGroupReplicaConfigurationNicFlowLogToHclTerraform(struct?: AutoscalingGroupReplicaConfigurationNicFlowLog | cdktf.IResolvable): any;
export declare class AutoscalingGroupReplicaConfigurationNicFlowLogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingGroupReplicaConfigurationNicFlowLog | cdktf.IResolvable | undefined;
    set internalValue(value: AutoscalingGroupReplicaConfigurationNicFlowLog | cdktf.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class AutoscalingGroupReplicaConfigurationNicFlowLogList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AutoscalingGroupReplicaConfigurationNicFlowLog[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingGroupReplicaConfigurationNicFlowLogOutputReference;
}
export interface AutoscalingGroupReplicaConfigurationNicTargetGroup {
    /**
    * The port for the target group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#port AutoscalingGroup#port}
    */
    readonly port: number;
    /**
    * The ID of the target group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#target_group_id AutoscalingGroup#target_group_id}
    */
    readonly targetGroupId: string;
    /**
    * The weight for the target group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#weight AutoscalingGroup#weight}
    */
    readonly weight: number;
}
export declare function autoscalingGroupReplicaConfigurationNicTargetGroupToTerraform(struct?: AutoscalingGroupReplicaConfigurationNicTargetGroupOutputReference | AutoscalingGroupReplicaConfigurationNicTargetGroup): any;
export declare function autoscalingGroupReplicaConfigurationNicTargetGroupToHclTerraform(struct?: AutoscalingGroupReplicaConfigurationNicTargetGroupOutputReference | AutoscalingGroupReplicaConfigurationNicTargetGroup): any;
export declare class AutoscalingGroupReplicaConfigurationNicTargetGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingGroupReplicaConfigurationNicTargetGroup | undefined;
    set internalValue(value: AutoscalingGroupReplicaConfigurationNicTargetGroup | undefined);
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _targetGroupId?;
    get targetGroupId(): string;
    set targetGroupId(value: string);
    get targetGroupIdInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export interface AutoscalingGroupReplicaConfigurationNic {
    /**
    * Dhcp flag for this replica Nic. This is an optional attribute with default value of 'true' if not given in the request payload or given as null.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#dhcp AutoscalingGroup#dhcp}
    */
    readonly dhcp?: boolean | cdktf.IResolvable;
    /**
    * Activate or deactivate the firewall. By default, an active firewall without any defined rules will block all incoming network traffic except for the firewall rules that explicitly allows certain protocols, IP addresses and ports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#firewall_active AutoscalingGroup#firewall_active}
    */
    readonly firewallActive?: boolean | cdktf.IResolvable;
    /**
    * The type of firewall rules that will be allowed on the NIC. If not specified, the default INGRESS value is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#firewall_type AutoscalingGroup#firewall_type}
    */
    readonly firewallType?: string;
    /**
    * Lan ID for this replica Nic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#lan AutoscalingGroup#lan}
    */
    readonly lan: number;
    /**
    * Name for this replica NIC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#name AutoscalingGroup#name}
    */
    readonly name: string;
    /**
    * firewall_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#firewall_rule AutoscalingGroup#firewall_rule}
    */
    readonly firewallRule?: AutoscalingGroupReplicaConfigurationNicFirewallRule[] | cdktf.IResolvable;
    /**
    * flow_log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#flow_log AutoscalingGroup#flow_log}
    */
    readonly flowLog?: AutoscalingGroupReplicaConfigurationNicFlowLog[] | cdktf.IResolvable;
    /**
    * target_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#target_group AutoscalingGroup#target_group}
    */
    readonly targetGroup?: AutoscalingGroupReplicaConfigurationNicTargetGroup;
}
export declare function autoscalingGroupReplicaConfigurationNicToTerraform(struct?: AutoscalingGroupReplicaConfigurationNic | cdktf.IResolvable): any;
export declare function autoscalingGroupReplicaConfigurationNicToHclTerraform(struct?: AutoscalingGroupReplicaConfigurationNic | cdktf.IResolvable): any;
export declare class AutoscalingGroupReplicaConfigurationNicOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingGroupReplicaConfigurationNic | cdktf.IResolvable | undefined;
    set internalValue(value: AutoscalingGroupReplicaConfigurationNic | cdktf.IResolvable | undefined);
    private _dhcp?;
    get dhcp(): boolean | cdktf.IResolvable;
    set dhcp(value: boolean | cdktf.IResolvable);
    resetDhcp(): void;
    get dhcpInput(): boolean | cdktf.IResolvable | undefined;
    private _firewallActive?;
    get firewallActive(): boolean | cdktf.IResolvable;
    set firewallActive(value: boolean | cdktf.IResolvable);
    resetFirewallActive(): void;
    get firewallActiveInput(): boolean | cdktf.IResolvable | undefined;
    private _firewallType?;
    get firewallType(): string;
    set firewallType(value: string);
    resetFirewallType(): void;
    get firewallTypeInput(): string | undefined;
    private _lan?;
    get lan(): number;
    set lan(value: number);
    get lanInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _firewallRule;
    get firewallRule(): AutoscalingGroupReplicaConfigurationNicFirewallRuleList;
    putFirewallRule(value: AutoscalingGroupReplicaConfigurationNicFirewallRule[] | cdktf.IResolvable): void;
    resetFirewallRule(): void;
    get firewallRuleInput(): cdktf.IResolvable | AutoscalingGroupReplicaConfigurationNicFirewallRule[] | undefined;
    private _flowLog;
    get flowLog(): AutoscalingGroupReplicaConfigurationNicFlowLogList;
    putFlowLog(value: AutoscalingGroupReplicaConfigurationNicFlowLog[] | cdktf.IResolvable): void;
    resetFlowLog(): void;
    get flowLogInput(): cdktf.IResolvable | AutoscalingGroupReplicaConfigurationNicFlowLog[] | undefined;
    private _targetGroup;
    get targetGroup(): AutoscalingGroupReplicaConfigurationNicTargetGroupOutputReference;
    putTargetGroup(value: AutoscalingGroupReplicaConfigurationNicTargetGroup): void;
    resetTargetGroup(): void;
    get targetGroupInput(): AutoscalingGroupReplicaConfigurationNicTargetGroup | undefined;
}
export declare class AutoscalingGroupReplicaConfigurationNicList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AutoscalingGroupReplicaConfigurationNic[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingGroupReplicaConfigurationNicOutputReference;
}
export interface AutoscalingGroupReplicaConfigurationVolume {
    /**
    * The uuid of the Backup Unit that user has access to. The property is immutable and is only allowed to be set on a new volume creation. It is mandatory to provide either 'public image' or 'imageAlias' in conjunction with this property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#backup_unit_id AutoscalingGroup#backup_unit_id}
    */
    readonly backupUnitId?: string;
    /**
    * Determines whether the volume will be used as a boot volume. Set to NONE, the volume will not be used as boot volume.
    * Set to PRIMARY, the volume will be used as boot volume and set to AUTO will delegate the decision to the provisioning engine to decide whether to use the volume as boot volume.
    * Notice that exactly one volume can be set to PRIMARY or all of them set to AUTO.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#boot_order AutoscalingGroup#boot_order}
    */
    readonly bootOrder: string;
    /**
    * The bus type of the volume. Default setting is 'VIRTIO'. The bus type 'IDE' is also supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#bus AutoscalingGroup#bus}
    */
    readonly bus?: string;
    /**
    * The image installed on the disk. Currently, only the UUID of the image is supported. Note that either 'image' or 'imageAlias' must be specified, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#image AutoscalingGroup#image}
    */
    readonly image?: string;
    /**
    * The image installed on the volume. Must be an 'imageAlias' as specified via the images API. Note that one of 'image' or 'imageAlias' must be set, but not both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#image_alias AutoscalingGroup#image_alias}
    */
    readonly imageAlias?: string;
    /**
    * Image password for this replica volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#image_password AutoscalingGroup#image_password}
    */
    readonly imagePassword?: string;
    /**
    * Name for this replica volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#name AutoscalingGroup#name}
    */
    readonly name: string;
    /**
    * User-defined size for this replica volume in GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#size AutoscalingGroup#size}
    */
    readonly size: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#ssh_keys AutoscalingGroup#ssh_keys}
    */
    readonly sshKeys?: string[];
    /**
    * Storage Type for this replica volume. Possible values: SSD, HDD, SSD_STANDARD or SSD_PREMIUM
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#type AutoscalingGroup#type}
    */
    readonly type: string;
    /**
    * User-data (Cloud Init) for this replica volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#user_data AutoscalingGroup#user_data}
    */
    readonly userData?: string;
}
export declare function autoscalingGroupReplicaConfigurationVolumeToTerraform(struct?: AutoscalingGroupReplicaConfigurationVolume | cdktf.IResolvable): any;
export declare function autoscalingGroupReplicaConfigurationVolumeToHclTerraform(struct?: AutoscalingGroupReplicaConfigurationVolume | cdktf.IResolvable): any;
export declare class AutoscalingGroupReplicaConfigurationVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AutoscalingGroupReplicaConfigurationVolume | cdktf.IResolvable | undefined;
    set internalValue(value: AutoscalingGroupReplicaConfigurationVolume | cdktf.IResolvable | undefined);
    private _backupUnitId?;
    get backupUnitId(): string;
    set backupUnitId(value: string);
    resetBackupUnitId(): void;
    get backupUnitIdInput(): string | undefined;
    private _bootOrder?;
    get bootOrder(): string;
    set bootOrder(value: string);
    get bootOrderInput(): string | undefined;
    private _bus?;
    get bus(): string;
    set bus(value: string);
    resetBus(): void;
    get busInput(): string | undefined;
    private _image?;
    get image(): string;
    set image(value: string);
    resetImage(): void;
    get imageInput(): string | undefined;
    private _imageAlias?;
    get imageAlias(): string;
    set imageAlias(value: string);
    resetImageAlias(): void;
    get imageAliasInput(): string | undefined;
    private _imagePassword?;
    get imagePassword(): string;
    set imagePassword(value: string);
    resetImagePassword(): void;
    get imagePasswordInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    private _sshKeys?;
    get sshKeys(): string[];
    set sshKeys(value: string[]);
    resetSshKeys(): void;
    get sshKeysInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
}
export declare class AutoscalingGroupReplicaConfigurationVolumeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AutoscalingGroupReplicaConfigurationVolume[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AutoscalingGroupReplicaConfigurationVolumeOutputReference;
}
export interface AutoscalingGroupReplicaConfiguration {
    /**
    * The zone where the VMs are created using this configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#availability_zone AutoscalingGroup#availability_zone}
    */
    readonly availabilityZone: string;
    /**
    * The total number of cores for the VMs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#cores AutoscalingGroup#cores}
    */
    readonly cores: number;
    /**
    * The zone where the VMs are created using this configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#cpu_family AutoscalingGroup#cpu_family}
    */
    readonly cpuFamily?: string;
    /**
    * The amount of memory for the VMs in MB, e.g. 2048. Size must be specified in multiples of 256 MB with a minimum of 256 MB; however, if you set ramHotPlug to TRUE then you must use a minimum of 1024 MB. If you set the RAM size more than 240GB, then ramHotPlug will be set to FALSE and can not be set to TRUE unless RAM size not set to less than 240GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#ram AutoscalingGroup#ram}
    */
    readonly ram: number;
    /**
    * nic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#nic AutoscalingGroup#nic}
    */
    readonly nic?: AutoscalingGroupReplicaConfigurationNic[] | cdktf.IResolvable;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#volume AutoscalingGroup#volume}
    */
    readonly volume?: AutoscalingGroupReplicaConfigurationVolume[] | cdktf.IResolvable;
}
export declare function autoscalingGroupReplicaConfigurationToTerraform(struct?: AutoscalingGroupReplicaConfigurationOutputReference | AutoscalingGroupReplicaConfiguration): any;
export declare function autoscalingGroupReplicaConfigurationToHclTerraform(struct?: AutoscalingGroupReplicaConfigurationOutputReference | AutoscalingGroupReplicaConfiguration): any;
export declare class AutoscalingGroupReplicaConfigurationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingGroupReplicaConfiguration | undefined;
    set internalValue(value: AutoscalingGroupReplicaConfiguration | undefined);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    get availabilityZoneInput(): string | undefined;
    private _cores?;
    get cores(): number;
    set cores(value: number);
    get coresInput(): number | undefined;
    private _cpuFamily?;
    get cpuFamily(): string;
    set cpuFamily(value: string);
    resetCpuFamily(): void;
    get cpuFamilyInput(): string | undefined;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    get ramInput(): number | undefined;
    private _nic;
    get nic(): AutoscalingGroupReplicaConfigurationNicList;
    putNic(value: AutoscalingGroupReplicaConfigurationNic[] | cdktf.IResolvable): void;
    resetNic(): void;
    get nicInput(): cdktf.IResolvable | AutoscalingGroupReplicaConfigurationNic[] | undefined;
    private _volume;
    get volume(): AutoscalingGroupReplicaConfigurationVolumeList;
    putVolume(value: AutoscalingGroupReplicaConfigurationVolume[] | cdktf.IResolvable): void;
    resetVolume(): void;
    get volumeInput(): cdktf.IResolvable | AutoscalingGroupReplicaConfigurationVolume[] | undefined;
}
export interface AutoscalingGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#create AutoscalingGroup#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#default AutoscalingGroup#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#delete AutoscalingGroup#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#update AutoscalingGroup#update}
    */
    readonly update?: string;
}
export declare function autoscalingGroupTimeoutsToTerraform(struct?: AutoscalingGroupTimeouts | cdktf.IResolvable): any;
export declare function autoscalingGroupTimeoutsToHclTerraform(struct?: AutoscalingGroupTimeouts | cdktf.IResolvable): any;
export declare class AutoscalingGroupTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoscalingGroupTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: AutoscalingGroupTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group ionoscloud_autoscaling_group}
*/
export declare class AutoscalingGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_autoscaling_group";
    /**
    * Generates CDKTF code for importing a AutoscalingGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutoscalingGroup to import
    * @param importFromId The id of the existing AutoscalingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutoscalingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/autoscaling_group ionoscloud_autoscaling_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutoscalingGroupConfig
    */
    constructor(scope: Construct, id: string, config: AutoscalingGroupConfig);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get location(): string;
    private _maxReplicaCount?;
    get maxReplicaCount(): number;
    set maxReplicaCount(value: number);
    get maxReplicaCountInput(): number | undefined;
    private _minReplicaCount?;
    get minReplicaCount(): number;
    set minReplicaCount(value: number);
    get minReplicaCountInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policy;
    get policy(): AutoscalingGroupPolicyOutputReference;
    putPolicy(value: AutoscalingGroupPolicy): void;
    get policyInput(): AutoscalingGroupPolicy | undefined;
    private _replicaConfiguration;
    get replicaConfiguration(): AutoscalingGroupReplicaConfigurationOutputReference;
    putReplicaConfiguration(value: AutoscalingGroupReplicaConfiguration): void;
    get replicaConfigurationInput(): AutoscalingGroupReplicaConfiguration | undefined;
    private _timeouts;
    get timeouts(): AutoscalingGroupTimeoutsOutputReference;
    putTimeouts(value: AutoscalingGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | AutoscalingGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
