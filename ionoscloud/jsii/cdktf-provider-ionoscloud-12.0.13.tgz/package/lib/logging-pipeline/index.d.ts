/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LoggingPipelineConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#id LoggingPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of your logging pipeline. Default: de/txl. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/lhr, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#location LoggingPipeline#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#name LoggingPipeline#name}
    */
    readonly name: string;
    /**
    * log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#log LoggingPipeline#log}
    */
    readonly log: LoggingPipelineLog[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#timeouts LoggingPipeline#timeouts}
    */
    readonly timeouts?: LoggingPipelineTimeouts;
}
export interface LoggingPipelineLogDestinations {
    /**
    * Defines the number of days a log record should be kept in loki. Works with loki destination type only. Possible values are: 7, 14, 30.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#retention_in_days LoggingPipeline#retention_in_days}
    */
    readonly retentionInDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#type LoggingPipeline#type}
    */
    readonly type?: string;
}
export declare function loggingPipelineLogDestinationsToTerraform(struct?: LoggingPipelineLogDestinations | cdktf.IResolvable): any;
export declare function loggingPipelineLogDestinationsToHclTerraform(struct?: LoggingPipelineLogDestinations | cdktf.IResolvable): any;
export declare class LoggingPipelineLogDestinationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoggingPipelineLogDestinations | cdktf.IResolvable | undefined;
    set internalValue(value: LoggingPipelineLogDestinations | cdktf.IResolvable | undefined);
    private _retentionInDays?;
    get retentionInDays(): number;
    set retentionInDays(value: number);
    resetRetentionInDays(): void;
    get retentionInDaysInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class LoggingPipelineLogDestinationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LoggingPipelineLogDestinations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoggingPipelineLogDestinationsOutputReference;
}
export interface LoggingPipelineLog {
    /**
    * Protocol to use as intake. Possible values are: http, tcp.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#protocol LoggingPipeline#protocol}
    */
    readonly protocol: string;
    /**
    * The source parser to be used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#source LoggingPipeline#source}
    */
    readonly source: string;
    /**
    * The tag is used to distinguish different pipelines. Must be unique amongst the pipeline's array items.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#tag LoggingPipeline#tag}
    */
    readonly tag: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#destinations LoggingPipeline#destinations}
    */
    readonly destinations?: LoggingPipelineLogDestinations[] | cdktf.IResolvable;
}
export declare function loggingPipelineLogToTerraform(struct?: LoggingPipelineLog | cdktf.IResolvable): any;
export declare function loggingPipelineLogToHclTerraform(struct?: LoggingPipelineLog | cdktf.IResolvable): any;
export declare class LoggingPipelineLogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoggingPipelineLog | cdktf.IResolvable | undefined;
    set internalValue(value: LoggingPipelineLog | cdktf.IResolvable | undefined);
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    get public(): cdktf.IResolvable;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    get tagInput(): string | undefined;
    private _destinations;
    get destinations(): LoggingPipelineLogDestinationsList;
    putDestinations(value: LoggingPipelineLogDestinations[] | cdktf.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktf.IResolvable | LoggingPipelineLogDestinations[] | undefined;
}
export declare class LoggingPipelineLogList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LoggingPipelineLog[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoggingPipelineLogOutputReference;
}
export interface LoggingPipelineTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#create LoggingPipeline#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#default LoggingPipeline#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#delete LoggingPipeline#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#update LoggingPipeline#update}
    */
    readonly update?: string;
}
export declare function loggingPipelineTimeoutsToTerraform(struct?: LoggingPipelineTimeouts | cdktf.IResolvable): any;
export declare function loggingPipelineTimeoutsToHclTerraform(struct?: LoggingPipelineTimeouts | cdktf.IResolvable): any;
export declare class LoggingPipelineTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoggingPipelineTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: LoggingPipelineTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline ionoscloud_logging_pipeline}
*/
export declare class LoggingPipeline extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_logging_pipeline";
    /**
    * Generates CDKTF code for importing a LoggingPipeline resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoggingPipeline to import
    * @param importFromId The id of the existing LoggingPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoggingPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/logging_pipeline ionoscloud_logging_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoggingPipelineConfig
    */
    constructor(scope: Construct, id: string, config: LoggingPipelineConfig);
    get grafanaAddress(): string;
    get httpAddress(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get key(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get tcpAddress(): string;
    private _log;
    get log(): LoggingPipelineLogList;
    putLog(value: LoggingPipelineLog[] | cdktf.IResolvable): void;
    get logInput(): cdktf.IResolvable | LoggingPipelineLog[] | undefined;
    private _timeouts;
    get timeouts(): LoggingPipelineTimeoutsOutputReference;
    putTimeouts(value: LoggingPipelineTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | LoggingPipelineTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
