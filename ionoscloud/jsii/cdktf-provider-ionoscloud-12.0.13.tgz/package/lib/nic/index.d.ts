/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NicConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#datacenter_id Nic#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#dhcp Nic#dhcp}
    */
    readonly dhcp?: boolean | cdktf.IResolvable;
    /**
    * Indicates whether this NIC receives an IPv6 address through DHCP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#dhcpv6 Nic#dhcpv6}
    */
    readonly dhcpv6?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#firewall_active Nic#firewall_active}
    */
    readonly firewallActive?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#firewall_type Nic#firewall_type}
    */
    readonly firewallType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#id Nic#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Collection of IP addresses assigned to a nic. Explicitly assigned public IPs need to come from reserved IP blocks, Passing value null or empty array will assign an IP address automatically.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#ips Nic#ips}
    */
    readonly ips?: string[];
    /**
    * IPv6 CIDR block assigned to the NIC.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#ipv6_cidr_block Nic#ipv6_cidr_block}
    */
    readonly ipv6CidrBlock?: string;
    /**
    * Collection for IPv6 addresses assigned to a nic. Explicitly assigned IPv6 addresses need to come from inside the IPv6 CIDR block assigned to the nic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#ipv6_ips Nic#ipv6_ips}
    */
    readonly ipv6Ips?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#lan Nic#lan}
    */
    readonly lan: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#mac Nic#mac}
    */
    readonly mac?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#name Nic#name}
    */
    readonly name?: string;
    /**
    * The list of Security Group IDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#security_groups_ids Nic#security_groups_ids}
    */
    readonly securityGroupsIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#server_id Nic#server_id}
    */
    readonly serverId: string;
    /**
    * flowlog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#flowlog Nic#flowlog}
    */
    readonly flowlog?: NicFlowlog;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#timeouts Nic#timeouts}
    */
    readonly timeouts?: NicTimeouts;
}
export interface NicFlowlog {
    /**
    * Specifies the traffic direction pattern. Valid values: ACCEPTED, REJECTED, ALL. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#action Nic#action}
    */
    readonly action: string;
    /**
    * The bucket name of an existing IONOS Object Storage bucket. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#bucket Nic#bucket}
    */
    readonly bucket: string;
    /**
    * Specifies the traffic direction pattern. Valid values: INGRESS, EGRESS, BIDIRECTIONAL. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#direction Nic#direction}
    */
    readonly direction: string;
    /**
    * The resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#name Nic#name}
    */
    readonly name: string;
}
export declare function nicFlowlogToTerraform(struct?: NicFlowlogOutputReference | NicFlowlog): any;
export declare function nicFlowlogToHclTerraform(struct?: NicFlowlogOutputReference | NicFlowlog): any;
export declare class NicFlowlogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NicFlowlog | undefined;
    set internalValue(value: NicFlowlog | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface NicTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#create Nic#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#default Nic#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#delete Nic#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#update Nic#update}
    */
    readonly update?: string;
}
export declare function nicTimeoutsToTerraform(struct?: NicTimeouts | cdktf.IResolvable): any;
export declare function nicTimeoutsToHclTerraform(struct?: NicTimeouts | cdktf.IResolvable): any;
export declare class NicTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NicTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: NicTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic ionoscloud_nic}
*/
export declare class Nic extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_nic";
    /**
    * Generates CDKTF code for importing a Nic resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Nic to import
    * @param importFromId The id of the existing Nic that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Nic to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nic ionoscloud_nic} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NicConfig
    */
    constructor(scope: Construct, id: string, config: NicConfig);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    get deviceNumber(): number;
    private _dhcp?;
    get dhcp(): boolean | cdktf.IResolvable;
    set dhcp(value: boolean | cdktf.IResolvable);
    resetDhcp(): void;
    get dhcpInput(): boolean | cdktf.IResolvable | undefined;
    private _dhcpv6?;
    get dhcpv6(): boolean | cdktf.IResolvable;
    set dhcpv6(value: boolean | cdktf.IResolvable);
    resetDhcpv6(): void;
    get dhcpv6Input(): boolean | cdktf.IResolvable | undefined;
    private _firewallActive?;
    get firewallActive(): boolean | cdktf.IResolvable;
    set firewallActive(value: boolean | cdktf.IResolvable);
    resetFirewallActive(): void;
    get firewallActiveInput(): boolean | cdktf.IResolvable | undefined;
    private _firewallType?;
    get firewallType(): string;
    set firewallType(value: string);
    resetFirewallType(): void;
    get firewallTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ips?;
    get ips(): string[];
    set ips(value: string[]);
    resetIps(): void;
    get ipsInput(): string[] | undefined;
    private _ipv6CidrBlock?;
    get ipv6CidrBlock(): string;
    set ipv6CidrBlock(value: string);
    resetIpv6CidrBlock(): void;
    get ipv6CidrBlockInput(): string | undefined;
    private _ipv6Ips?;
    get ipv6Ips(): string[];
    set ipv6Ips(value: string[]);
    resetIpv6Ips(): void;
    get ipv6IpsInput(): string[] | undefined;
    private _lan?;
    get lan(): number;
    set lan(value: number);
    get lanInput(): number | undefined;
    private _mac?;
    get mac(): string;
    set mac(value: string);
    resetMac(): void;
    get macInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get pciSlot(): number;
    private _securityGroupsIds?;
    get securityGroupsIds(): string[];
    set securityGroupsIds(value: string[]);
    resetSecurityGroupsIds(): void;
    get securityGroupsIdsInput(): string[] | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _flowlog;
    get flowlog(): NicFlowlogOutputReference;
    putFlowlog(value: NicFlowlog): void;
    resetFlowlog(): void;
    get flowlogInput(): NicFlowlog | undefined;
    private _timeouts;
    get timeouts(): NicTimeoutsOutputReference;
    putTimeouts(value: NicTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | NicTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
