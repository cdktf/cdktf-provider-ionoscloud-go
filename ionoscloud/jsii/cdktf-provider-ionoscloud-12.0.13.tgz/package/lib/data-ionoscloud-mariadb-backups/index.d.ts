/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudMariadbBackupsConfig extends cdktf.TerraformMetaArguments {
    /**
    * The unique ID of the backup
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#backup_id DataIonoscloudMariadbBackups#backup_id}
    */
    readonly backupId?: string;
    /**
    * The unique ID of the cluster that was backed up
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#cluster_id DataIonoscloudMariadbBackups#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#id DataIonoscloudMariadbBackups#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The cluster location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#location DataIonoscloudMariadbBackups#location}
    */
    readonly location?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#timeouts DataIonoscloudMariadbBackups#timeouts}
    */
    readonly timeouts?: DataIonoscloudMariadbBackupsTimeouts;
}
export interface DataIonoscloudMariadbBackupsBackupsBaseBackups {
}
export declare function dataIonoscloudMariadbBackupsBackupsBaseBackupsToTerraform(struct?: DataIonoscloudMariadbBackupsBackupsBaseBackups): any;
export declare function dataIonoscloudMariadbBackupsBackupsBaseBackupsToHclTerraform(struct?: DataIonoscloudMariadbBackupsBackupsBaseBackups): any;
export declare class DataIonoscloudMariadbBackupsBackupsBaseBackupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudMariadbBackupsBackupsBaseBackups | undefined;
    set internalValue(value: DataIonoscloudMariadbBackupsBackupsBaseBackups | undefined);
    get created(): string;
    get size(): number;
}
export declare class DataIonoscloudMariadbBackupsBackupsBaseBackupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudMariadbBackupsBackupsBaseBackupsOutputReference;
}
export interface DataIonoscloudMariadbBackupsBackups {
}
export declare function dataIonoscloudMariadbBackupsBackupsToTerraform(struct?: DataIonoscloudMariadbBackupsBackups): any;
export declare function dataIonoscloudMariadbBackupsBackupsToHclTerraform(struct?: DataIonoscloudMariadbBackupsBackups): any;
export declare class DataIonoscloudMariadbBackupsBackupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudMariadbBackupsBackups | undefined;
    set internalValue(value: DataIonoscloudMariadbBackupsBackups | undefined);
    private _baseBackups;
    get baseBackups(): DataIonoscloudMariadbBackupsBackupsBaseBackupsList;
    get clusterId(): string;
    get earliestRecoveryTargetTime(): string;
    get size(): number;
}
export declare class DataIonoscloudMariadbBackupsBackupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudMariadbBackupsBackupsOutputReference;
}
export interface DataIonoscloudMariadbBackupsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#create DataIonoscloudMariadbBackups#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#default DataIonoscloudMariadbBackups#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#delete DataIonoscloudMariadbBackups#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#update DataIonoscloudMariadbBackups#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudMariadbBackupsTimeoutsToTerraform(struct?: DataIonoscloudMariadbBackupsTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudMariadbBackupsTimeoutsToHclTerraform(struct?: DataIonoscloudMariadbBackupsTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudMariadbBackupsTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudMariadbBackupsTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudMariadbBackupsTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups ionoscloud_mariadb_backups}
*/
export declare class DataIonoscloudMariadbBackups extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_mariadb_backups";
    /**
    * Generates CDKTF code for importing a DataIonoscloudMariadbBackups resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudMariadbBackups to import
    * @param importFromId The id of the existing DataIonoscloudMariadbBackups that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudMariadbBackups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/mariadb_backups ionoscloud_mariadb_backups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudMariadbBackupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudMariadbBackupsConfig);
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    resetBackupId(): void;
    get backupIdInput(): string | undefined;
    private _backups;
    get backups(): DataIonoscloudMariadbBackupsBackupsList;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataIonoscloudMariadbBackupsTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudMariadbBackupsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudMariadbBackupsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
