/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudPgDatabasesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#cluster_id DataIonoscloudPgDatabases#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#id DataIonoscloudPgDatabases#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Filter for this data source, using this you can retrieve all databases that belong to a specific user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#owner DataIonoscloudPgDatabases#owner}
    */
    readonly owner?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#timeouts DataIonoscloudPgDatabases#timeouts}
    */
    readonly timeouts?: DataIonoscloudPgDatabasesTimeouts;
}
export interface DataIonoscloudPgDatabasesDatabases {
}
export declare function dataIonoscloudPgDatabasesDatabasesToTerraform(struct?: DataIonoscloudPgDatabasesDatabases): any;
export declare function dataIonoscloudPgDatabasesDatabasesToHclTerraform(struct?: DataIonoscloudPgDatabasesDatabases): any;
export declare class DataIonoscloudPgDatabasesDatabasesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudPgDatabasesDatabases | undefined;
    set internalValue(value: DataIonoscloudPgDatabasesDatabases | undefined);
    get id(): string;
    get name(): string;
    get owner(): string;
}
export declare class DataIonoscloudPgDatabasesDatabasesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudPgDatabasesDatabasesOutputReference;
}
export interface DataIonoscloudPgDatabasesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#create DataIonoscloudPgDatabases#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#default DataIonoscloudPgDatabases#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#delete DataIonoscloudPgDatabases#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#update DataIonoscloudPgDatabases#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudPgDatabasesTimeoutsToTerraform(struct?: DataIonoscloudPgDatabasesTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudPgDatabasesTimeoutsToHclTerraform(struct?: DataIonoscloudPgDatabasesTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudPgDatabasesTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudPgDatabasesTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudPgDatabasesTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases ionoscloud_pg_databases}
*/
export declare class DataIonoscloudPgDatabases extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_pg_databases";
    /**
    * Generates CDKTF code for importing a DataIonoscloudPgDatabases resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudPgDatabases to import
    * @param importFromId The id of the existing DataIonoscloudPgDatabases that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudPgDatabases to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/pg_databases ionoscloud_pg_databases} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudPgDatabasesConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudPgDatabasesConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _databases;
    get databases(): DataIonoscloudPgDatabasesDatabasesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataIonoscloudPgDatabasesTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudPgDatabasesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudPgDatabasesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
