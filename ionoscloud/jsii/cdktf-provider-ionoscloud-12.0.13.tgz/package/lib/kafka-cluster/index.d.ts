/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KafkaClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The location of your Kafka Cluster. Supported locations: de/fra, de/fra/2, de/txl, fr/par, es/vit, gb/lhr, gb/bhx, us/las, us/mci, us/ewr
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#location KafkaCluster#location}
    */
    readonly location?: string;
    /**
    * The name of your Kafka Cluster. Must be 63 characters or less and must begin and end with an alphanumeric character (`[a-z0-9A-Z]`) with dashes (`-`), underscores (`_`), dots (`.`), and alphanumerics between.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#name KafkaCluster#name}
    */
    readonly name: string;
    /**
    * The size of your Kafka Cluster. The size of the Kafka Cluster is given in T-shirt sizes. Valid values are: XS, S
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#size KafkaCluster#size}
    */
    readonly size: string;
    /**
    * The desired Kafka Version. Supported versions: 3.8.0
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#version KafkaCluster#version}
    */
    readonly version: string;
    /**
    * connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#connections KafkaCluster#connections}
    */
    readonly connections: KafkaClusterConnections;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#timeouts KafkaCluster#timeouts}
    */
    readonly timeouts?: KafkaClusterTimeouts;
}
export interface KafkaClusterConnections {
    /**
    * The broker addresses of the Kafka Cluster. Can be empty, but must be present.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#broker_addresses KafkaCluster#broker_addresses}
    */
    readonly brokerAddresses: string[];
    /**
    * The datacenter to connect your Kafka Cluster to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#datacenter_id KafkaCluster#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * The numeric LAN ID to connect your Kafka Cluster to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#lan_id KafkaCluster#lan_id}
    */
    readonly lanId: string;
}
export declare function kafkaClusterConnectionsToTerraform(struct?: KafkaClusterConnectionsOutputReference | KafkaClusterConnections): any;
export declare function kafkaClusterConnectionsToHclTerraform(struct?: KafkaClusterConnectionsOutputReference | KafkaClusterConnections): any;
export declare class KafkaClusterConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KafkaClusterConnections | undefined;
    set internalValue(value: KafkaClusterConnections | undefined);
    private _brokerAddresses?;
    get brokerAddresses(): string[];
    set brokerAddresses(value: string[]);
    get brokerAddressesInput(): string[] | undefined;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
}
export interface KafkaClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#create KafkaCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#default KafkaCluster#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#delete KafkaCluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#update KafkaCluster#update}
    */
    readonly update?: string;
}
export declare function kafkaClusterTimeoutsToTerraform(struct?: KafkaClusterTimeouts | cdktf.IResolvable): any;
export declare function kafkaClusterTimeoutsToHclTerraform(struct?: KafkaClusterTimeouts | cdktf.IResolvable): any;
export declare class KafkaClusterTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KafkaClusterTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: KafkaClusterTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster ionoscloud_kafka_cluster}
*/
export declare class KafkaCluster extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_kafka_cluster";
    /**
    * Generates CDKTF code for importing a KafkaCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KafkaCluster to import
    * @param importFromId The id of the existing KafkaCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KafkaCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/kafka_cluster ionoscloud_kafka_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KafkaClusterConfig
    */
    constructor(scope: Construct, id: string, config: KafkaClusterConfig);
    get brokerAddresses(): string[];
    get id(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _size?;
    get size(): string;
    set size(value: string);
    get sizeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _connections;
    get connections(): KafkaClusterConnectionsOutputReference;
    putConnections(value: KafkaClusterConnections): void;
    get connectionsInput(): KafkaClusterConnections | undefined;
    private _timeouts;
    get timeouts(): KafkaClusterTimeoutsOutputReference;
    putTimeouts(value: KafkaClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | KafkaClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
