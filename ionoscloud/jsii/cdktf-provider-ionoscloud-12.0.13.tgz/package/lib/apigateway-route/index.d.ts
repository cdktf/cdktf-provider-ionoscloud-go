/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApigatewayRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the API Gateway that the route belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#gateway_id ApigatewayRoute#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * The HTTP methods that the route should match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#methods ApigatewayRoute#methods}
    */
    readonly methods: string[];
    /**
    * The name of the API Gateway Route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#name ApigatewayRoute#name}
    */
    readonly name: string;
    /**
    * The paths that the route should match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#paths ApigatewayRoute#paths}
    */
    readonly paths: string[];
    /**
    * This field specifies the protocol used by the ingress to route traffic to the backend service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#type ApigatewayRoute#type}
    */
    readonly type?: string;
    /**
    * To enable websocket support.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#websocket ApigatewayRoute#websocket}
    */
    readonly websocket?: boolean | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#timeouts ApigatewayRoute#timeouts}
    */
    readonly timeouts?: ApigatewayRouteTimeouts;
    /**
    * upstreams block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#upstreams ApigatewayRoute#upstreams}
    */
    readonly upstreams: ApigatewayRouteUpstreams[] | cdktf.IResolvable;
}
export interface ApigatewayRouteTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#create ApigatewayRoute#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#default ApigatewayRoute#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#delete ApigatewayRoute#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#update ApigatewayRoute#update}
    */
    readonly update?: string;
}
export declare function apigatewayRouteTimeoutsToTerraform(struct?: ApigatewayRouteTimeouts | cdktf.IResolvable): any;
export declare function apigatewayRouteTimeoutsToHclTerraform(struct?: ApigatewayRouteTimeouts | cdktf.IResolvable): any;
export declare class ApigatewayRouteTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApigatewayRouteTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ApigatewayRouteTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ApigatewayRouteUpstreams {
    /**
    * The host of the upstream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#host ApigatewayRoute#host}
    */
    readonly host: string;
    /**
    * The load balancer algorithm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#loadbalancer ApigatewayRoute#loadbalancer}
    */
    readonly loadbalancer?: string;
    /**
    * The port of the upstream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#port ApigatewayRoute#port}
    */
    readonly port?: number;
    /**
    * The target URL of the upstream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#scheme ApigatewayRoute#scheme}
    */
    readonly scheme?: string;
    /**
    * Weight with which to split traffic to the upstream.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#weight ApigatewayRoute#weight}
    */
    readonly weight?: number;
}
export declare function apigatewayRouteUpstreamsToTerraform(struct?: ApigatewayRouteUpstreams | cdktf.IResolvable): any;
export declare function apigatewayRouteUpstreamsToHclTerraform(struct?: ApigatewayRouteUpstreams | cdktf.IResolvable): any;
export declare class ApigatewayRouteUpstreamsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApigatewayRouteUpstreams | cdktf.IResolvable | undefined;
    set internalValue(value: ApigatewayRouteUpstreams | cdktf.IResolvable | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _loadbalancer?;
    get loadbalancer(): string;
    set loadbalancer(value: string);
    resetLoadbalancer(): void;
    get loadbalancerInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    resetWeight(): void;
    get weightInput(): number | undefined;
}
export declare class ApigatewayRouteUpstreamsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApigatewayRouteUpstreams[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApigatewayRouteUpstreamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route ionoscloud_apigateway_route}
*/
export declare class ApigatewayRoute extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_apigateway_route";
    /**
    * Generates CDKTF code for importing a ApigatewayRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApigatewayRoute to import
    * @param importFromId The id of the existing ApigatewayRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApigatewayRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/apigateway_route ionoscloud_apigateway_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApigatewayRouteConfig
    */
    constructor(scope: Construct, id: string, config: ApigatewayRouteConfig);
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    get id(): string;
    private _methods?;
    get methods(): string[];
    set methods(value: string[]);
    get methodsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    get pathsInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _websocket?;
    get websocket(): boolean | cdktf.IResolvable;
    set websocket(value: boolean | cdktf.IResolvable);
    resetWebsocket(): void;
    get websocketInput(): boolean | cdktf.IResolvable | undefined;
    private _timeouts;
    get timeouts(): ApigatewayRouteTimeoutsOutputReference;
    putTimeouts(value: ApigatewayRouteTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ApigatewayRouteTimeouts | undefined;
    private _upstreams;
    get upstreams(): ApigatewayRouteUpstreamsList;
    putUpstreams(value: ApigatewayRouteUpstreams[] | cdktf.IResolvable): void;
    get upstreamsInput(): cdktf.IResolvable | ApigatewayRouteUpstreams[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
