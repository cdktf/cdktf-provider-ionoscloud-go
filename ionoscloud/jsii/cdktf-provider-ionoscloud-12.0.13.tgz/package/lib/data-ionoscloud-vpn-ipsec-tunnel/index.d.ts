/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudVpnIpsecTunnelConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the IPSec Gateway that the tunnel belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_tunnel#gateway_id DataIonoscloudVpnIpsecTunnel#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * The ID of the IPSec Gateway Tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_tunnel#id DataIonoscloudVpnIpsecTunnel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the IPSec Gateway Tunnel. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/bhx, gb/lhr, us/ewr, us/las, us/mci, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_tunnel#location DataIonoscloudVpnIpsecTunnel#location}
    */
    readonly location?: string;
    /**
    * The human readable name of your IPSec Gateway Tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_tunnel#name DataIonoscloudVpnIpsecTunnel#name}
    */
    readonly name?: string;
}
export interface DataIonoscloudVpnIpsecTunnelAuth {
}
export declare function dataIonoscloudVpnIpsecTunnelAuthToTerraform(struct?: DataIonoscloudVpnIpsecTunnelAuth): any;
export declare function dataIonoscloudVpnIpsecTunnelAuthToHclTerraform(struct?: DataIonoscloudVpnIpsecTunnelAuth): any;
export declare class DataIonoscloudVpnIpsecTunnelAuthOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudVpnIpsecTunnelAuth | undefined;
    set internalValue(value: DataIonoscloudVpnIpsecTunnelAuth | undefined);
    get method(): string;
}
export declare class DataIonoscloudVpnIpsecTunnelAuthList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudVpnIpsecTunnelAuthOutputReference;
}
export interface DataIonoscloudVpnIpsecTunnelEsp {
}
export declare function dataIonoscloudVpnIpsecTunnelEspToTerraform(struct?: DataIonoscloudVpnIpsecTunnelEsp): any;
export declare function dataIonoscloudVpnIpsecTunnelEspToHclTerraform(struct?: DataIonoscloudVpnIpsecTunnelEsp): any;
export declare class DataIonoscloudVpnIpsecTunnelEspOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudVpnIpsecTunnelEsp | undefined;
    set internalValue(value: DataIonoscloudVpnIpsecTunnelEsp | undefined);
    get diffieHellmanGroup(): string;
    get encryptionAlgorithm(): string;
    get integrityAlgorithm(): string;
    get lifetime(): number;
}
export declare class DataIonoscloudVpnIpsecTunnelEspList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudVpnIpsecTunnelEspOutputReference;
}
export interface DataIonoscloudVpnIpsecTunnelIke {
}
export declare function dataIonoscloudVpnIpsecTunnelIkeToTerraform(struct?: DataIonoscloudVpnIpsecTunnelIke): any;
export declare function dataIonoscloudVpnIpsecTunnelIkeToHclTerraform(struct?: DataIonoscloudVpnIpsecTunnelIke): any;
export declare class DataIonoscloudVpnIpsecTunnelIkeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudVpnIpsecTunnelIke | undefined;
    set internalValue(value: DataIonoscloudVpnIpsecTunnelIke | undefined);
    get diffieHellmanGroup(): string;
    get encryptionAlgorithm(): string;
    get integrityAlgorithm(): string;
    get lifetime(): number;
}
export declare class DataIonoscloudVpnIpsecTunnelIkeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudVpnIpsecTunnelIkeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_tunnel ionoscloud_vpn_ipsec_tunnel}
*/
export declare class DataIonoscloudVpnIpsecTunnel extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_vpn_ipsec_tunnel";
    /**
    * Generates CDKTF code for importing a DataIonoscloudVpnIpsecTunnel resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudVpnIpsecTunnel to import
    * @param importFromId The id of the existing DataIonoscloudVpnIpsecTunnel that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_tunnel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudVpnIpsecTunnel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_ipsec_tunnel ionoscloud_vpn_ipsec_tunnel} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudVpnIpsecTunnelConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudVpnIpsecTunnelConfig);
    private _auth;
    get auth(): DataIonoscloudVpnIpsecTunnelAuthList;
    get cloudNetworkCidrs(): string[];
    get description(): string;
    private _esp;
    get esp(): DataIonoscloudVpnIpsecTunnelEspList;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ike;
    get ike(): DataIonoscloudVpnIpsecTunnelIkeList;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get peerNetworkCidrs(): string[];
    get remoteHost(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
