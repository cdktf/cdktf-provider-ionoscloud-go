/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VcpuServerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#availability_zone VcpuServer#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * The associated boot drive, if any. Must be the UUID of a bootable CDROM image that can be retrieved using the ionoscloud_image data source.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#boot_cdrom VcpuServer#boot_cdrom}
    */
    readonly bootCdrom?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#boot_image VcpuServer#boot_image}
    */
    readonly bootImage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#cores VcpuServer#cores}
    */
    readonly cores: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#datacenter_id VcpuServer#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#firewallrule_ids VcpuServer#firewallrule_ids}
    */
    readonly firewallruleIds?: string[];
    /**
    * The hostname of the resource. Allowed characters are a-z, 0-9 and - (minus). Hostname should not start with minus and should not be longer than 63 characters. If no value provided explicitly, it will be populated with the name of the server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#hostname VcpuServer#hostname}
    */
    readonly hostname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#id VcpuServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#image_name VcpuServer#image_name}
    */
    readonly imageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#image_password VcpuServer#image_password}
    */
    readonly imagePassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#name VcpuServer#name}
    */
    readonly name: string;
    /**
    * Activate or deactivate the Multi Queue feature on all NICs of this server. This feature is beneficial to enable when the NICs are experiencing performance issues (e.g. low throughput). Toggling this feature will also initiate a restart of the server. If the specified value is `true`, the feature will be activated; if it is not specified or set to `false`, the feature will be deactivated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#nic_multi_queue VcpuServer#nic_multi_queue}
    */
    readonly nicMultiQueue?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#ram VcpuServer#ram}
    */
    readonly ram: number;
    /**
    * The list of Security Group IDs for the server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#security_groups_ids VcpuServer#security_groups_ids}
    */
    readonly securityGroupsIds?: string[];
    /**
    * Public SSH keys are set on the image as authorized keys for appropriate SSH login to the instance using the corresponding private key. This field may only be set in creation requests. When reading, it always returns null. SSH keys are only supported if a public Linux image is used for the volume creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#ssh_keys VcpuServer#ssh_keys}
    */
    readonly sshKeys?: string[];
    /**
    * Sets the power state of the vcpu server. Possible values: `RUNNING` or `SHUTOFF`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#vm_state VcpuServer#vm_state}
    */
    readonly vmState?: string;
    /**
    * label block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#label VcpuServer#label}
    */
    readonly label?: VcpuServerLabel[] | cdktf.IResolvable;
    /**
    * nic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#nic VcpuServer#nic}
    */
    readonly nic?: VcpuServerNic;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#timeouts VcpuServer#timeouts}
    */
    readonly timeouts?: VcpuServerTimeouts;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#volume VcpuServer#volume}
    */
    readonly volume: VcpuServerVolume;
}
export interface VcpuServerLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#key VcpuServer#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#value VcpuServer#value}
    */
    readonly value: string;
}
export declare function vcpuServerLabelToTerraform(struct?: VcpuServerLabel | cdktf.IResolvable): any;
export declare function vcpuServerLabelToHclTerraform(struct?: VcpuServerLabel | cdktf.IResolvable): any;
export declare class VcpuServerLabelOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VcpuServerLabel | cdktf.IResolvable | undefined;
    set internalValue(value: VcpuServerLabel | cdktf.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class VcpuServerLabelList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VcpuServerLabel[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VcpuServerLabelOutputReference;
}
export interface VcpuServerNicFirewall {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#icmp_code VcpuServer#icmp_code}
    */
    readonly icmpCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#icmp_type VcpuServer#icmp_type}
    */
    readonly icmpType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#name VcpuServer#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#port_range_end VcpuServer#port_range_end}
    */
    readonly portRangeEnd?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#port_range_start VcpuServer#port_range_start}
    */
    readonly portRangeStart?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#protocol VcpuServer#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#source_ip VcpuServer#source_ip}
    */
    readonly sourceIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#source_mac VcpuServer#source_mac}
    */
    readonly sourceMac?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#target_ip VcpuServer#target_ip}
    */
    readonly targetIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#type VcpuServer#type}
    */
    readonly type?: string;
}
export declare function vcpuServerNicFirewallToTerraform(struct?: VcpuServerNicFirewall | cdktf.IResolvable): any;
export declare function vcpuServerNicFirewallToHclTerraform(struct?: VcpuServerNicFirewall | cdktf.IResolvable): any;
export declare class VcpuServerNicFirewallOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VcpuServerNicFirewall | cdktf.IResolvable | undefined;
    set internalValue(value: VcpuServerNicFirewall | cdktf.IResolvable | undefined);
    private _icmpCode?;
    get icmpCode(): string;
    set icmpCode(value: string);
    resetIcmpCode(): void;
    get icmpCodeInput(): string | undefined;
    private _icmpType?;
    get icmpType(): string;
    set icmpType(value: string);
    resetIcmpType(): void;
    get icmpTypeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _portRangeEnd?;
    get portRangeEnd(): number;
    set portRangeEnd(value: number);
    resetPortRangeEnd(): void;
    get portRangeEndInput(): number | undefined;
    private _portRangeStart?;
    get portRangeStart(): number;
    set portRangeStart(value: number);
    resetPortRangeStart(): void;
    get portRangeStartInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _sourceIp?;
    get sourceIp(): string;
    set sourceIp(value: string);
    resetSourceIp(): void;
    get sourceIpInput(): string | undefined;
    private _sourceMac?;
    get sourceMac(): string;
    set sourceMac(value: string);
    resetSourceMac(): void;
    get sourceMacInput(): string | undefined;
    private _targetIp?;
    get targetIp(): string;
    set targetIp(value: string);
    resetTargetIp(): void;
    get targetIpInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class VcpuServerNicFirewallList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VcpuServerNicFirewall[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VcpuServerNicFirewallOutputReference;
}
export interface VcpuServerNic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#dhcp VcpuServer#dhcp}
    */
    readonly dhcp?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#dhcpv6 VcpuServer#dhcpv6}
    */
    readonly dhcpv6?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#firewall_active VcpuServer#firewall_active}
    */
    readonly firewallActive?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#firewall_type VcpuServer#firewall_type}
    */
    readonly firewallType?: string;
    /**
    * Collection of IP addresses assigned to a nic. Explicitly assigned public IPs need to come from reserved IP blocks, Passing value null or empty array will assign an IP address automatically.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#ips VcpuServer#ips}
    */
    readonly ips?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#ipv6_cidr_block VcpuServer#ipv6_cidr_block}
    */
    readonly ipv6CidrBlock?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#ipv6_ips VcpuServer#ipv6_ips}
    */
    readonly ipv6Ips?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#lan VcpuServer#lan}
    */
    readonly lan: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#mac VcpuServer#mac}
    */
    readonly mac?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#name VcpuServer#name}
    */
    readonly name?: string;
    /**
    * The list of Security Group IDs for the NIC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#security_groups_ids VcpuServer#security_groups_ids}
    */
    readonly securityGroupsIds?: string[];
    /**
    * firewall block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#firewall VcpuServer#firewall}
    */
    readonly firewall?: VcpuServerNicFirewall[] | cdktf.IResolvable;
}
export declare function vcpuServerNicToTerraform(struct?: VcpuServerNicOutputReference | VcpuServerNic): any;
export declare function vcpuServerNicToHclTerraform(struct?: VcpuServerNicOutputReference | VcpuServerNic): any;
export declare class VcpuServerNicOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VcpuServerNic | undefined;
    set internalValue(value: VcpuServerNic | undefined);
    get deviceNumber(): number;
    private _dhcp?;
    get dhcp(): boolean | cdktf.IResolvable;
    set dhcp(value: boolean | cdktf.IResolvable);
    resetDhcp(): void;
    get dhcpInput(): boolean | cdktf.IResolvable | undefined;
    private _dhcpv6?;
    get dhcpv6(): boolean | cdktf.IResolvable;
    set dhcpv6(value: boolean | cdktf.IResolvable);
    resetDhcpv6(): void;
    get dhcpv6Input(): boolean | cdktf.IResolvable | undefined;
    private _firewallActive?;
    get firewallActive(): boolean | cdktf.IResolvable;
    set firewallActive(value: boolean | cdktf.IResolvable);
    resetFirewallActive(): void;
    get firewallActiveInput(): boolean | cdktf.IResolvable | undefined;
    private _firewallType?;
    get firewallType(): string;
    set firewallType(value: string);
    resetFirewallType(): void;
    get firewallTypeInput(): string | undefined;
    get id(): string;
    private _ips?;
    get ips(): string[];
    set ips(value: string[]);
    resetIps(): void;
    get ipsInput(): string[] | undefined;
    private _ipv6CidrBlock?;
    get ipv6CidrBlock(): string;
    set ipv6CidrBlock(value: string);
    resetIpv6CidrBlock(): void;
    get ipv6CidrBlockInput(): string | undefined;
    private _ipv6Ips?;
    get ipv6Ips(): string[];
    set ipv6Ips(value: string[]);
    resetIpv6Ips(): void;
    get ipv6IpsInput(): string[] | undefined;
    private _lan?;
    get lan(): number;
    set lan(value: number);
    get lanInput(): number | undefined;
    private _mac?;
    get mac(): string;
    set mac(value: string);
    resetMac(): void;
    get macInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get pciSlot(): number;
    private _securityGroupsIds?;
    get securityGroupsIds(): string[];
    set securityGroupsIds(value: string[]);
    resetSecurityGroupsIds(): void;
    get securityGroupsIdsInput(): string[] | undefined;
    private _firewall;
    get firewall(): VcpuServerNicFirewallList;
    putFirewall(value: VcpuServerNicFirewall[] | cdktf.IResolvable): void;
    resetFirewall(): void;
    get firewallInput(): cdktf.IResolvable | VcpuServerNicFirewall[] | undefined;
}
export interface VcpuServerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#create VcpuServer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#default VcpuServer#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#delete VcpuServer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#update VcpuServer#update}
    */
    readonly update?: string;
}
export declare function vcpuServerTimeoutsToTerraform(struct?: VcpuServerTimeouts | cdktf.IResolvable): any;
export declare function vcpuServerTimeoutsToHclTerraform(struct?: VcpuServerTimeouts | cdktf.IResolvable): any;
export declare class VcpuServerTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VcpuServerTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VcpuServerTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface VcpuServerVolume {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#availability_zone VcpuServer#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * The uuid of the Backup Unit that user has access to. The property is immutable and is only allowed to be set on a new volume creation. It is mandatory to provide either 'public image' or 'imageAlias' in conjunction with this property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#backup_unit_id VcpuServer#backup_unit_id}
    */
    readonly backupUnitId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#bus VcpuServer#bus}
    */
    readonly bus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#disk_type VcpuServer#disk_type}
    */
    readonly diskType: string;
    /**
    * If set to `true` will expose the serial id of the disk attached to the server. If set to `false` will not expose the serial id. Some operating systems or software solutions require the serial id to be exposed to work properly. Exposing the serial can influence licensed software (e.g. Windows) behavior
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#expose_serial VcpuServer#expose_serial}
    */
    readonly exposeSerial?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#licence_type VcpuServer#licence_type}
    */
    readonly licenceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#name VcpuServer#name}
    */
    readonly name?: string;
    /**
    * The size of the volume in GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#size VcpuServer#size}
    */
    readonly size?: number;
    /**
    * The cloud-init configuration for the volume as base64 encoded string. The property is immutable and is only allowed to be set on a new volume creation. It is mandatory to provide either 'public image' or 'imageAlias' that has cloud-init compatibility in conjunction with this property.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#user_data VcpuServer#user_data}
    */
    readonly userData?: string;
}
export declare function vcpuServerVolumeToTerraform(struct?: VcpuServerVolumeOutputReference | VcpuServerVolume): any;
export declare function vcpuServerVolumeToHclTerraform(struct?: VcpuServerVolumeOutputReference | VcpuServerVolume): any;
export declare class VcpuServerVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VcpuServerVolume | undefined;
    set internalValue(value: VcpuServerVolume | undefined);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _backupUnitId?;
    get backupUnitId(): string;
    set backupUnitId(value: string);
    resetBackupUnitId(): void;
    get backupUnitIdInput(): string | undefined;
    get bootServer(): string;
    private _bus?;
    get bus(): string;
    set bus(value: string);
    resetBus(): void;
    get busInput(): string | undefined;
    get cpuHotPlug(): cdktf.IResolvable;
    get deviceNumber(): number;
    get discVirtioHotPlug(): cdktf.IResolvable;
    get discVirtioHotUnplug(): cdktf.IResolvable;
    private _diskType?;
    get diskType(): string;
    set diskType(value: string);
    get diskTypeInput(): string | undefined;
    private _exposeSerial?;
    get exposeSerial(): boolean | cdktf.IResolvable;
    set exposeSerial(value: boolean | cdktf.IResolvable);
    resetExposeSerial(): void;
    get exposeSerialInput(): boolean | cdktf.IResolvable | undefined;
    private _licenceType?;
    get licenceType(): string;
    set licenceType(value: string);
    resetLicenceType(): void;
    get licenceTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get nicHotPlug(): cdktf.IResolvable;
    get nicHotUnplug(): cdktf.IResolvable;
    get pciSlot(): number;
    get ramHotPlug(): cdktf.IResolvable;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server ionoscloud_vcpu_server}
*/
export declare class VcpuServer extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_vcpu_server";
    /**
    * Generates CDKTF code for importing a VcpuServer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VcpuServer to import
    * @param importFromId The id of the existing VcpuServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VcpuServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vcpu_server ionoscloud_vcpu_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VcpuServerConfig
    */
    constructor(scope: Construct, id: string, config: VcpuServerConfig);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _bootCdrom?;
    get bootCdrom(): string;
    set bootCdrom(value: string);
    resetBootCdrom(): void;
    get bootCdromInput(): string | undefined;
    private _bootImage?;
    get bootImage(): string;
    set bootImage(value: string);
    resetBootImage(): void;
    get bootImageInput(): string | undefined;
    get bootVolume(): string;
    private _cores?;
    get cores(): number;
    set cores(value: number);
    get coresInput(): number | undefined;
    get cpuFamily(): string;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    get firewallruleId(): string;
    private _firewallruleIds?;
    get firewallruleIds(): string[];
    set firewallruleIds(value: string[]);
    resetFirewallruleIds(): void;
    get firewallruleIdsInput(): string[] | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    resetImageName(): void;
    get imageNameInput(): string | undefined;
    private _imagePassword?;
    get imagePassword(): string;
    set imagePassword(value: string);
    resetImagePassword(): void;
    get imagePasswordInput(): string | undefined;
    get inlineVolumeIds(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nicMultiQueue?;
    get nicMultiQueue(): boolean | cdktf.IResolvable;
    set nicMultiQueue(value: boolean | cdktf.IResolvable);
    resetNicMultiQueue(): void;
    get nicMultiQueueInput(): boolean | cdktf.IResolvable | undefined;
    get primaryIp(): string;
    get primaryNic(): string;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    get ramInput(): number | undefined;
    private _securityGroupsIds?;
    get securityGroupsIds(): string[];
    set securityGroupsIds(value: string[]);
    resetSecurityGroupsIds(): void;
    get securityGroupsIdsInput(): string[] | undefined;
    private _sshKeys?;
    get sshKeys(): string[];
    set sshKeys(value: string[]);
    resetSshKeys(): void;
    get sshKeysInput(): string[] | undefined;
    get type(): string;
    private _vmState?;
    get vmState(): string;
    set vmState(value: string);
    resetVmState(): void;
    get vmStateInput(): string | undefined;
    private _label;
    get label(): VcpuServerLabelList;
    putLabel(value: VcpuServerLabel[] | cdktf.IResolvable): void;
    resetLabel(): void;
    get labelInput(): cdktf.IResolvable | VcpuServerLabel[] | undefined;
    private _nic;
    get nic(): VcpuServerNicOutputReference;
    putNic(value: VcpuServerNic): void;
    resetNic(): void;
    get nicInput(): VcpuServerNic | undefined;
    private _timeouts;
    get timeouts(): VcpuServerTimeoutsOutputReference;
    putTimeouts(value: VcpuServerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VcpuServerTimeouts | undefined;
    private _volume;
    get volume(): VcpuServerVolumeOutputReference;
    putVolume(value: VcpuServerVolume): void;
    get volumeInput(): VcpuServerVolume | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
