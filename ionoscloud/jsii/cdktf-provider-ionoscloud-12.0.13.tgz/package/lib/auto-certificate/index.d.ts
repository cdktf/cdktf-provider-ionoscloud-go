/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AutoCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * The common name (DNS) of the certificate to issue. The common name needs to be part of a zone in IONOS Cloud DNS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#common_name AutoCertificate#common_name}
    */
    readonly commonName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#id AutoCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The key algorithm used to generate the certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#key_algorithm AutoCertificate#key_algorithm}
    */
    readonly keyAlgorithm: string;
    /**
    * The location of the auto-certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#location AutoCertificate#location}
    */
    readonly location: string;
    /**
    * A certificate name used for management purposes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#name AutoCertificate#name}
    */
    readonly name: string;
    /**
    * The certificate provider used to issue the certificates
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#provider_id AutoCertificate#provider_id}
    */
    readonly providerId: string;
    /**
    * Optional additional names to be added to the issued certificate. The additional names needs to be part of a zone in IONOS Cloud DNS
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#subject_alternative_names AutoCertificate#subject_alternative_names}
    */
    readonly subjectAlternativeNames?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#timeouts AutoCertificate#timeouts}
    */
    readonly timeouts?: AutoCertificateTimeouts;
}
export interface AutoCertificateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#create AutoCertificate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#default AutoCertificate#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#delete AutoCertificate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#update AutoCertificate#update}
    */
    readonly update?: string;
}
export declare function autoCertificateTimeoutsToTerraform(struct?: AutoCertificateTimeouts | cdktf.IResolvable): any;
export declare function autoCertificateTimeoutsToHclTerraform(struct?: AutoCertificateTimeouts | cdktf.IResolvable): any;
export declare class AutoCertificateTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoCertificateTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: AutoCertificateTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate ionoscloud_auto_certificate}
*/
export declare class AutoCertificate extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_auto_certificate";
    /**
    * Generates CDKTF code for importing a AutoCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutoCertificate to import
    * @param importFromId The id of the existing AutoCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutoCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate ionoscloud_auto_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutoCertificateConfig
    */
    constructor(scope: Construct, id: string, config: AutoCertificateConfig);
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    get commonNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyAlgorithm?;
    get keyAlgorithm(): string;
    set keyAlgorithm(value: string);
    get keyAlgorithmInput(): string | undefined;
    get lastIssuedCertificateId(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerId?;
    get providerId(): string;
    set providerId(value: string);
    get providerIdInput(): string | undefined;
    private _subjectAlternativeNames?;
    get subjectAlternativeNames(): string[];
    set subjectAlternativeNames(value: string[]);
    resetSubjectAlternativeNames(): void;
    get subjectAlternativeNamesInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): AutoCertificateTimeoutsOutputReference;
    putTimeouts(value: AutoCertificateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | AutoCertificateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
