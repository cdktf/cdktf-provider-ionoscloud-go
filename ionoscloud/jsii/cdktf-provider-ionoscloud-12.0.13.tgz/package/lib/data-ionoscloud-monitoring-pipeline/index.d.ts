/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudMonitoringPipelineConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the pipeline
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/monitoring_pipeline#id DataIonoscloudMonitoringPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the pipeline
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/monitoring_pipeline#location DataIonoscloudMonitoringPipeline#location}
    */
    readonly location?: string;
    /**
    * The name of the pipeline
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/monitoring_pipeline#name DataIonoscloudMonitoringPipeline#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/monitoring_pipeline ionoscloud_monitoring_pipeline}
*/
export declare class DataIonoscloudMonitoringPipeline extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_monitoring_pipeline";
    /**
    * Generates CDKTF code for importing a DataIonoscloudMonitoringPipeline resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudMonitoringPipeline to import
    * @param importFromId The id of the existing DataIonoscloudMonitoringPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/monitoring_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudMonitoringPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/monitoring_pipeline ionoscloud_monitoring_pipeline} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudMonitoringPipelineConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudMonitoringPipelineConfig);
    get grafanaEndpoint(): string;
    get httpEndpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
