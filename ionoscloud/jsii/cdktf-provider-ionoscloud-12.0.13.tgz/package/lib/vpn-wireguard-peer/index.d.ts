/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpnWireguardPeerConfig extends cdktf.TerraformMetaArguments {
    /**
    * The subnet CIDRs that are allowed to connect to the WireGuard Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#allowed_ips VpnWireguardPeer#allowed_ips}
    */
    readonly allowedIps: string[];
    /**
    * Human readable description of the WireGuard Gateway Peer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#description VpnWireguardPeer#description}
    */
    readonly description?: string;
    /**
    * The ID of the WireGuard Peer that the peer will connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#gateway_id VpnWireguardPeer#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#id VpnWireguardPeer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the WireGuard Peer. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/bhx, gb/lhr, us/ewr, us/las, us/mci, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#location VpnWireguardPeer#location}
    */
    readonly location?: string;
    /**
    * The human readable name of your WireGuard Gateway Peer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#name VpnWireguardPeer#name}
    */
    readonly name: string;
    /**
    * WireGuard public key of the connecting peer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#public_key VpnWireguardPeer#public_key}
    */
    readonly publicKey: string;
    /**
    * endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#endpoint VpnWireguardPeer#endpoint}
    */
    readonly endpoint?: VpnWireguardPeerEndpoint;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#timeouts VpnWireguardPeer#timeouts}
    */
    readonly timeouts?: VpnWireguardPeerTimeouts;
}
export interface VpnWireguardPeerEndpoint {
    /**
    * Hostname or IPV4 address that the WireGuard Server will connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#host VpnWireguardPeer#host}
    */
    readonly host: string;
    /**
    * Port that the WireGuard Server will connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#port VpnWireguardPeer#port}
    */
    readonly port?: number;
}
export declare function vpnWireguardPeerEndpointToTerraform(struct?: VpnWireguardPeerEndpointOutputReference | VpnWireguardPeerEndpoint): any;
export declare function vpnWireguardPeerEndpointToHclTerraform(struct?: VpnWireguardPeerEndpointOutputReference | VpnWireguardPeerEndpoint): any;
export declare class VpnWireguardPeerEndpointOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnWireguardPeerEndpoint | undefined;
    set internalValue(value: VpnWireguardPeerEndpoint | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface VpnWireguardPeerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#create VpnWireguardPeer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#default VpnWireguardPeer#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#delete VpnWireguardPeer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#update VpnWireguardPeer#update}
    */
    readonly update?: string;
}
export declare function vpnWireguardPeerTimeoutsToTerraform(struct?: VpnWireguardPeerTimeouts | cdktf.IResolvable): any;
export declare function vpnWireguardPeerTimeoutsToHclTerraform(struct?: VpnWireguardPeerTimeouts | cdktf.IResolvable): any;
export declare class VpnWireguardPeerTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnWireguardPeerTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VpnWireguardPeerTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer ionoscloud_vpn_wireguard_peer}
*/
export declare class VpnWireguardPeer extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_vpn_wireguard_peer";
    /**
    * Generates CDKTF code for importing a VpnWireguardPeer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpnWireguardPeer to import
    * @param importFromId The id of the existing VpnWireguardPeer that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpnWireguardPeer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_wireguard_peer ionoscloud_vpn_wireguard_peer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpnWireguardPeerConfig
    */
    constructor(scope: Construct, id: string, config: VpnWireguardPeerConfig);
    private _allowedIps?;
    get allowedIps(): string[];
    set allowedIps(value: string[]);
    get allowedIpsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
    get status(): string;
    private _endpoint;
    get endpoint(): VpnWireguardPeerEndpointOutputReference;
    putEndpoint(value: VpnWireguardPeerEndpoint): void;
    resetEndpoint(): void;
    get endpointInput(): VpnWireguardPeerEndpoint | undefined;
    private _timeouts;
    get timeouts(): VpnWireguardPeerTimeoutsOutputReference;
    putTimeouts(value: VpnWireguardPeerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VpnWireguardPeerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
