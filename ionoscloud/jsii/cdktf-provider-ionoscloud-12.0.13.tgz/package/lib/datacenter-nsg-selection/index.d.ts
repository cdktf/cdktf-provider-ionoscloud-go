/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DatacenterNsgSelectionConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Datacenter to which the NSG will be attached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#datacenter_id DatacenterNsgSelection#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#id DatacenterNsgSelection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of the NSG which will be attached to the datacenter. If an empty string is specified and a NSG was attached previously, it will be unset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#nsg_id DatacenterNsgSelection#nsg_id}
    */
    readonly nsgId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#timeouts DatacenterNsgSelection#timeouts}
    */
    readonly timeouts?: DatacenterNsgSelectionTimeouts;
}
export interface DatacenterNsgSelectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#create DatacenterNsgSelection#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#default DatacenterNsgSelection#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#delete DatacenterNsgSelection#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#update DatacenterNsgSelection#update}
    */
    readonly update?: string;
}
export declare function datacenterNsgSelectionTimeoutsToTerraform(struct?: DatacenterNsgSelectionTimeouts | cdktf.IResolvable): any;
export declare function datacenterNsgSelectionTimeoutsToHclTerraform(struct?: DatacenterNsgSelectionTimeouts | cdktf.IResolvable): any;
export declare class DatacenterNsgSelectionTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatacenterNsgSelectionTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DatacenterNsgSelectionTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection ionoscloud_datacenter_nsg_selection}
*/
export declare class DatacenterNsgSelection extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_datacenter_nsg_selection";
    /**
    * Generates CDKTF code for importing a DatacenterNsgSelection resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatacenterNsgSelection to import
    * @param importFromId The id of the existing DatacenterNsgSelection that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatacenterNsgSelection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/datacenter_nsg_selection ionoscloud_datacenter_nsg_selection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatacenterNsgSelectionConfig
    */
    constructor(scope: Construct, id: string, config: DatacenterNsgSelectionConfig);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _nsgId?;
    get nsgId(): string;
    set nsgId(value: string);
    get nsgIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DatacenterNsgSelectionTimeoutsOutputReference;
    putTimeouts(value: DatacenterNsgSelectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DatacenterNsgSelectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
