/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ContainerRegistryConfig extends cdktf.TerraformMetaArguments {
    /**
    * The subnet CIDRs that are allowed to connect to the registry. Specify 'a.b.c.d/32' for an individual IP address. __Note__: If this list is empty or not set, there are no restrictions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#api_subnet_allow_list ContainerRegistry#api_subnet_allow_list}
    */
    readonly apiSubnetAllowList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#id ContainerRegistry#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#location ContainerRegistry#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#name ContainerRegistry#name}
    */
    readonly name: string;
    /**
    * features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#features ContainerRegistry#features}
    */
    readonly features?: ContainerRegistryFeatures;
    /**
    * garbage_collection_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#garbage_collection_schedule ContainerRegistry#garbage_collection_schedule}
    */
    readonly garbageCollectionSchedule?: ContainerRegistryGarbageCollectionSchedule;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#timeouts ContainerRegistry#timeouts}
    */
    readonly timeouts?: ContainerRegistryTimeouts;
}
export interface ContainerRegistryStorageUsage {
}
export declare function containerRegistryStorageUsageToTerraform(struct?: ContainerRegistryStorageUsage): any;
export declare function containerRegistryStorageUsageToHclTerraform(struct?: ContainerRegistryStorageUsage): any;
export declare class ContainerRegistryStorageUsageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerRegistryStorageUsage | undefined;
    set internalValue(value: ContainerRegistryStorageUsage | undefined);
    get bytes(): number;
    get updatedAt(): string;
}
export declare class ContainerRegistryStorageUsageList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerRegistryStorageUsageOutputReference;
}
export interface ContainerRegistryFeatures {
    /**
    * Enables vulnerability scanning for images in the container registry. Note: this feature can incur additional charges
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#vulnerability_scanning ContainerRegistry#vulnerability_scanning}
    */
    readonly vulnerabilityScanning?: boolean | cdktf.IResolvable;
}
export declare function containerRegistryFeaturesToTerraform(struct?: ContainerRegistryFeaturesOutputReference | ContainerRegistryFeatures): any;
export declare function containerRegistryFeaturesToHclTerraform(struct?: ContainerRegistryFeaturesOutputReference | ContainerRegistryFeatures): any;
export declare class ContainerRegistryFeaturesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerRegistryFeatures | undefined;
    set internalValue(value: ContainerRegistryFeatures | undefined);
    private _vulnerabilityScanning?;
    get vulnerabilityScanning(): boolean | cdktf.IResolvable;
    set vulnerabilityScanning(value: boolean | cdktf.IResolvable);
    resetVulnerabilityScanning(): void;
    get vulnerabilityScanningInput(): boolean | cdktf.IResolvable | undefined;
}
export interface ContainerRegistryGarbageCollectionSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#days ContainerRegistry#days}
    */
    readonly days: string[];
    /**
    * UTC time of day e.g. 01:00:00 - as defined by partial-time - RFC3339
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#time ContainerRegistry#time}
    */
    readonly time: string;
}
export declare function containerRegistryGarbageCollectionScheduleToTerraform(struct?: ContainerRegistryGarbageCollectionScheduleOutputReference | ContainerRegistryGarbageCollectionSchedule): any;
export declare function containerRegistryGarbageCollectionScheduleToHclTerraform(struct?: ContainerRegistryGarbageCollectionScheduleOutputReference | ContainerRegistryGarbageCollectionSchedule): any;
export declare class ContainerRegistryGarbageCollectionScheduleOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerRegistryGarbageCollectionSchedule | undefined;
    set internalValue(value: ContainerRegistryGarbageCollectionSchedule | undefined);
    private _days?;
    get days(): string[];
    set days(value: string[]);
    get daysInput(): string[] | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
}
export interface ContainerRegistryTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#create ContainerRegistry#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#default ContainerRegistry#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#delete ContainerRegistry#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#update ContainerRegistry#update}
    */
    readonly update?: string;
}
export declare function containerRegistryTimeoutsToTerraform(struct?: ContainerRegistryTimeouts | cdktf.IResolvable): any;
export declare function containerRegistryTimeoutsToHclTerraform(struct?: ContainerRegistryTimeouts | cdktf.IResolvable): any;
export declare class ContainerRegistryTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerRegistryTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ContainerRegistryTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry ionoscloud_container_registry}
*/
export declare class ContainerRegistry extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_container_registry";
    /**
    * Generates CDKTF code for importing a ContainerRegistry resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ContainerRegistry to import
    * @param importFromId The id of the existing ContainerRegistry that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ContainerRegistry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry ionoscloud_container_registry} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContainerRegistryConfig
    */
    constructor(scope: Construct, id: string, config: ContainerRegistryConfig);
    private _apiSubnetAllowList?;
    get apiSubnetAllowList(): string[];
    set apiSubnetAllowList(value: string[]);
    resetApiSubnetAllowList(): void;
    get apiSubnetAllowListInput(): string[] | undefined;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storageUsage;
    get storageUsage(): ContainerRegistryStorageUsageList;
    private _features;
    get features(): ContainerRegistryFeaturesOutputReference;
    putFeatures(value: ContainerRegistryFeatures): void;
    resetFeatures(): void;
    get featuresInput(): ContainerRegistryFeatures | undefined;
    private _garbageCollectionSchedule;
    get garbageCollectionSchedule(): ContainerRegistryGarbageCollectionScheduleOutputReference;
    putGarbageCollectionSchedule(value: ContainerRegistryGarbageCollectionSchedule): void;
    resetGarbageCollectionSchedule(): void;
    get garbageCollectionScheduleInput(): ContainerRegistryGarbageCollectionSchedule | undefined;
    private _timeouts;
    get timeouts(): ContainerRegistryTimeoutsOutputReference;
    putTimeouts(value: ContainerRegistryTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ContainerRegistryTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
