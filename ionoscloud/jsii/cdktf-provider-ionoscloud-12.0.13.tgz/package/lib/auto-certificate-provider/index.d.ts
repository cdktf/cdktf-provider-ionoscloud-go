/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AutoCertificateProviderConfig extends cdktf.TerraformMetaArguments {
    /**
    * The email address of the certificate requester
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#email AutoCertificateProvider#email}
    */
    readonly email: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#id AutoCertificateProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the certificate provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#location AutoCertificateProvider#location}
    */
    readonly location?: string;
    /**
    * The name of the certificate provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#name AutoCertificateProvider#name}
    */
    readonly name: string;
    /**
    * The URL of the certificate provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#server AutoCertificateProvider#server}
    */
    readonly server: string;
    /**
    * external_account_binding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#external_account_binding AutoCertificateProvider#external_account_binding}
    */
    readonly externalAccountBinding?: AutoCertificateProviderExternalAccountBinding;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#timeouts AutoCertificateProvider#timeouts}
    */
    readonly timeouts?: AutoCertificateProviderTimeouts;
}
export interface AutoCertificateProviderExternalAccountBinding {
    /**
    * The key ID of the external account binding
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#key_id AutoCertificateProvider#key_id}
    */
    readonly keyId: string;
    /**
    * The secret of the external account binding
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#key_secret AutoCertificateProvider#key_secret}
    */
    readonly keySecret: string;
}
export declare function autoCertificateProviderExternalAccountBindingToTerraform(struct?: AutoCertificateProviderExternalAccountBindingOutputReference | AutoCertificateProviderExternalAccountBinding): any;
export declare function autoCertificateProviderExternalAccountBindingToHclTerraform(struct?: AutoCertificateProviderExternalAccountBindingOutputReference | AutoCertificateProviderExternalAccountBinding): any;
export declare class AutoCertificateProviderExternalAccountBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoCertificateProviderExternalAccountBinding | undefined;
    set internalValue(value: AutoCertificateProviderExternalAccountBinding | undefined);
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    private _keySecret?;
    get keySecret(): string;
    set keySecret(value: string);
    get keySecretInput(): string | undefined;
}
export interface AutoCertificateProviderTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#create AutoCertificateProvider#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#default AutoCertificateProvider#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#delete AutoCertificateProvider#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#update AutoCertificateProvider#update}
    */
    readonly update?: string;
}
export declare function autoCertificateProviderTimeoutsToTerraform(struct?: AutoCertificateProviderTimeouts | cdktf.IResolvable): any;
export declare function autoCertificateProviderTimeoutsToHclTerraform(struct?: AutoCertificateProviderTimeouts | cdktf.IResolvable): any;
export declare class AutoCertificateProviderTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutoCertificateProviderTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: AutoCertificateProviderTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider ionoscloud_auto_certificate_provider}
*/
export declare class AutoCertificateProvider extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_auto_certificate_provider";
    /**
    * Generates CDKTF code for importing a AutoCertificateProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutoCertificateProvider to import
    * @param importFromId The id of the existing AutoCertificateProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutoCertificateProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/auto_certificate_provider ionoscloud_auto_certificate_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutoCertificateProviderConfig
    */
    constructor(scope: Construct, id: string, config: AutoCertificateProviderConfig);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
    private _externalAccountBinding;
    get externalAccountBinding(): AutoCertificateProviderExternalAccountBindingOutputReference;
    putExternalAccountBinding(value: AutoCertificateProviderExternalAccountBinding): void;
    resetExternalAccountBinding(): void;
    get externalAccountBindingInput(): AutoCertificateProviderExternalAccountBinding | undefined;
    private _timeouts;
    get timeouts(): AutoCertificateProviderTimeoutsOutputReference;
    putTimeouts(value: AutoCertificateProviderTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | AutoCertificateProviderTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
