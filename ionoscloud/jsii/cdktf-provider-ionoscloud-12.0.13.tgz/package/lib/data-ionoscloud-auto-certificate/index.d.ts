/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudAutoCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the auto-certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#id DataIonoscloudAutoCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the auto-certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#location DataIonoscloudAutoCertificate#location}
    */
    readonly location: string;
    /**
    * The name of the auto-certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#name DataIonoscloudAutoCertificate#name}
    */
    readonly name?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#timeouts DataIonoscloudAutoCertificate#timeouts}
    */
    readonly timeouts?: DataIonoscloudAutoCertificateTimeouts;
}
export interface DataIonoscloudAutoCertificateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#create DataIonoscloudAutoCertificate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#default DataIonoscloudAutoCertificate#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#delete DataIonoscloudAutoCertificate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#update DataIonoscloudAutoCertificate#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudAutoCertificateTimeoutsToTerraform(struct?: DataIonoscloudAutoCertificateTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudAutoCertificateTimeoutsToHclTerraform(struct?: DataIonoscloudAutoCertificateTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudAutoCertificateTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudAutoCertificateTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudAutoCertificateTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate ionoscloud_auto_certificate}
*/
export declare class DataIonoscloudAutoCertificate extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_auto_certificate";
    /**
    * Generates CDKTF code for importing a DataIonoscloudAutoCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudAutoCertificate to import
    * @param importFromId The id of the existing DataIonoscloudAutoCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudAutoCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate ionoscloud_auto_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudAutoCertificateConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudAutoCertificateConfig);
    get commonName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keyAlgorithm(): string;
    get lastIssuedCertificateId(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get providerId(): string;
    get subjectAlternativeNames(): string[];
    private _timeouts;
    get timeouts(): DataIonoscloudAutoCertificateTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudAutoCertificateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudAutoCertificateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
