/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NfsClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The location of the Network File Storage Cluster. Available locations: 'de/fra, 'de/fra/2, 'de/txl, 'fr-par, 'gb-lhr, 'es/vit, 'us/las, 'us/ewr, 'us/mci'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#location NfsCluster#location}
    */
    readonly location?: string;
    /**
    * The name of the Network File Storage Cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#name NfsCluster#name}
    */
    readonly name: string;
    /**
    * The size of the Network File Storage Cluster. Minimum size is 2.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#size NfsCluster#size}
    */
    readonly size: number;
    /**
    * connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#connections NfsCluster#connections}
    */
    readonly connections: NfsClusterConnections;
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#nfs NfsCluster#nfs}
    */
    readonly nfs?: NfsClusterNfs;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#timeouts NfsCluster#timeouts}
    */
    readonly timeouts?: NfsClusterTimeouts;
}
export interface NfsClusterConnections {
    /**
    * The datacenter to connect your instance to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#datacenter_id NfsCluster#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * The IP address and subnet for your instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#ip_address NfsCluster#ip_address}
    */
    readonly ipAddress: string;
    /**
    * The numeric LAN ID to connect your instance to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#lan NfsCluster#lan}
    */
    readonly lan: string;
}
export declare function nfsClusterConnectionsToTerraform(struct?: NfsClusterConnectionsOutputReference | NfsClusterConnections): any;
export declare function nfsClusterConnectionsToHclTerraform(struct?: NfsClusterConnectionsOutputReference | NfsClusterConnections): any;
export declare class NfsClusterConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NfsClusterConnections | undefined;
    set internalValue(value: NfsClusterConnections | undefined);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _ipAddress?;
    get ipAddress(): string;
    set ipAddress(value: string);
    get ipAddressInput(): string | undefined;
    private _lan?;
    get lan(): string;
    set lan(value: string);
    get lanInput(): string | undefined;
}
export interface NfsClusterNfs {
    /**
    * The minimum Network File Storage version
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#min_version NfsCluster#min_version}
    */
    readonly minVersion?: string;
}
export declare function nfsClusterNfsToTerraform(struct?: NfsClusterNfsOutputReference | NfsClusterNfs): any;
export declare function nfsClusterNfsToHclTerraform(struct?: NfsClusterNfsOutputReference | NfsClusterNfs): any;
export declare class NfsClusterNfsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NfsClusterNfs | undefined;
    set internalValue(value: NfsClusterNfs | undefined);
    private _minVersion?;
    get minVersion(): string;
    set minVersion(value: string);
    resetMinVersion(): void;
    get minVersionInput(): string | undefined;
}
export interface NfsClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#create NfsCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#default NfsCluster#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#delete NfsCluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#update NfsCluster#update}
    */
    readonly update?: string;
}
export declare function nfsClusterTimeoutsToTerraform(struct?: NfsClusterTimeouts | cdktf.IResolvable): any;
export declare function nfsClusterTimeoutsToHclTerraform(struct?: NfsClusterTimeouts | cdktf.IResolvable): any;
export declare class NfsClusterTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NfsClusterTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: NfsClusterTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster ionoscloud_nfs_cluster}
*/
export declare class NfsCluster extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_nfs_cluster";
    /**
    * Generates CDKTF code for importing a NfsCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NfsCluster to import
    * @param importFromId The id of the existing NfsCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NfsCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/nfs_cluster ionoscloud_nfs_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NfsClusterConfig
    */
    constructor(scope: Construct, id: string, config: NfsClusterConfig);
    get id(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
    private _connections;
    get connections(): NfsClusterConnectionsOutputReference;
    putConnections(value: NfsClusterConnections): void;
    get connectionsInput(): NfsClusterConnections | undefined;
    private _nfs;
    get nfs(): NfsClusterNfsOutputReference;
    putNfs(value: NfsClusterNfs): void;
    resetNfs(): void;
    get nfsInput(): NfsClusterNfs | undefined;
    private _timeouts;
    get timeouts(): NfsClusterTimeoutsOutputReference;
    putTimeouts(value: NfsClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | NfsClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
