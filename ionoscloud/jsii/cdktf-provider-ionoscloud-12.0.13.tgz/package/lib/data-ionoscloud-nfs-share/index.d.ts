/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudNfsShareConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Network File Storage Cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#cluster_id DataIonoscloudNfsShare#cluster_id}
    */
    readonly clusterId: string;
    /**
    * The group ID that will own the exported directory. If not set, **anonymous** (`512`) will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#gid DataIonoscloudNfsShare#gid}
    */
    readonly gid?: number;
    /**
    * The ID of the Network File Storage Share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#id DataIonoscloudNfsShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the Network File Storage Cluster. Available locations: 'de/fra, 'de/fra/2, 'de/txl, 'fr-par, 'gb-lhr, 'es/vit, 'us/las, 'us/ewr, 'us/mci'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#location DataIonoscloudNfsShare#location}
    */
    readonly location?: string;
    /**
    * The name of the Network File Storage Share
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#name DataIonoscloudNfsShare#name}
    */
    readonly name?: string;
    /**
    * Whether partial matching is allowed or not when using the name filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#partial_match DataIonoscloudNfsShare#partial_match}
    */
    readonly partialMatch?: boolean | cdktf.IResolvable;
    /**
    * The quota in MiB for the export. The quota can restrict the amount of data that can be stored within the export. The quota can be disabled using `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#quota DataIonoscloudNfsShare#quota}
    */
    readonly quota?: number;
    /**
    * The user ID that will own the exported directory. If not set, **anonymous** (`512`) will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#uid DataIonoscloudNfsShare#uid}
    */
    readonly uid?: number;
    /**
    * client_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#client_groups DataIonoscloudNfsShare#client_groups}
    */
    readonly clientGroups?: DataIonoscloudNfsShareClientGroups[] | cdktf.IResolvable;
}
export interface DataIonoscloudNfsShareClientGroupsNfs {
    /**
    * The squash mode for the export. The squash mode can be: none - No squash mode. no mapping, root-anonymous - Map root user to anonymous uid, all-anonymous - Map all users to anonymous uid.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#squash DataIonoscloudNfsShare#squash}
    */
    readonly squash?: string;
}
export declare function dataIonoscloudNfsShareClientGroupsNfsToTerraform(struct?: DataIonoscloudNfsShareClientGroupsNfs | cdktf.IResolvable): any;
export declare function dataIonoscloudNfsShareClientGroupsNfsToHclTerraform(struct?: DataIonoscloudNfsShareClientGroupsNfs | cdktf.IResolvable): any;
export declare class DataIonoscloudNfsShareClientGroupsNfsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudNfsShareClientGroupsNfs | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudNfsShareClientGroupsNfs | cdktf.IResolvable | undefined);
    private _squash?;
    get squash(): string;
    set squash(value: string);
    resetSquash(): void;
    get squashInput(): string | undefined;
}
export declare class DataIonoscloudNfsShareClientGroupsNfsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataIonoscloudNfsShareClientGroupsNfs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudNfsShareClientGroupsNfsOutputReference;
}
export interface DataIonoscloudNfsShareClientGroups {
    /**
    * Optional description for the clients groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#description DataIonoscloudNfsShare#description}
    */
    readonly description?: string;
    /**
    * A singular host allowed to connect to the share. The host can be specified as IP address and can be either IPv4 or IPv6.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#hosts DataIonoscloudNfsShare#hosts}
    */
    readonly hosts?: string[];
    /**
    * The allowed host or network to which the export is being shared. The IP address can be either IPv4 or IPv6 and has to be given with CIDR notation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#ip_networks DataIonoscloudNfsShare#ip_networks}
    */
    readonly ipNetworks?: string[];
    /**
    * nfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#nfs DataIonoscloudNfsShare#nfs}
    */
    readonly nfs?: DataIonoscloudNfsShareClientGroupsNfs[] | cdktf.IResolvable;
}
export declare function dataIonoscloudNfsShareClientGroupsToTerraform(struct?: DataIonoscloudNfsShareClientGroups | cdktf.IResolvable): any;
export declare function dataIonoscloudNfsShareClientGroupsToHclTerraform(struct?: DataIonoscloudNfsShareClientGroups | cdktf.IResolvable): any;
export declare class DataIonoscloudNfsShareClientGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudNfsShareClientGroups | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudNfsShareClientGroups | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hosts?;
    get hosts(): string[];
    set hosts(value: string[]);
    resetHosts(): void;
    get hostsInput(): string[] | undefined;
    private _ipNetworks?;
    get ipNetworks(): string[];
    set ipNetworks(value: string[]);
    resetIpNetworks(): void;
    get ipNetworksInput(): string[] | undefined;
    private _nfs;
    get nfs(): DataIonoscloudNfsShareClientGroupsNfsList;
    putNfs(value: DataIonoscloudNfsShareClientGroupsNfs[] | cdktf.IResolvable): void;
    resetNfs(): void;
    get nfsInput(): cdktf.IResolvable | DataIonoscloudNfsShareClientGroupsNfs[] | undefined;
}
export declare class DataIonoscloudNfsShareClientGroupsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataIonoscloudNfsShareClientGroups[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudNfsShareClientGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share ionoscloud_nfs_share}
*/
export declare class DataIonoscloudNfsShare extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_nfs_share";
    /**
    * Generates CDKTF code for importing a DataIonoscloudNfsShare resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudNfsShare to import
    * @param importFromId The id of the existing DataIonoscloudNfsShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudNfsShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/nfs_share ionoscloud_nfs_share} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudNfsShareConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudNfsShareConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _gid?;
    get gid(): number;
    set gid(value: number);
    resetGid(): void;
    get gidInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get nfsPath(): string;
    private _partialMatch?;
    get partialMatch(): boolean | cdktf.IResolvable;
    set partialMatch(value: boolean | cdktf.IResolvable);
    resetPartialMatch(): void;
    get partialMatchInput(): boolean | cdktf.IResolvable | undefined;
    private _quota?;
    get quota(): number;
    set quota(value: number);
    resetQuota(): void;
    get quotaInput(): number | undefined;
    private _uid?;
    get uid(): number;
    set uid(value: number);
    resetUid(): void;
    get uidInput(): number | undefined;
    private _clientGroups;
    get clientGroups(): DataIonoscloudNfsShareClientGroupsList;
    putClientGroups(value: DataIonoscloudNfsShareClientGroups[] | cdktf.IResolvable): void;
    resetClientGroups(): void;
    get clientGroupsInput(): cdktf.IResolvable | DataIonoscloudNfsShareClientGroups[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
