/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudK8SClustersConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#id DataIonoscloudK8SClusters#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#filter DataIonoscloudK8SClusters#filter}
    */
    readonly filter?: DataIonoscloudK8SClustersFilter[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#timeouts DataIonoscloudK8SClusters#timeouts}
    */
    readonly timeouts?: DataIonoscloudK8SClustersTimeouts;
}
export interface DataIonoscloudK8SClustersClustersConfigClusters {
}
export declare function dataIonoscloudK8SClustersClustersConfigClustersToTerraform(struct?: DataIonoscloudK8SClustersClustersConfigClusters): any;
export declare function dataIonoscloudK8SClustersClustersConfigClustersToHclTerraform(struct?: DataIonoscloudK8SClustersClustersConfigClusters): any;
export declare class DataIonoscloudK8SClustersClustersConfigClustersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersClustersConfigClusters | undefined;
    set internalValue(value: DataIonoscloudK8SClustersClustersConfigClusters | undefined);
    private _cluster;
    get cluster(): cdktf.StringMap;
    get name(): string;
}
export declare class DataIonoscloudK8SClustersClustersConfigClustersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersClustersConfigClustersOutputReference;
}
export interface DataIonoscloudK8SClustersClustersConfigContexts {
}
export declare function dataIonoscloudK8SClustersClustersConfigContextsToTerraform(struct?: DataIonoscloudK8SClustersClustersConfigContexts): any;
export declare function dataIonoscloudK8SClustersClustersConfigContextsToHclTerraform(struct?: DataIonoscloudK8SClustersClustersConfigContexts): any;
export declare class DataIonoscloudK8SClustersClustersConfigContextsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersClustersConfigContexts | undefined;
    set internalValue(value: DataIonoscloudK8SClustersClustersConfigContexts | undefined);
    private _context;
    get context(): cdktf.StringMap;
    get name(): string;
}
export declare class DataIonoscloudK8SClustersClustersConfigContextsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersClustersConfigContextsOutputReference;
}
export interface DataIonoscloudK8SClustersClustersConfigUsers {
}
export declare function dataIonoscloudK8SClustersClustersConfigUsersToTerraform(struct?: DataIonoscloudK8SClustersClustersConfigUsers): any;
export declare function dataIonoscloudK8SClustersClustersConfigUsersToHclTerraform(struct?: DataIonoscloudK8SClustersClustersConfigUsers): any;
export declare class DataIonoscloudK8SClustersClustersConfigUsersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersClustersConfigUsers | undefined;
    set internalValue(value: DataIonoscloudK8SClustersClustersConfigUsers | undefined);
    get name(): string;
    private _user;
    get user(): cdktf.StringMap;
}
export declare class DataIonoscloudK8SClustersClustersConfigUsersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersClustersConfigUsersOutputReference;
}
export interface DataIonoscloudK8SClustersClustersConfig {
}
export declare function dataIonoscloudK8SClustersClustersConfigToTerraform(struct?: DataIonoscloudK8SClustersClustersConfig): any;
export declare function dataIonoscloudK8SClustersClustersConfigToHclTerraform(struct?: DataIonoscloudK8SClustersClustersConfig): any;
export declare class DataIonoscloudK8SClustersClustersConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersClustersConfig | undefined;
    set internalValue(value: DataIonoscloudK8SClustersClustersConfig | undefined);
    get apiVersion(): string;
    private _clusters;
    get clusters(): DataIonoscloudK8SClustersClustersConfigClustersList;
    private _contexts;
    get contexts(): DataIonoscloudK8SClustersClustersConfigContextsList;
    get currentContext(): string;
    get kind(): string;
    private _users;
    get users(): DataIonoscloudK8SClustersClustersConfigUsersList;
}
export declare class DataIonoscloudK8SClustersClustersConfigList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersClustersConfigOutputReference;
}
export interface DataIonoscloudK8SClustersClustersMaintenanceWindow {
}
export declare function dataIonoscloudK8SClustersClustersMaintenanceWindowToTerraform(struct?: DataIonoscloudK8SClustersClustersMaintenanceWindow): any;
export declare function dataIonoscloudK8SClustersClustersMaintenanceWindowToHclTerraform(struct?: DataIonoscloudK8SClustersClustersMaintenanceWindow): any;
export declare class DataIonoscloudK8SClustersClustersMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersClustersMaintenanceWindow | undefined;
    set internalValue(value: DataIonoscloudK8SClustersClustersMaintenanceWindow | undefined);
    get dayOfTheWeek(): string;
    get time(): string;
}
export declare class DataIonoscloudK8SClustersClustersMaintenanceWindowList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersClustersMaintenanceWindowOutputReference;
}
export interface DataIonoscloudK8SClustersClustersS3Buckets {
}
export declare function dataIonoscloudK8SClustersClustersS3BucketsToTerraform(struct?: DataIonoscloudK8SClustersClustersS3Buckets): any;
export declare function dataIonoscloudK8SClustersClustersS3BucketsToHclTerraform(struct?: DataIonoscloudK8SClustersClustersS3Buckets): any;
export declare class DataIonoscloudK8SClustersClustersS3BucketsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersClustersS3Buckets | undefined;
    set internalValue(value: DataIonoscloudK8SClustersClustersS3Buckets | undefined);
    get name(): string;
}
export declare class DataIonoscloudK8SClustersClustersS3BucketsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersClustersS3BucketsOutputReference;
}
export interface DataIonoscloudK8SClustersClusters {
}
export declare function dataIonoscloudK8SClustersClustersToTerraform(struct?: DataIonoscloudK8SClustersClusters): any;
export declare function dataIonoscloudK8SClustersClustersToHclTerraform(struct?: DataIonoscloudK8SClustersClusters): any;
export declare class DataIonoscloudK8SClustersClustersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersClusters | undefined;
    set internalValue(value: DataIonoscloudK8SClustersClusters | undefined);
    get apiSubnetAllowList(): string[];
    get availableUpgradeVersions(): string[];
    get caCrt(): string;
    private _config;
    get config(): DataIonoscloudK8SClustersClustersConfigList;
    get id(): string;
    get k8SVersion(): string;
    get kubeConfig(): string;
    get location(): string;
    private _maintenanceWindow;
    get maintenanceWindow(): DataIonoscloudK8SClustersClustersMaintenanceWindowList;
    get name(): string;
    get natGatewayIp(): string;
    get nodePools(): string[];
    get nodeSubnet(): string;
    get public(): cdktf.IResolvable;
    private _s3Buckets;
    get s3Buckets(): DataIonoscloudK8SClustersClustersS3BucketsList;
    get server(): string;
    get state(): string;
    private _userTokens;
    get userTokens(): cdktf.StringMap;
    get viableNodePoolVersions(): string[];
}
export declare class DataIonoscloudK8SClustersClustersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersClustersOutputReference;
}
export interface DataIonoscloudK8SClustersFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#name DataIonoscloudK8SClusters#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#value DataIonoscloudK8SClusters#value}
    */
    readonly value: string;
}
export declare function dataIonoscloudK8SClustersFilterToTerraform(struct?: DataIonoscloudK8SClustersFilter | cdktf.IResolvable): any;
export declare function dataIonoscloudK8SClustersFilterToHclTerraform(struct?: DataIonoscloudK8SClustersFilter | cdktf.IResolvable): any;
export declare class DataIonoscloudK8SClustersFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudK8SClustersFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudK8SClustersFilter | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataIonoscloudK8SClustersFilterList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataIonoscloudK8SClustersFilter[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudK8SClustersFilterOutputReference;
}
export interface DataIonoscloudK8SClustersTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#create DataIonoscloudK8SClusters#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#default DataIonoscloudK8SClusters#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#delete DataIonoscloudK8SClusters#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#update DataIonoscloudK8SClusters#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudK8SClustersTimeoutsToTerraform(struct?: DataIonoscloudK8SClustersTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudK8SClustersTimeoutsToHclTerraform(struct?: DataIonoscloudK8SClustersTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudK8SClustersTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudK8SClustersTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudK8SClustersTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters ionoscloud_k8s_clusters}
*/
export declare class DataIonoscloudK8SClusters extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_k8s_clusters";
    /**
    * Generates CDKTF code for importing a DataIonoscloudK8SClusters resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudK8SClusters to import
    * @param importFromId The id of the existing DataIonoscloudK8SClusters that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudK8SClusters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/k8s_clusters ionoscloud_k8s_clusters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudK8SClustersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudK8SClustersConfig);
    private _clusters;
    get clusters(): DataIonoscloudK8SClustersClustersList;
    get entries(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _filter;
    get filter(): DataIonoscloudK8SClustersFilterList;
    putFilter(value: DataIonoscloudK8SClustersFilter[] | cdktf.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataIonoscloudK8SClustersFilter[] | undefined;
    private _timeouts;
    get timeouts(): DataIonoscloudK8SClustersTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudK8SClustersTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudK8SClustersTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
