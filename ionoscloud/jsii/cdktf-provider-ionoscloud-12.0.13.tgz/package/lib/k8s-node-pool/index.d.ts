/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface K8SNodePoolConfig extends cdktf.TerraformMetaArguments {
    /**
    * When set to true, allows the update of immutable fields by destroying and re-creating the node pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#allow_replace K8SNodePool#allow_replace}
    */
    readonly allowReplace?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#annotations K8SNodePool#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * The compute availability zone in which the nodes should exist
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#availability_zone K8SNodePool#availability_zone}
    */
    readonly availabilityZone: string;
    /**
    * CPU cores count
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#cores_count K8SNodePool#cores_count}
    */
    readonly coresCount: number;
    /**
    * CPU Family
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#cpu_family K8SNodePool#cpu_family}
    */
    readonly cpuFamily?: string;
    /**
    * The UUID of the VDC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#datacenter_id K8SNodePool#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#id K8SNodePool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The UUID of an existing kubernetes cluster
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#k8s_cluster_id K8SNodePool#k8s_cluster_id}
    */
    readonly k8SClusterId: string;
    /**
    * The desired Kubernetes Version. For supported values, please check the API documentation. Downgrades are not supported. The provider will ignore downgrades of patch level.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#k8s_version K8SNodePool#k8s_version}
    */
    readonly k8SVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#labels K8SNodePool#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The desired name for the node pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#name K8SNodePool#name}
    */
    readonly name: string;
    /**
    * The number of nodes in this node pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#node_count K8SNodePool#node_count}
    */
    readonly nodeCount: number;
    /**
    * A list of fixed IPs. Cannot be set on private clusters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#public_ips K8SNodePool#public_ips}
    */
    readonly publicIps?: string[];
    /**
    * The amount of RAM in MB
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#ram_size K8SNodePool#ram_size}
    */
    readonly ramSize: number;
    /**
    * The server type for the compute engine
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#server_type K8SNodePool#server_type}
    */
    readonly serverType?: string;
    /**
    * The total allocated storage capacity of a node in GB
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#storage_size K8SNodePool#storage_size}
    */
    readonly storageSize: number;
    /**
    * Storage type to use
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#storage_type K8SNodePool#storage_type}
    */
    readonly storageType: string;
    /**
    * auto_scaling block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#auto_scaling K8SNodePool#auto_scaling}
    */
    readonly autoScaling?: K8SNodePoolAutoScaling;
    /**
    * lans block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#lans K8SNodePool#lans}
    */
    readonly lans?: K8SNodePoolLans[] | cdktf.IResolvable;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#maintenance_window K8SNodePool#maintenance_window}
    */
    readonly maintenanceWindow?: K8SNodePoolMaintenanceWindow;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#timeouts K8SNodePool#timeouts}
    */
    readonly timeouts?: K8SNodePoolTimeouts;
}
export interface K8SNodePoolAutoScaling {
    /**
    * The maximum number of worker nodes that the node pool can scale to. Should be greater than min_node_count
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#max_node_count K8SNodePool#max_node_count}
    */
    readonly maxNodeCount: number;
    /**
    * The minimum number of worker nodes the node pool can scale down to. Should be less than max_node_count
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#min_node_count K8SNodePool#min_node_count}
    */
    readonly minNodeCount: number;
}
export declare function k8SNodePoolAutoScalingToTerraform(struct?: K8SNodePoolAutoScalingOutputReference | K8SNodePoolAutoScaling): any;
export declare function k8SNodePoolAutoScalingToHclTerraform(struct?: K8SNodePoolAutoScalingOutputReference | K8SNodePoolAutoScaling): any;
export declare class K8SNodePoolAutoScalingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): K8SNodePoolAutoScaling | undefined;
    set internalValue(value: K8SNodePoolAutoScaling | undefined);
    private _maxNodeCount?;
    get maxNodeCount(): number;
    set maxNodeCount(value: number);
    get maxNodeCountInput(): number | undefined;
    private _minNodeCount?;
    get minNodeCount(): number;
    set minNodeCount(value: number);
    get minNodeCountInput(): number | undefined;
}
export interface K8SNodePoolLansRoutes {
    /**
    * IPv4 or IPv6 Gateway IP for the route
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#gateway_ip K8SNodePool#gateway_ip}
    */
    readonly gatewayIp: string;
    /**
    * IPv4 or IPv6 CIDR to be routed via the interface
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#network K8SNodePool#network}
    */
    readonly network: string;
}
export declare function k8SNodePoolLansRoutesToTerraform(struct?: K8SNodePoolLansRoutes | cdktf.IResolvable): any;
export declare function k8SNodePoolLansRoutesToHclTerraform(struct?: K8SNodePoolLansRoutes | cdktf.IResolvable): any;
export declare class K8SNodePoolLansRoutesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): K8SNodePoolLansRoutes | cdktf.IResolvable | undefined;
    set internalValue(value: K8SNodePoolLansRoutes | cdktf.IResolvable | undefined);
    private _gatewayIp?;
    get gatewayIp(): string;
    set gatewayIp(value: string);
    get gatewayIpInput(): string | undefined;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
}
export declare class K8SNodePoolLansRoutesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: K8SNodePoolLansRoutes[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): K8SNodePoolLansRoutesOutputReference;
}
export interface K8SNodePoolLans {
    /**
    * Indicates if the Kubernetes Node Pool LAN will reserve an IP using DHCP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#dhcp K8SNodePool#dhcp}
    */
    readonly dhcp?: boolean | cdktf.IResolvable;
    /**
    * The LAN ID of an existing LAN at the related datacenter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#id K8SNodePool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: number;
    /**
    * routes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#routes K8SNodePool#routes}
    */
    readonly routes?: K8SNodePoolLansRoutes[] | cdktf.IResolvable;
}
export declare function k8SNodePoolLansToTerraform(struct?: K8SNodePoolLans | cdktf.IResolvable): any;
export declare function k8SNodePoolLansToHclTerraform(struct?: K8SNodePoolLans | cdktf.IResolvable): any;
export declare class K8SNodePoolLansOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): K8SNodePoolLans | cdktf.IResolvable | undefined;
    set internalValue(value: K8SNodePoolLans | cdktf.IResolvable | undefined);
    private _dhcp?;
    get dhcp(): boolean | cdktf.IResolvable;
    set dhcp(value: boolean | cdktf.IResolvable);
    resetDhcp(): void;
    get dhcpInput(): boolean | cdktf.IResolvable | undefined;
    private _id?;
    get id(): number;
    set id(value: number);
    get idInput(): number | undefined;
    private _routes;
    get routes(): K8SNodePoolLansRoutesList;
    putRoutes(value: K8SNodePoolLansRoutes[] | cdktf.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktf.IResolvable | K8SNodePoolLansRoutes[] | undefined;
}
export declare class K8SNodePoolLansList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: K8SNodePoolLans[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): K8SNodePoolLansOutputReference;
}
export interface K8SNodePoolMaintenanceWindow {
    /**
    * Day of the week when maintenance is allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#day_of_the_week K8SNodePool#day_of_the_week}
    */
    readonly dayOfTheWeek: string;
    /**
    * A clock time in the day when maintenance is allowed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#time K8SNodePool#time}
    */
    readonly time: string;
}
export declare function k8SNodePoolMaintenanceWindowToTerraform(struct?: K8SNodePoolMaintenanceWindowOutputReference | K8SNodePoolMaintenanceWindow): any;
export declare function k8SNodePoolMaintenanceWindowToHclTerraform(struct?: K8SNodePoolMaintenanceWindowOutputReference | K8SNodePoolMaintenanceWindow): any;
export declare class K8SNodePoolMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): K8SNodePoolMaintenanceWindow | undefined;
    set internalValue(value: K8SNodePoolMaintenanceWindow | undefined);
    private _dayOfTheWeek?;
    get dayOfTheWeek(): string;
    set dayOfTheWeek(value: string);
    get dayOfTheWeekInput(): string | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
}
export interface K8SNodePoolTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#create K8SNodePool#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#default K8SNodePool#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#delete K8SNodePool#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#update K8SNodePool#update}
    */
    readonly update?: string;
}
export declare function k8SNodePoolTimeoutsToTerraform(struct?: K8SNodePoolTimeouts | cdktf.IResolvable): any;
export declare function k8SNodePoolTimeoutsToHclTerraform(struct?: K8SNodePoolTimeouts | cdktf.IResolvable): any;
export declare class K8SNodePoolTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): K8SNodePoolTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: K8SNodePoolTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool ionoscloud_k8s_node_pool}
*/
export declare class K8SNodePool extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_k8s_node_pool";
    /**
    * Generates CDKTF code for importing a K8SNodePool resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the K8SNodePool to import
    * @param importFromId The id of the existing K8SNodePool that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the K8SNodePool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/k8s_node_pool ionoscloud_k8s_node_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options K8SNodePoolConfig
    */
    constructor(scope: Construct, id: string, config: K8SNodePoolConfig);
    private _allowReplace?;
    get allowReplace(): boolean | cdktf.IResolvable;
    set allowReplace(value: boolean | cdktf.IResolvable);
    resetAllowReplace(): void;
    get allowReplaceInput(): boolean | cdktf.IResolvable | undefined;
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    get availabilityZoneInput(): string | undefined;
    private _coresCount?;
    get coresCount(): number;
    set coresCount(value: number);
    get coresCountInput(): number | undefined;
    private _cpuFamily?;
    get cpuFamily(): string;
    set cpuFamily(value: string);
    resetCpuFamily(): void;
    get cpuFamilyInput(): string | undefined;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _k8SClusterId?;
    get k8SClusterId(): string;
    set k8SClusterId(value: string);
    get k8SClusterIdInput(): string | undefined;
    private _k8SVersion?;
    get k8SVersion(): string;
    set k8SVersion(value: string);
    get k8SVersionInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeCount?;
    get nodeCount(): number;
    set nodeCount(value: number);
    get nodeCountInput(): number | undefined;
    private _publicIps?;
    get publicIps(): string[];
    set publicIps(value: string[]);
    resetPublicIps(): void;
    get publicIpsInput(): string[] | undefined;
    private _ramSize?;
    get ramSize(): number;
    set ramSize(value: number);
    get ramSizeInput(): number | undefined;
    private _serverType?;
    get serverType(): string;
    set serverType(value: string);
    resetServerType(): void;
    get serverTypeInput(): string | undefined;
    private _storageSize?;
    get storageSize(): number;
    set storageSize(value: number);
    get storageSizeInput(): number | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    get storageTypeInput(): string | undefined;
    private _autoScaling;
    get autoScaling(): K8SNodePoolAutoScalingOutputReference;
    putAutoScaling(value: K8SNodePoolAutoScaling): void;
    resetAutoScaling(): void;
    get autoScalingInput(): K8SNodePoolAutoScaling | undefined;
    private _lans;
    get lans(): K8SNodePoolLansList;
    putLans(value: K8SNodePoolLans[] | cdktf.IResolvable): void;
    resetLans(): void;
    get lansInput(): cdktf.IResolvable | K8SNodePoolLans[] | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): K8SNodePoolMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: K8SNodePoolMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): K8SNodePoolMaintenanceWindow | undefined;
    private _timeouts;
    get timeouts(): K8SNodePoolTimeoutsOutputReference;
    putTimeouts(value: K8SNodePoolTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | K8SNodePoolTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
