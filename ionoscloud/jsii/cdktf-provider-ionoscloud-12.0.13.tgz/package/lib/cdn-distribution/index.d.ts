/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CdnDistributionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the certificate to use for the distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#certificate_id CdnDistribution#certificate_id}
    */
    readonly certificateId?: string;
    /**
    * The domain of the distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#domain CdnDistribution#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#id CdnDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * routing_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#routing_rules CdnDistribution#routing_rules}
    */
    readonly routingRules: CdnDistributionRoutingRules[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#timeouts CdnDistribution#timeouts}
    */
    readonly timeouts?: CdnDistributionTimeouts;
}
export interface CdnDistributionRoutingRulesUpstreamGeoRestrictions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#allow_list CdnDistribution#allow_list}
    */
    readonly allowList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#block_list CdnDistribution#block_list}
    */
    readonly blockList?: string[];
}
export declare function cdnDistributionRoutingRulesUpstreamGeoRestrictionsToTerraform(struct?: CdnDistributionRoutingRulesUpstreamGeoRestrictionsOutputReference | CdnDistributionRoutingRulesUpstreamGeoRestrictions): any;
export declare function cdnDistributionRoutingRulesUpstreamGeoRestrictionsToHclTerraform(struct?: CdnDistributionRoutingRulesUpstreamGeoRestrictionsOutputReference | CdnDistributionRoutingRulesUpstreamGeoRestrictions): any;
export declare class CdnDistributionRoutingRulesUpstreamGeoRestrictionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionRoutingRulesUpstreamGeoRestrictions | undefined;
    set internalValue(value: CdnDistributionRoutingRulesUpstreamGeoRestrictions | undefined);
    private _allowList?;
    get allowList(): string[];
    set allowList(value: string[]);
    resetAllowList(): void;
    get allowListInput(): string[] | undefined;
    private _blockList?;
    get blockList(): string[];
    set blockList(value: string[]);
    resetBlockList(): void;
    get blockListInput(): string[] | undefined;
}
export interface CdnDistributionRoutingRulesUpstream {
    /**
    * Enable or disable caching. If enabled, the CDN will cache the responses from the upstream host. Subsequent requests for the same resource will be served from the cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#caching CdnDistribution#caching}
    */
    readonly caching: boolean | cdktf.IResolvable;
    /**
    * The upstream host that handles the requests if not already cached. This host will be protected by the WAF if the option is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#host CdnDistribution#host}
    */
    readonly host: string;
    /**
    * Rate limit class that will be applied to limit the number of incoming requests per IP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#rate_limit_class CdnDistribution#rate_limit_class}
    */
    readonly rateLimitClass: string;
    /**
    * The SNI (Server Name Indication) mode of the upstream host. It supports two modes: 'distribution' and 'origin', for more information about these modes please check the resource docs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#sni_mode CdnDistribution#sni_mode}
    */
    readonly sniMode: string;
    /**
    * Enable or disable WAF to protect the upstream host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#waf CdnDistribution#waf}
    */
    readonly waf: boolean | cdktf.IResolvable;
    /**
    * geo_restrictions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#geo_restrictions CdnDistribution#geo_restrictions}
    */
    readonly geoRestrictions?: CdnDistributionRoutingRulesUpstreamGeoRestrictions;
}
export declare function cdnDistributionRoutingRulesUpstreamToTerraform(struct?: CdnDistributionRoutingRulesUpstreamOutputReference | CdnDistributionRoutingRulesUpstream): any;
export declare function cdnDistributionRoutingRulesUpstreamToHclTerraform(struct?: CdnDistributionRoutingRulesUpstreamOutputReference | CdnDistributionRoutingRulesUpstream): any;
export declare class CdnDistributionRoutingRulesUpstreamOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionRoutingRulesUpstream | undefined;
    set internalValue(value: CdnDistributionRoutingRulesUpstream | undefined);
    private _caching?;
    get caching(): boolean | cdktf.IResolvable;
    set caching(value: boolean | cdktf.IResolvable);
    get cachingInput(): boolean | cdktf.IResolvable | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _rateLimitClass?;
    get rateLimitClass(): string;
    set rateLimitClass(value: string);
    get rateLimitClassInput(): string | undefined;
    private _sniMode?;
    get sniMode(): string;
    set sniMode(value: string);
    get sniModeInput(): string | undefined;
    private _waf?;
    get waf(): boolean | cdktf.IResolvable;
    set waf(value: boolean | cdktf.IResolvable);
    get wafInput(): boolean | cdktf.IResolvable | undefined;
    private _geoRestrictions;
    get geoRestrictions(): CdnDistributionRoutingRulesUpstreamGeoRestrictionsOutputReference;
    putGeoRestrictions(value: CdnDistributionRoutingRulesUpstreamGeoRestrictions): void;
    resetGeoRestrictions(): void;
    get geoRestrictionsInput(): CdnDistributionRoutingRulesUpstreamGeoRestrictions | undefined;
}
export interface CdnDistributionRoutingRules {
    /**
    * The prefix of the routing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#prefix CdnDistribution#prefix}
    */
    readonly prefix: string;
    /**
    * The scheme of the routing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#scheme CdnDistribution#scheme}
    */
    readonly scheme: string;
    /**
    * upstream block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#upstream CdnDistribution#upstream}
    */
    readonly upstream: CdnDistributionRoutingRulesUpstream;
}
export declare function cdnDistributionRoutingRulesToTerraform(struct?: CdnDistributionRoutingRules | cdktf.IResolvable): any;
export declare function cdnDistributionRoutingRulesToHclTerraform(struct?: CdnDistributionRoutingRules | cdktf.IResolvable): any;
export declare class CdnDistributionRoutingRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnDistributionRoutingRules | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionRoutingRules | cdktf.IResolvable | undefined);
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    get schemeInput(): string | undefined;
    private _upstream;
    get upstream(): CdnDistributionRoutingRulesUpstreamOutputReference;
    putUpstream(value: CdnDistributionRoutingRulesUpstream): void;
    get upstreamInput(): CdnDistributionRoutingRulesUpstream | undefined;
}
export declare class CdnDistributionRoutingRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CdnDistributionRoutingRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnDistributionRoutingRulesOutputReference;
}
export interface CdnDistributionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#create CdnDistribution#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#default CdnDistribution#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#delete CdnDistribution#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#update CdnDistribution#update}
    */
    readonly update?: string;
}
export declare function cdnDistributionTimeoutsToTerraform(struct?: CdnDistributionTimeouts | cdktf.IResolvable): any;
export declare function cdnDistributionTimeoutsToHclTerraform(struct?: CdnDistributionTimeouts | cdktf.IResolvable): any;
export declare class CdnDistributionTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution ionoscloud_cdn_distribution}
*/
export declare class CdnDistribution extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_cdn_distribution";
    /**
    * Generates CDKTF code for importing a CdnDistribution resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CdnDistribution to import
    * @param importFromId The id of the existing CdnDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CdnDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/cdn_distribution ionoscloud_cdn_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnDistributionConfig
    */
    constructor(scope: Construct, id: string, config: CdnDistributionConfig);
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    resetCertificateId(): void;
    get certificateIdInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get publicEndpointV4(): string;
    get publicEndpointV6(): string;
    get resourceUrn(): string;
    private _routingRules;
    get routingRules(): CdnDistributionRoutingRulesList;
    putRoutingRules(value: CdnDistributionRoutingRules[] | cdktf.IResolvable): void;
    get routingRulesInput(): cdktf.IResolvable | CdnDistributionRoutingRules[] | undefined;
    private _timeouts;
    get timeouts(): CdnDistributionTimeoutsOutputReference;
    putTimeouts(value: CdnDistributionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | CdnDistributionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
