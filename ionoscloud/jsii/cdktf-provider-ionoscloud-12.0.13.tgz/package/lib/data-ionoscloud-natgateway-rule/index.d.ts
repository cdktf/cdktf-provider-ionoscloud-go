/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudNatgatewayRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#datacenter_id DataIonoscloudNatgatewayRule#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#id DataIonoscloudNatgatewayRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#name DataIonoscloudNatgatewayRule#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#natgateway_id DataIonoscloudNatgatewayRule#natgateway_id}
    */
    readonly natgatewayId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#timeouts DataIonoscloudNatgatewayRule#timeouts}
    */
    readonly timeouts?: DataIonoscloudNatgatewayRuleTimeouts;
}
export interface DataIonoscloudNatgatewayRuleTargetPortRange {
}
export declare function dataIonoscloudNatgatewayRuleTargetPortRangeToTerraform(struct?: DataIonoscloudNatgatewayRuleTargetPortRange): any;
export declare function dataIonoscloudNatgatewayRuleTargetPortRangeToHclTerraform(struct?: DataIonoscloudNatgatewayRuleTargetPortRange): any;
export declare class DataIonoscloudNatgatewayRuleTargetPortRangeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudNatgatewayRuleTargetPortRange | undefined;
    set internalValue(value: DataIonoscloudNatgatewayRuleTargetPortRange | undefined);
    get end(): number;
    get start(): number;
}
export declare class DataIonoscloudNatgatewayRuleTargetPortRangeList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudNatgatewayRuleTargetPortRangeOutputReference;
}
export interface DataIonoscloudNatgatewayRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#create DataIonoscloudNatgatewayRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#default DataIonoscloudNatgatewayRule#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#delete DataIonoscloudNatgatewayRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#update DataIonoscloudNatgatewayRule#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudNatgatewayRuleTimeoutsToTerraform(struct?: DataIonoscloudNatgatewayRuleTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudNatgatewayRuleTimeoutsToHclTerraform(struct?: DataIonoscloudNatgatewayRuleTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudNatgatewayRuleTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudNatgatewayRuleTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudNatgatewayRuleTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule ionoscloud_natgateway_rule}
*/
export declare class DataIonoscloudNatgatewayRule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_natgateway_rule";
    /**
    * Generates CDKTF code for importing a DataIonoscloudNatgatewayRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudNatgatewayRule to import
    * @param importFromId The id of the existing DataIonoscloudNatgatewayRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudNatgatewayRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/natgateway_rule ionoscloud_natgateway_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudNatgatewayRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudNatgatewayRuleConfig);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _natgatewayId?;
    get natgatewayId(): string;
    set natgatewayId(value: string);
    get natgatewayIdInput(): string | undefined;
    get protocol(): string;
    get publicIp(): string;
    get sourceSubnet(): string;
    private _targetPortRange;
    get targetPortRange(): DataIonoscloudNatgatewayRuleTargetPortRangeList;
    get targetSubnet(): string;
    get type(): string;
    private _timeouts;
    get timeouts(): DataIonoscloudNatgatewayRuleTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudNatgatewayRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudNatgatewayRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
