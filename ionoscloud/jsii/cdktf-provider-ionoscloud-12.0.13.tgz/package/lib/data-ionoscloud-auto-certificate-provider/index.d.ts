/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudAutoCertificateProviderConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the auto-certificate provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#id DataIonoscloudAutoCertificateProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the auto-certificate provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#location DataIonoscloudAutoCertificateProvider#location}
    */
    readonly location?: string;
    /**
    * The name of the auto-certificate provider
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#name DataIonoscloudAutoCertificateProvider#name}
    */
    readonly name?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#timeouts DataIonoscloudAutoCertificateProvider#timeouts}
    */
    readonly timeouts?: DataIonoscloudAutoCertificateProviderTimeouts;
}
export interface DataIonoscloudAutoCertificateProviderExternalAccountBinding {
}
export declare function dataIonoscloudAutoCertificateProviderExternalAccountBindingToTerraform(struct?: DataIonoscloudAutoCertificateProviderExternalAccountBinding): any;
export declare function dataIonoscloudAutoCertificateProviderExternalAccountBindingToHclTerraform(struct?: DataIonoscloudAutoCertificateProviderExternalAccountBinding): any;
export declare class DataIonoscloudAutoCertificateProviderExternalAccountBindingOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudAutoCertificateProviderExternalAccountBinding | undefined;
    set internalValue(value: DataIonoscloudAutoCertificateProviderExternalAccountBinding | undefined);
    get keyId(): string;
}
export declare class DataIonoscloudAutoCertificateProviderExternalAccountBindingList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudAutoCertificateProviderExternalAccountBindingOutputReference;
}
export interface DataIonoscloudAutoCertificateProviderTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#create DataIonoscloudAutoCertificateProvider#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#default DataIonoscloudAutoCertificateProvider#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#delete DataIonoscloudAutoCertificateProvider#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#update DataIonoscloudAutoCertificateProvider#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudAutoCertificateProviderTimeoutsToTerraform(struct?: DataIonoscloudAutoCertificateProviderTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudAutoCertificateProviderTimeoutsToHclTerraform(struct?: DataIonoscloudAutoCertificateProviderTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudAutoCertificateProviderTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudAutoCertificateProviderTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudAutoCertificateProviderTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider ionoscloud_auto_certificate_provider}
*/
export declare class DataIonoscloudAutoCertificateProvider extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_auto_certificate_provider";
    /**
    * Generates CDKTF code for importing a DataIonoscloudAutoCertificateProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudAutoCertificateProvider to import
    * @param importFromId The id of the existing DataIonoscloudAutoCertificateProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudAutoCertificateProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/auto_certificate_provider ionoscloud_auto_certificate_provider} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudAutoCertificateProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudAutoCertificateProviderConfig);
    get email(): string;
    private _externalAccountBinding;
    get externalAccountBinding(): DataIonoscloudAutoCertificateProviderExternalAccountBindingList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get server(): string;
    private _timeouts;
    get timeouts(): DataIonoscloudAutoCertificateProviderTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudAutoCertificateProviderTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudAutoCertificateProviderTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
