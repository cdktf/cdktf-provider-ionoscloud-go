/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudLoggingPipelineConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Logging pipeline
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/logging_pipeline#id DataIonoscloudLoggingPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of your logging pipeline. Default: de/txl. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/lhr, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/logging_pipeline#location DataIonoscloudLoggingPipeline#location}
    */
    readonly location?: string;
    /**
    * The name of the Logging pipeline
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/logging_pipeline#name DataIonoscloudLoggingPipeline#name}
    */
    readonly name?: string;
}
export interface DataIonoscloudLoggingPipelineLogDestinations {
}
export declare function dataIonoscloudLoggingPipelineLogDestinationsToTerraform(struct?: DataIonoscloudLoggingPipelineLogDestinations): any;
export declare function dataIonoscloudLoggingPipelineLogDestinationsToHclTerraform(struct?: DataIonoscloudLoggingPipelineLogDestinations): any;
export declare class DataIonoscloudLoggingPipelineLogDestinationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudLoggingPipelineLogDestinations | undefined;
    set internalValue(value: DataIonoscloudLoggingPipelineLogDestinations | undefined);
    get retentionInDays(): number;
    get type(): string;
}
export declare class DataIonoscloudLoggingPipelineLogDestinationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudLoggingPipelineLogDestinationsOutputReference;
}
export interface DataIonoscloudLoggingPipelineLog {
}
export declare function dataIonoscloudLoggingPipelineLogToTerraform(struct?: DataIonoscloudLoggingPipelineLog): any;
export declare function dataIonoscloudLoggingPipelineLogToHclTerraform(struct?: DataIonoscloudLoggingPipelineLog): any;
export declare class DataIonoscloudLoggingPipelineLogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudLoggingPipelineLog | undefined;
    set internalValue(value: DataIonoscloudLoggingPipelineLog | undefined);
    private _destinations;
    get destinations(): DataIonoscloudLoggingPipelineLogDestinationsList;
    get protocol(): string;
    get public(): cdktf.IResolvable;
    get source(): string;
    get tag(): string;
}
export declare class DataIonoscloudLoggingPipelineLogList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudLoggingPipelineLogOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/logging_pipeline ionoscloud_logging_pipeline}
*/
export declare class DataIonoscloudLoggingPipeline extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_logging_pipeline";
    /**
    * Generates CDKTF code for importing a DataIonoscloudLoggingPipeline resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudLoggingPipeline to import
    * @param importFromId The id of the existing DataIonoscloudLoggingPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/logging_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudLoggingPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/logging_pipeline ionoscloud_logging_pipeline} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudLoggingPipelineConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudLoggingPipelineConfig);
    get grafanaAddress(): string;
    get httpAddress(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _log;
    get log(): DataIonoscloudLoggingPipelineLogList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get tcpAddress(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
