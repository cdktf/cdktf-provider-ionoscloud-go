/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ContainerRegistryTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#expiry_date ContainerRegistryToken#expiry_date}
    */
    readonly expiryDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#id ContainerRegistryToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#name ContainerRegistryToken#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#registry_id ContainerRegistryToken#registry_id}
    */
    readonly registryId: string;
    /**
    * Saves password to file. Only works on create. Takes as argument a file name, or a file path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#save_password_to_file ContainerRegistryToken#save_password_to_file}
    */
    readonly savePasswordToFile?: string;
    /**
    * Can be one of enabled, disabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#status ContainerRegistryToken#status}
    */
    readonly status?: string;
    /**
    * scopes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#scopes ContainerRegistryToken#scopes}
    */
    readonly scopes?: ContainerRegistryTokenScopes[] | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#timeouts ContainerRegistryToken#timeouts}
    */
    readonly timeouts?: ContainerRegistryTokenTimeouts;
}
export interface ContainerRegistryTokenCredentials {
}
export declare function containerRegistryTokenCredentialsToTerraform(struct?: ContainerRegistryTokenCredentials): any;
export declare function containerRegistryTokenCredentialsToHclTerraform(struct?: ContainerRegistryTokenCredentials): any;
export declare class ContainerRegistryTokenCredentialsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerRegistryTokenCredentials | undefined;
    set internalValue(value: ContainerRegistryTokenCredentials | undefined);
    get password(): string;
    get username(): string;
}
export declare class ContainerRegistryTokenCredentialsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerRegistryTokenCredentialsOutputReference;
}
export interface ContainerRegistryTokenScopes {
    /**
    * Example: ["pull", "push", "delete"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#actions ContainerRegistryToken#actions}
    */
    readonly actions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#name ContainerRegistryToken#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#type ContainerRegistryToken#type}
    */
    readonly type: string;
}
export declare function containerRegistryTokenScopesToTerraform(struct?: ContainerRegistryTokenScopes | cdktf.IResolvable): any;
export declare function containerRegistryTokenScopesToHclTerraform(struct?: ContainerRegistryTokenScopes | cdktf.IResolvable): any;
export declare class ContainerRegistryTokenScopesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerRegistryTokenScopes | cdktf.IResolvable | undefined;
    set internalValue(value: ContainerRegistryTokenScopes | cdktf.IResolvable | undefined);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    get actionsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ContainerRegistryTokenScopesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ContainerRegistryTokenScopes[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerRegistryTokenScopesOutputReference;
}
export interface ContainerRegistryTokenTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#create ContainerRegistryToken#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#default ContainerRegistryToken#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#delete ContainerRegistryToken#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#update ContainerRegistryToken#update}
    */
    readonly update?: string;
}
export declare function containerRegistryTokenTimeoutsToTerraform(struct?: ContainerRegistryTokenTimeouts | cdktf.IResolvable): any;
export declare function containerRegistryTokenTimeoutsToHclTerraform(struct?: ContainerRegistryTokenTimeouts | cdktf.IResolvable): any;
export declare class ContainerRegistryTokenTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerRegistryTokenTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ContainerRegistryTokenTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token ionoscloud_container_registry_token}
*/
export declare class ContainerRegistryToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_container_registry_token";
    /**
    * Generates CDKTF code for importing a ContainerRegistryToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ContainerRegistryToken to import
    * @param importFromId The id of the existing ContainerRegistryToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ContainerRegistryToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/container_registry_token ionoscloud_container_registry_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContainerRegistryTokenConfig
    */
    constructor(scope: Construct, id: string, config: ContainerRegistryTokenConfig);
    private _credentials;
    get credentials(): ContainerRegistryTokenCredentialsList;
    private _expiryDate?;
    get expiryDate(): string;
    set expiryDate(value: string);
    resetExpiryDate(): void;
    get expiryDateInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _registryId?;
    get registryId(): string;
    set registryId(value: string);
    get registryIdInput(): string | undefined;
    private _savePasswordToFile?;
    get savePasswordToFile(): string;
    set savePasswordToFile(value: string);
    resetSavePasswordToFile(): void;
    get savePasswordToFileInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _scopes;
    get scopes(): ContainerRegistryTokenScopesList;
    putScopes(value: ContainerRegistryTokenScopes[] | cdktf.IResolvable): void;
    resetScopes(): void;
    get scopesInput(): cdktf.IResolvable | ContainerRegistryTokenScopes[] | undefined;
    private _timeouts;
    get timeouts(): ContainerRegistryTokenTimeoutsOutputReference;
    putTimeouts(value: ContainerRegistryTokenTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ContainerRegistryTokenTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
