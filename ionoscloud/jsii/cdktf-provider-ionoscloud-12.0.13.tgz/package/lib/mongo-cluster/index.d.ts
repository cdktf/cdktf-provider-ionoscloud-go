/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MongoClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The number of CPU cores per instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#cores MongoCluster#cores}
    */
    readonly cores?: number;
    /**
    * The name of your cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#display_name MongoCluster#display_name}
    */
    readonly displayName: string;
    /**
    * The cluster edition. Must be one of: playground, business, enterprise
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#edition MongoCluster#edition}
    */
    readonly edition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#id MongoCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The total number of instances in the cluster (one master and n-1 standbys). Example: 1, 3, 5, 7. For enterprise edition at least 3.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#instances MongoCluster#instances}
    */
    readonly instances: number;
    /**
    * The physical location where the cluster will be created. This will be where all of your instances live. Property cannot be modified after datacenter creation (disallowed in update requests). Available locations: de/txl, gb/lhr, es/vit. Update forces cluster re-creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#location MongoCluster#location}
    */
    readonly location: string;
    /**
    * The MongoDB version of your cluster. Downgrade is not possible and will throw an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#mongodb_version MongoCluster#mongodb_version}
    */
    readonly mongodbVersion: string;
    /**
    * The amount of memory per instance in megabytes. Multiple of 1024
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#ram MongoCluster#ram}
    */
    readonly ram?: number;
    /**
    * The total number of shards in the cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#shards MongoCluster#shards}
    */
    readonly shards?: number;
    /**
    * The amount of storage per instance in megabytes. At least 5120, at most 2097152
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#storage_size MongoCluster#storage_size}
    */
    readonly storageSize?: number;
    /**
    * The storage type. One of : HDD, SSD, SSD Standard, SSD Premium
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#storage_type MongoCluster#storage_type}
    */
    readonly storageType?: string;
    /**
    * The unique ID of the template, which specifies the number of cores, storage size, and memory. You cannot downgrade to a smaller template or minor edition (e.g. from business to playground). To get a list of all templates to confirm the changes use the /templates endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#template_id MongoCluster#template_id}
    */
    readonly templateId?: string;
    /**
    * The cluster type, either `replicaset` or `sharded-cluster`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#type MongoCluster#type}
    */
    readonly type?: string;
    /**
    * backup block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#backup MongoCluster#backup}
    */
    readonly backup?: MongoClusterBackup;
    /**
    * bi_connector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#bi_connector MongoCluster#bi_connector}
    */
    readonly biConnector?: MongoClusterBiConnector;
    /**
    * connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#connections MongoCluster#connections}
    */
    readonly connections: MongoClusterConnections;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#maintenance_window MongoCluster#maintenance_window}
    */
    readonly maintenanceWindow?: MongoClusterMaintenanceWindow;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#timeouts MongoCluster#timeouts}
    */
    readonly timeouts?: MongoClusterTimeouts;
}
export interface MongoClusterBackup {
    /**
    * The location where the cluster backups will be stored. If not set, the backup is stored in the nearest location of the cluster. Examples: de, eu-sounth-2, eu-central-2
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#location MongoCluster#location}
    */
    readonly location?: string;
    /**
    * Number of hours in the past for which a point-in-time snapshot can be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#point_in_time_window_hours MongoCluster#point_in_time_window_hours}
    */
    readonly pointInTimeWindowHours?: number;
    /**
    * Number of hours between snapshots.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#snapshot_interval_hours MongoCluster#snapshot_interval_hours}
    */
    readonly snapshotIntervalHours?: number;
}
export declare function mongoClusterBackupToTerraform(struct?: MongoClusterBackupOutputReference | MongoClusterBackup): any;
export declare function mongoClusterBackupToHclTerraform(struct?: MongoClusterBackupOutputReference | MongoClusterBackup): any;
export declare class MongoClusterBackupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongoClusterBackup | undefined;
    set internalValue(value: MongoClusterBackup | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _pointInTimeWindowHours?;
    get pointInTimeWindowHours(): number;
    set pointInTimeWindowHours(value: number);
    resetPointInTimeWindowHours(): void;
    get pointInTimeWindowHoursInput(): number | undefined;
    private _snapshotIntervalHours?;
    get snapshotIntervalHours(): number;
    set snapshotIntervalHours(value: number);
    resetSnapshotIntervalHours(): void;
    get snapshotIntervalHoursInput(): number | undefined;
}
export interface MongoClusterBiConnector {
    /**
    * Enable or disable the BiConnector.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#enabled MongoCluster#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
}
export declare function mongoClusterBiConnectorToTerraform(struct?: MongoClusterBiConnectorOutputReference | MongoClusterBiConnector): any;
export declare function mongoClusterBiConnectorToHclTerraform(struct?: MongoClusterBiConnectorOutputReference | MongoClusterBiConnector): any;
export declare class MongoClusterBiConnectorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongoClusterBiConnector | undefined;
    set internalValue(value: MongoClusterBiConnector | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get host(): string;
    get port(): string;
}
export interface MongoClusterConnections {
    /**
    * The list of IPs and subnet for your cluster. Note the following unavailable IP ranges:10.233.64.0/18, 10.233.0.0/18, 10.233.114.0/24. example: [192.168.1.100/24, 192.168.1.101/24]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#cidr_list MongoCluster#cidr_list}
    */
    readonly cidrList: string[];
    /**
    * The datacenter to connect your cluster to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#datacenter_id MongoCluster#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * The LAN to connect your cluster to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#lan_id MongoCluster#lan_id}
    */
    readonly lanId: string;
}
export declare function mongoClusterConnectionsToTerraform(struct?: MongoClusterConnectionsOutputReference | MongoClusterConnections): any;
export declare function mongoClusterConnectionsToHclTerraform(struct?: MongoClusterConnectionsOutputReference | MongoClusterConnections): any;
export declare class MongoClusterConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongoClusterConnections | undefined;
    set internalValue(value: MongoClusterConnections | undefined);
    private _cidrList?;
    get cidrList(): string[];
    set cidrList(value: string[]);
    get cidrListInput(): string[] | undefined;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
}
export interface MongoClusterMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#day_of_the_week MongoCluster#day_of_the_week}
    */
    readonly dayOfTheWeek: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#time MongoCluster#time}
    */
    readonly time: string;
}
export declare function mongoClusterMaintenanceWindowToTerraform(struct?: MongoClusterMaintenanceWindowOutputReference | MongoClusterMaintenanceWindow): any;
export declare function mongoClusterMaintenanceWindowToHclTerraform(struct?: MongoClusterMaintenanceWindowOutputReference | MongoClusterMaintenanceWindow): any;
export declare class MongoClusterMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongoClusterMaintenanceWindow | undefined;
    set internalValue(value: MongoClusterMaintenanceWindow | undefined);
    private _dayOfTheWeek?;
    get dayOfTheWeek(): string;
    set dayOfTheWeek(value: string);
    get dayOfTheWeekInput(): string | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
}
export interface MongoClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#create MongoCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#default MongoCluster#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#delete MongoCluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#update MongoCluster#update}
    */
    readonly update?: string;
}
export declare function mongoClusterTimeoutsToTerraform(struct?: MongoClusterTimeouts | cdktf.IResolvable): any;
export declare function mongoClusterTimeoutsToHclTerraform(struct?: MongoClusterTimeouts | cdktf.IResolvable): any;
export declare class MongoClusterTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongoClusterTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: MongoClusterTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster ionoscloud_mongo_cluster}
*/
export declare class MongoCluster extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_mongo_cluster";
    /**
    * Generates CDKTF code for importing a MongoCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MongoCluster to import
    * @param importFromId The id of the existing MongoCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MongoCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mongo_cluster ionoscloud_mongo_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MongoClusterConfig
    */
    constructor(scope: Construct, id: string, config: MongoClusterConfig);
    get connectionString(): string;
    private _cores?;
    get cores(): number;
    set cores(value: number);
    resetCores(): void;
    get coresInput(): number | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instances?;
    get instances(): number;
    set instances(value: number);
    get instancesInput(): number | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _mongodbVersion?;
    get mongodbVersion(): string;
    set mongodbVersion(value: string);
    get mongodbVersionInput(): string | undefined;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    resetRam(): void;
    get ramInput(): number | undefined;
    private _shards?;
    get shards(): number;
    set shards(value: number);
    resetShards(): void;
    get shardsInput(): number | undefined;
    private _storageSize?;
    get storageSize(): number;
    set storageSize(value: number);
    resetStorageSize(): void;
    get storageSizeInput(): number | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    resetTemplateId(): void;
    get templateIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _backup;
    get backup(): MongoClusterBackupOutputReference;
    putBackup(value: MongoClusterBackup): void;
    resetBackup(): void;
    get backupInput(): MongoClusterBackup | undefined;
    private _biConnector;
    get biConnector(): MongoClusterBiConnectorOutputReference;
    putBiConnector(value: MongoClusterBiConnector): void;
    resetBiConnector(): void;
    get biConnectorInput(): MongoClusterBiConnector | undefined;
    private _connections;
    get connections(): MongoClusterConnectionsOutputReference;
    putConnections(value: MongoClusterConnections): void;
    get connectionsInput(): MongoClusterConnections | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): MongoClusterMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: MongoClusterMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): MongoClusterMaintenanceWindow | undefined;
    private _timeouts;
    get timeouts(): MongoClusterTimeoutsOutputReference;
    putTimeouts(value: MongoClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | MongoClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
