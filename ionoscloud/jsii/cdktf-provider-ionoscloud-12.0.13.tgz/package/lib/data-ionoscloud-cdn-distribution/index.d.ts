/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudCdnDistributionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The domain of the distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#domain DataIonoscloudCdnDistribution#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#id DataIonoscloudCdnDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether partial matching is allowed or not when using domain argument.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#partial_match DataIonoscloudCdnDistribution#partial_match}
    */
    readonly partialMatch?: boolean | cdktf.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#timeouts DataIonoscloudCdnDistribution#timeouts}
    */
    readonly timeouts?: DataIonoscloudCdnDistributionTimeouts;
}
export interface DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictions {
}
export declare function dataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictionsToTerraform(struct?: DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictions): any;
export declare function dataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictionsToHclTerraform(struct?: DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictions): any;
export declare class DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictions | undefined;
    set internalValue(value: DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictions | undefined);
    get allowList(): string[];
    get blockList(): string[];
}
export declare class DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictionsOutputReference;
}
export interface DataIonoscloudCdnDistributionRoutingRulesUpstream {
}
export declare function dataIonoscloudCdnDistributionRoutingRulesUpstreamToTerraform(struct?: DataIonoscloudCdnDistributionRoutingRulesUpstream): any;
export declare function dataIonoscloudCdnDistributionRoutingRulesUpstreamToHclTerraform(struct?: DataIonoscloudCdnDistributionRoutingRulesUpstream): any;
export declare class DataIonoscloudCdnDistributionRoutingRulesUpstreamOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudCdnDistributionRoutingRulesUpstream | undefined;
    set internalValue(value: DataIonoscloudCdnDistributionRoutingRulesUpstream | undefined);
    get caching(): cdktf.IResolvable;
    private _geoRestrictions;
    get geoRestrictions(): DataIonoscloudCdnDistributionRoutingRulesUpstreamGeoRestrictionsList;
    get host(): string;
    get rateLimitClass(): string;
    get sniMode(): string;
    get waf(): cdktf.IResolvable;
}
export declare class DataIonoscloudCdnDistributionRoutingRulesUpstreamList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudCdnDistributionRoutingRulesUpstreamOutputReference;
}
export interface DataIonoscloudCdnDistributionRoutingRules {
}
export declare function dataIonoscloudCdnDistributionRoutingRulesToTerraform(struct?: DataIonoscloudCdnDistributionRoutingRules): any;
export declare function dataIonoscloudCdnDistributionRoutingRulesToHclTerraform(struct?: DataIonoscloudCdnDistributionRoutingRules): any;
export declare class DataIonoscloudCdnDistributionRoutingRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudCdnDistributionRoutingRules | undefined;
    set internalValue(value: DataIonoscloudCdnDistributionRoutingRules | undefined);
    get prefix(): string;
    get scheme(): string;
    private _upstream;
    get upstream(): DataIonoscloudCdnDistributionRoutingRulesUpstreamList;
}
export declare class DataIonoscloudCdnDistributionRoutingRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudCdnDistributionRoutingRulesOutputReference;
}
export interface DataIonoscloudCdnDistributionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#create DataIonoscloudCdnDistribution#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#default DataIonoscloudCdnDistribution#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#delete DataIonoscloudCdnDistribution#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#update DataIonoscloudCdnDistribution#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudCdnDistributionTimeoutsToTerraform(struct?: DataIonoscloudCdnDistributionTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudCdnDistributionTimeoutsToHclTerraform(struct?: DataIonoscloudCdnDistributionTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudCdnDistributionTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudCdnDistributionTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudCdnDistributionTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution ionoscloud_cdn_distribution}
*/
export declare class DataIonoscloudCdnDistribution extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_cdn_distribution";
    /**
    * Generates CDKTF code for importing a DataIonoscloudCdnDistribution resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudCdnDistribution to import
    * @param importFromId The id of the existing DataIonoscloudCdnDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudCdnDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/cdn_distribution ionoscloud_cdn_distribution} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudCdnDistributionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudCdnDistributionConfig);
    get certificateId(): string;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _partialMatch?;
    get partialMatch(): boolean | cdktf.IResolvable;
    set partialMatch(value: boolean | cdktf.IResolvable);
    resetPartialMatch(): void;
    get partialMatchInput(): boolean | cdktf.IResolvable | undefined;
    get publicEndpointV4(): string;
    get publicEndpointV6(): string;
    get resourceUrn(): string;
    private _routingRules;
    get routingRules(): DataIonoscloudCdnDistributionRoutingRulesList;
    private _timeouts;
    get timeouts(): DataIonoscloudCdnDistributionTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudCdnDistributionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudCdnDistributionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
