/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObjectStorageAccesskeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Description of the Access key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey#description ObjectStorageAccesskey#description}
    */
    readonly description?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey#timeouts ObjectStorageAccesskey#timeouts}
    */
    readonly timeouts?: ObjectStorageAccesskeyTimeouts;
}
export interface ObjectStorageAccesskeyTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey#create ObjectStorageAccesskey#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey#delete ObjectStorageAccesskey#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey#read ObjectStorageAccesskey#read}
    */
    readonly read?: string;
}
export declare function objectStorageAccesskeyTimeoutsToTerraform(struct?: ObjectStorageAccesskeyTimeouts | cdktf.IResolvable): any;
export declare function objectStorageAccesskeyTimeoutsToHclTerraform(struct?: ObjectStorageAccesskeyTimeouts | cdktf.IResolvable): any;
export declare class ObjectStorageAccesskeyTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObjectStorageAccesskeyTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ObjectStorageAccesskeyTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey ionoscloud_object_storage_accesskey}
*/
export declare class ObjectStorageAccesskey extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_object_storage_accesskey";
    /**
    * Generates CDKTF code for importing a ObjectStorageAccesskey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObjectStorageAccesskey to import
    * @param importFromId The id of the existing ObjectStorageAccesskey that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObjectStorageAccesskey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/object_storage_accesskey ionoscloud_object_storage_accesskey} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObjectStorageAccesskeyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ObjectStorageAccesskeyConfig);
    get accesskey(): string;
    get canonicalUserId(): string;
    get contractUserId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get secretkey(): string;
    private _timeouts;
    get timeouts(): ObjectStorageAccesskeyTimeoutsOutputReference;
    putTimeouts(value: ObjectStorageAccesskeyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ObjectStorageAccesskeyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
