/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpnIpsecTunnelConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network CIDRs on the "Left" side that are allowed to connect to the IPSec tunnel, i.e. the CIDRs within your IONOS Cloud LAN. Specify "0.0.0.0/0" or "::/0" for all addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#cloud_network_cidrs VpnIpsecTunnel#cloud_network_cidrs}
    */
    readonly cloudNetworkCidrs: string[];
    /**
    * The human-readable description of your IPSec Gateway Tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#description VpnIpsecTunnel#description}
    */
    readonly description?: string;
    /**
    * The ID of the IPSec Gateway that the tunnel belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#gateway_id VpnIpsecTunnel#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#id VpnIpsecTunnel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the IPSec Gateway Tunnel. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/bhx, gb/lhr, us/ewr, us/las, us/mci, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#location VpnIpsecTunnel#location}
    */
    readonly location?: string;
    /**
    * The human-readable name of your IPSec Gateway Tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#name VpnIpsecTunnel#name}
    */
    readonly name: string;
    /**
    * The network CIDRs on the "Right" side that are allowed to connect to the IPSec tunnel. Specify "0.0.0.0/0" or "::/0" for all addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#peer_network_cidrs VpnIpsecTunnel#peer_network_cidrs}
    */
    readonly peerNetworkCidrs: string[];
    /**
    * The remote peer host fully qualified domain name or public IPV4 IP to connect to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#remote_host VpnIpsecTunnel#remote_host}
    */
    readonly remoteHost: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#auth VpnIpsecTunnel#auth}
    */
    readonly auth: VpnIpsecTunnelAuth;
    /**
    * esp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#esp VpnIpsecTunnel#esp}
    */
    readonly esp: VpnIpsecTunnelEsp[] | cdktf.IResolvable;
    /**
    * ike block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#ike VpnIpsecTunnel#ike}
    */
    readonly ike: VpnIpsecTunnelIke;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#timeouts VpnIpsecTunnel#timeouts}
    */
    readonly timeouts?: VpnIpsecTunnelTimeouts;
}
export interface VpnIpsecTunnelAuth {
    /**
    * The Authentication Method to use for IPSec Authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#method VpnIpsecTunnel#method}
    */
    readonly method?: string;
    /**
    * The Pre-Shared Key to use for IPSec Authentication. Note: Required if method is PSK.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#psk_key VpnIpsecTunnel#psk_key}
    */
    readonly pskKey?: string;
}
export declare function vpnIpsecTunnelAuthToTerraform(struct?: VpnIpsecTunnelAuthOutputReference | VpnIpsecTunnelAuth): any;
export declare function vpnIpsecTunnelAuthToHclTerraform(struct?: VpnIpsecTunnelAuthOutputReference | VpnIpsecTunnelAuth): any;
export declare class VpnIpsecTunnelAuthOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnIpsecTunnelAuth | undefined;
    set internalValue(value: VpnIpsecTunnelAuth | undefined);
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _pskKey?;
    get pskKey(): string;
    set pskKey(value: string);
    resetPskKey(): void;
    get pskKeyInput(): string | undefined;
}
export interface VpnIpsecTunnelEsp {
    /**
    * The Diffie-Hellman Group to use for IPSec Encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#diffie_hellman_group VpnIpsecTunnel#diffie_hellman_group}
    */
    readonly diffieHellmanGroup?: string;
    /**
    * The encryption algorithm to use for IPSec Encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#encryption_algorithm VpnIpsecTunnel#encryption_algorithm}
    */
    readonly encryptionAlgorithm?: string;
    /**
    * The integrity algorithm to use for IPSec Encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#integrity_algorithm VpnIpsecTunnel#integrity_algorithm}
    */
    readonly integrityAlgorithm?: string;
    /**
    * The phase lifetime in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#lifetime VpnIpsecTunnel#lifetime}
    */
    readonly lifetime?: number;
}
export declare function vpnIpsecTunnelEspToTerraform(struct?: VpnIpsecTunnelEsp | cdktf.IResolvable): any;
export declare function vpnIpsecTunnelEspToHclTerraform(struct?: VpnIpsecTunnelEsp | cdktf.IResolvable): any;
export declare class VpnIpsecTunnelEspOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpnIpsecTunnelEsp | cdktf.IResolvable | undefined;
    set internalValue(value: VpnIpsecTunnelEsp | cdktf.IResolvable | undefined);
    private _diffieHellmanGroup?;
    get diffieHellmanGroup(): string;
    set diffieHellmanGroup(value: string);
    resetDiffieHellmanGroup(): void;
    get diffieHellmanGroupInput(): string | undefined;
    private _encryptionAlgorithm?;
    get encryptionAlgorithm(): string;
    set encryptionAlgorithm(value: string);
    resetEncryptionAlgorithm(): void;
    get encryptionAlgorithmInput(): string | undefined;
    private _integrityAlgorithm?;
    get integrityAlgorithm(): string;
    set integrityAlgorithm(value: string);
    resetIntegrityAlgorithm(): void;
    get integrityAlgorithmInput(): string | undefined;
    private _lifetime?;
    get lifetime(): number;
    set lifetime(value: number);
    resetLifetime(): void;
    get lifetimeInput(): number | undefined;
}
export declare class VpnIpsecTunnelEspList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VpnIpsecTunnelEsp[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpnIpsecTunnelEspOutputReference;
}
export interface VpnIpsecTunnelIke {
    /**
    * The Diffie-Hellman Group to use for IPSec Encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#diffie_hellman_group VpnIpsecTunnel#diffie_hellman_group}
    */
    readonly diffieHellmanGroup?: string;
    /**
    * The encryption algorithm to use for IPSec Encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#encryption_algorithm VpnIpsecTunnel#encryption_algorithm}
    */
    readonly encryptionAlgorithm?: string;
    /**
    * The integrity algorithm to use for IPSec Encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#integrity_algorithm VpnIpsecTunnel#integrity_algorithm}
    */
    readonly integrityAlgorithm?: string;
    /**
    * The phase lifetime in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#lifetime VpnIpsecTunnel#lifetime}
    */
    readonly lifetime?: number;
}
export declare function vpnIpsecTunnelIkeToTerraform(struct?: VpnIpsecTunnelIkeOutputReference | VpnIpsecTunnelIke): any;
export declare function vpnIpsecTunnelIkeToHclTerraform(struct?: VpnIpsecTunnelIkeOutputReference | VpnIpsecTunnelIke): any;
export declare class VpnIpsecTunnelIkeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnIpsecTunnelIke | undefined;
    set internalValue(value: VpnIpsecTunnelIke | undefined);
    private _diffieHellmanGroup?;
    get diffieHellmanGroup(): string;
    set diffieHellmanGroup(value: string);
    resetDiffieHellmanGroup(): void;
    get diffieHellmanGroupInput(): string | undefined;
    private _encryptionAlgorithm?;
    get encryptionAlgorithm(): string;
    set encryptionAlgorithm(value: string);
    resetEncryptionAlgorithm(): void;
    get encryptionAlgorithmInput(): string | undefined;
    private _integrityAlgorithm?;
    get integrityAlgorithm(): string;
    set integrityAlgorithm(value: string);
    resetIntegrityAlgorithm(): void;
    get integrityAlgorithmInput(): string | undefined;
    private _lifetime?;
    get lifetime(): number;
    set lifetime(value: number);
    resetLifetime(): void;
    get lifetimeInput(): number | undefined;
}
export interface VpnIpsecTunnelTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#create VpnIpsecTunnel#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#default VpnIpsecTunnel#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#delete VpnIpsecTunnel#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#update VpnIpsecTunnel#update}
    */
    readonly update?: string;
}
export declare function vpnIpsecTunnelTimeoutsToTerraform(struct?: VpnIpsecTunnelTimeouts | cdktf.IResolvable): any;
export declare function vpnIpsecTunnelTimeoutsToHclTerraform(struct?: VpnIpsecTunnelTimeouts | cdktf.IResolvable): any;
export declare class VpnIpsecTunnelTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnIpsecTunnelTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VpnIpsecTunnelTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel ionoscloud_vpn_ipsec_tunnel}
*/
export declare class VpnIpsecTunnel extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_vpn_ipsec_tunnel";
    /**
    * Generates CDKTF code for importing a VpnIpsecTunnel resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpnIpsecTunnel to import
    * @param importFromId The id of the existing VpnIpsecTunnel that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpnIpsecTunnel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_tunnel ionoscloud_vpn_ipsec_tunnel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpnIpsecTunnelConfig
    */
    constructor(scope: Construct, id: string, config: VpnIpsecTunnelConfig);
    private _cloudNetworkCidrs?;
    get cloudNetworkCidrs(): string[];
    set cloudNetworkCidrs(value: string[]);
    get cloudNetworkCidrsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _peerNetworkCidrs?;
    get peerNetworkCidrs(): string[];
    set peerNetworkCidrs(value: string[]);
    get peerNetworkCidrsInput(): string[] | undefined;
    private _remoteHost?;
    get remoteHost(): string;
    set remoteHost(value: string);
    get remoteHostInput(): string | undefined;
    private _auth;
    get auth(): VpnIpsecTunnelAuthOutputReference;
    putAuth(value: VpnIpsecTunnelAuth): void;
    get authInput(): VpnIpsecTunnelAuth | undefined;
    private _esp;
    get esp(): VpnIpsecTunnelEspList;
    putEsp(value: VpnIpsecTunnelEsp[] | cdktf.IResolvable): void;
    get espInput(): cdktf.IResolvable | VpnIpsecTunnelEsp[] | undefined;
    private _ike;
    get ike(): VpnIpsecTunnelIkeOutputReference;
    putIke(value: VpnIpsecTunnelIke): void;
    get ikeInput(): VpnIpsecTunnelIke | undefined;
    private _timeouts;
    get timeouts(): VpnIpsecTunnelTimeoutsOutputReference;
    putTimeouts(value: VpnIpsecTunnelTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VpnIpsecTunnelTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
