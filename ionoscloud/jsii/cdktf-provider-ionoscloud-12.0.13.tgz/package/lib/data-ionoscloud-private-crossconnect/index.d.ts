/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudPrivateCrossconnectConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#description DataIonoscloudPrivateCrossconnect#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#id DataIonoscloudPrivateCrossconnect#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#name DataIonoscloudPrivateCrossconnect#name}
    */
    readonly name?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#timeouts DataIonoscloudPrivateCrossconnect#timeouts}
    */
    readonly timeouts?: DataIonoscloudPrivateCrossconnectTimeouts;
}
export interface DataIonoscloudPrivateCrossconnectConnectableDatacenters {
}
export declare function dataIonoscloudPrivateCrossconnectConnectableDatacentersToTerraform(struct?: DataIonoscloudPrivateCrossconnectConnectableDatacenters): any;
export declare function dataIonoscloudPrivateCrossconnectConnectableDatacentersToHclTerraform(struct?: DataIonoscloudPrivateCrossconnectConnectableDatacenters): any;
export declare class DataIonoscloudPrivateCrossconnectConnectableDatacentersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudPrivateCrossconnectConnectableDatacenters | undefined;
    set internalValue(value: DataIonoscloudPrivateCrossconnectConnectableDatacenters | undefined);
    get id(): string;
    get location(): string;
    get name(): string;
}
export declare class DataIonoscloudPrivateCrossconnectConnectableDatacentersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudPrivateCrossconnectConnectableDatacentersOutputReference;
}
export interface DataIonoscloudPrivateCrossconnectPeers {
}
export declare function dataIonoscloudPrivateCrossconnectPeersToTerraform(struct?: DataIonoscloudPrivateCrossconnectPeers): any;
export declare function dataIonoscloudPrivateCrossconnectPeersToHclTerraform(struct?: DataIonoscloudPrivateCrossconnectPeers): any;
export declare class DataIonoscloudPrivateCrossconnectPeersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudPrivateCrossconnectPeers | undefined;
    set internalValue(value: DataIonoscloudPrivateCrossconnectPeers | undefined);
    get datacenterId(): string;
    get datacenterName(): string;
    get lanId(): string;
    get lanName(): string;
    get location(): string;
}
export declare class DataIonoscloudPrivateCrossconnectPeersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudPrivateCrossconnectPeersOutputReference;
}
export interface DataIonoscloudPrivateCrossconnectTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#create DataIonoscloudPrivateCrossconnect#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#default DataIonoscloudPrivateCrossconnect#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#delete DataIonoscloudPrivateCrossconnect#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#update DataIonoscloudPrivateCrossconnect#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudPrivateCrossconnectTimeoutsToTerraform(struct?: DataIonoscloudPrivateCrossconnectTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudPrivateCrossconnectTimeoutsToHclTerraform(struct?: DataIonoscloudPrivateCrossconnectTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudPrivateCrossconnectTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudPrivateCrossconnectTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudPrivateCrossconnectTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect ionoscloud_private_crossconnect}
*/
export declare class DataIonoscloudPrivateCrossconnect extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_private_crossconnect";
    /**
    * Generates CDKTF code for importing a DataIonoscloudPrivateCrossconnect resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudPrivateCrossconnect to import
    * @param importFromId The id of the existing DataIonoscloudPrivateCrossconnect that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudPrivateCrossconnect to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/private_crossconnect ionoscloud_private_crossconnect} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudPrivateCrossconnectConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudPrivateCrossconnectConfig);
    private _connectableDatacenters;
    get connectableDatacenters(): DataIonoscloudPrivateCrossconnectConnectableDatacentersList;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _peers;
    get peers(): DataIonoscloudPrivateCrossconnectPeersList;
    private _timeouts;
    get timeouts(): DataIonoscloudPrivateCrossconnectTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudPrivateCrossconnectTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudPrivateCrossconnectTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
