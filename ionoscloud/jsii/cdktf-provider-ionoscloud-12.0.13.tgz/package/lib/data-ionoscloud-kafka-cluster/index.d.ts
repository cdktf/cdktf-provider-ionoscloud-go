/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudKafkaClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Kafka Cluster
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/kafka_cluster#id DataIonoscloudKafkaCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of your Kafka Cluster. Supported locations: de/fra, de/fra/2, de/txl, fr/par, es/vit, gb/lhr, gb/bhx, us/las, us/mci, us/ewr
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/kafka_cluster#location DataIonoscloudKafkaCluster#location}
    */
    readonly location: string;
    /**
    * The name of the Kafka Cluster
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/kafka_cluster#name DataIonoscloudKafkaCluster#name}
    */
    readonly name?: string;
    /**
    * Whether partial matching is allowed or not when using the name filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/kafka_cluster#partial_match DataIonoscloudKafkaCluster#partial_match}
    */
    readonly partialMatch?: boolean | cdktf.IResolvable;
}
export interface DataIonoscloudKafkaClusterConnections {
}
export declare function dataIonoscloudKafkaClusterConnectionsToTerraform(struct?: DataIonoscloudKafkaClusterConnections): any;
export declare function dataIonoscloudKafkaClusterConnectionsToHclTerraform(struct?: DataIonoscloudKafkaClusterConnections): any;
export declare class DataIonoscloudKafkaClusterConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudKafkaClusterConnections | undefined;
    set internalValue(value: DataIonoscloudKafkaClusterConnections | undefined);
    get brokerAddresses(): string[];
    get datacenterId(): string;
    get lanId(): string;
}
export declare class DataIonoscloudKafkaClusterConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudKafkaClusterConnectionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/kafka_cluster ionoscloud_kafka_cluster}
*/
export declare class DataIonoscloudKafkaCluster extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_kafka_cluster";
    /**
    * Generates CDKTF code for importing a DataIonoscloudKafkaCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudKafkaCluster to import
    * @param importFromId The id of the existing DataIonoscloudKafkaCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/kafka_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudKafkaCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/kafka_cluster ionoscloud_kafka_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudKafkaClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudKafkaClusterConfig);
    get brokerAddresses(): string[];
    private _connections;
    get connections(): DataIonoscloudKafkaClusterConnectionsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _partialMatch?;
    get partialMatch(): boolean | cdktf.IResolvable;
    set partialMatch(value: boolean | cdktf.IResolvable);
    resetPartialMatch(): void;
    get partialMatchInput(): boolean | cdktf.IResolvable | undefined;
    get size(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
