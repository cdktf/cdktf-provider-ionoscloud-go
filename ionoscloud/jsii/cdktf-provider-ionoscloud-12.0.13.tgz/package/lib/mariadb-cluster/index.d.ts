/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MariadbClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The number of CPU cores per instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#cores MariadbCluster#cores}
    */
    readonly cores: number;
    /**
    * The friendly name of your cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#display_name MariadbCluster#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#id MariadbCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The total number of instances in the cluster (one primary and n-1 secondary).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#instances MariadbCluster#instances}
    */
    readonly instances: number;
    /**
    * The cluster location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#location MariadbCluster#location}
    */
    readonly location?: string;
    /**
    * The MariaDB version of your cluster. Cannot be downgraded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#mariadb_version MariadbCluster#mariadb_version}
    */
    readonly mariadbVersion: string;
    /**
    * The amount of memory per instance in gigabytes (GB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#ram MariadbCluster#ram}
    */
    readonly ram: number;
    /**
    * The amount of storage per instance in gigabytes (GB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#storage_size MariadbCluster#storage_size}
    */
    readonly storageSize: number;
    /**
    * backup block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#backup MariadbCluster#backup}
    */
    readonly backup?: MariadbClusterBackup;
    /**
    * connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#connections MariadbCluster#connections}
    */
    readonly connections: MariadbClusterConnections;
    /**
    * credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#credentials MariadbCluster#credentials}
    */
    readonly credentials: MariadbClusterCredentials;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#maintenance_window MariadbCluster#maintenance_window}
    */
    readonly maintenanceWindow?: MariadbClusterMaintenanceWindow;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#timeouts MariadbCluster#timeouts}
    */
    readonly timeouts?: MariadbClusterTimeouts;
}
export interface MariadbClusterBackup {
    /**
    * The IONOS Object Storage location where the backups will be stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#location MariadbCluster#location}
    */
    readonly location: string;
}
export declare function mariadbClusterBackupToTerraform(struct?: MariadbClusterBackupOutputReference | MariadbClusterBackup): any;
export declare function mariadbClusterBackupToHclTerraform(struct?: MariadbClusterBackupOutputReference | MariadbClusterBackup): any;
export declare class MariadbClusterBackupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MariadbClusterBackup | undefined;
    set internalValue(value: MariadbClusterBackup | undefined);
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
}
export interface MariadbClusterConnections {
    /**
    * The IP and subnet for your cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#cidr MariadbCluster#cidr}
    */
    readonly cidr: string;
    /**
    * The datacenter to connect your cluster to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#datacenter_id MariadbCluster#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * The numeric LAN ID to connect your cluster to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#lan_id MariadbCluster#lan_id}
    */
    readonly lanId: string;
}
export declare function mariadbClusterConnectionsToTerraform(struct?: MariadbClusterConnectionsOutputReference | MariadbClusterConnections): any;
export declare function mariadbClusterConnectionsToHclTerraform(struct?: MariadbClusterConnectionsOutputReference | MariadbClusterConnections): any;
export declare class MariadbClusterConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MariadbClusterConnections | undefined;
    set internalValue(value: MariadbClusterConnections | undefined);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    get cidrInput(): string | undefined;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
}
export interface MariadbClusterCredentials {
    /**
    * The password for a MariaDB user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#password MariadbCluster#password}
    */
    readonly password: string;
    /**
    * The username for the initial MariaDB user. Some system usernames are restricted (e.g 'mariadb', 'admin', 'standby').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#username MariadbCluster#username}
    */
    readonly username: string;
}
export declare function mariadbClusterCredentialsToTerraform(struct?: MariadbClusterCredentialsOutputReference | MariadbClusterCredentials): any;
export declare function mariadbClusterCredentialsToHclTerraform(struct?: MariadbClusterCredentialsOutputReference | MariadbClusterCredentials): any;
export declare class MariadbClusterCredentialsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MariadbClusterCredentials | undefined;
    set internalValue(value: MariadbClusterCredentials | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface MariadbClusterMaintenanceWindow {
    /**
    * The name of the week day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#day_of_the_week MariadbCluster#day_of_the_week}
    */
    readonly dayOfTheWeek: string;
    /**
    * Start of the maintenance window in UTC time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#time MariadbCluster#time}
    */
    readonly time: string;
}
export declare function mariadbClusterMaintenanceWindowToTerraform(struct?: MariadbClusterMaintenanceWindowOutputReference | MariadbClusterMaintenanceWindow): any;
export declare function mariadbClusterMaintenanceWindowToHclTerraform(struct?: MariadbClusterMaintenanceWindowOutputReference | MariadbClusterMaintenanceWindow): any;
export declare class MariadbClusterMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MariadbClusterMaintenanceWindow | undefined;
    set internalValue(value: MariadbClusterMaintenanceWindow | undefined);
    private _dayOfTheWeek?;
    get dayOfTheWeek(): string;
    set dayOfTheWeek(value: string);
    get dayOfTheWeekInput(): string | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
}
export interface MariadbClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#create MariadbCluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#default MariadbCluster#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#delete MariadbCluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#update MariadbCluster#update}
    */
    readonly update?: string;
}
export declare function mariadbClusterTimeoutsToTerraform(struct?: MariadbClusterTimeouts | cdktf.IResolvable): any;
export declare function mariadbClusterTimeoutsToHclTerraform(struct?: MariadbClusterTimeouts | cdktf.IResolvable): any;
export declare class MariadbClusterTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MariadbClusterTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: MariadbClusterTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster ionoscloud_mariadb_cluster}
*/
export declare class MariadbCluster extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_mariadb_cluster";
    /**
    * Generates CDKTF code for importing a MariadbCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MariadbCluster to import
    * @param importFromId The id of the existing MariadbCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MariadbCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/mariadb_cluster ionoscloud_mariadb_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MariadbClusterConfig
    */
    constructor(scope: Construct, id: string, config: MariadbClusterConfig);
    private _cores?;
    get cores(): number;
    set cores(value: number);
    get coresInput(): number | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get dnsName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instances?;
    get instances(): number;
    set instances(value: number);
    get instancesInput(): number | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _mariadbVersion?;
    get mariadbVersion(): string;
    set mariadbVersion(value: string);
    get mariadbVersionInput(): string | undefined;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    get ramInput(): number | undefined;
    private _storageSize?;
    get storageSize(): number;
    set storageSize(value: number);
    get storageSizeInput(): number | undefined;
    private _backup;
    get backup(): MariadbClusterBackupOutputReference;
    putBackup(value: MariadbClusterBackup): void;
    resetBackup(): void;
    get backupInput(): MariadbClusterBackup | undefined;
    private _connections;
    get connections(): MariadbClusterConnectionsOutputReference;
    putConnections(value: MariadbClusterConnections): void;
    get connectionsInput(): MariadbClusterConnections | undefined;
    private _credentials;
    get credentials(): MariadbClusterCredentialsOutputReference;
    putCredentials(value: MariadbClusterCredentials): void;
    get credentialsInput(): MariadbClusterCredentials | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): MariadbClusterMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: MariadbClusterMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): MariadbClusterMaintenanceWindow | undefined;
    private _timeouts;
    get timeouts(): MariadbClusterTimeoutsOutputReference;
    putTimeouts(value: MariadbClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | MariadbClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
