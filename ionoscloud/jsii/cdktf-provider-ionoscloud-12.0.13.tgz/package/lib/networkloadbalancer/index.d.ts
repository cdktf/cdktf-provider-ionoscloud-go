/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkloadbalancerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Turn logging on and off for this product. Default value is 'false'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#central_logging Networkloadbalancer#central_logging}
    */
    readonly centralLogging?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#datacenter_id Networkloadbalancer#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#id Networkloadbalancer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Collection of IP addresses of the Network Load Balancer. (inbound and outbound) IP of the listenerLan must be a customer reserved IP for the public load balancer and private IP for the private load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#ips Networkloadbalancer#ips}
    */
    readonly ips?: string[];
    /**
    * Collection of private IP addresses with subnet mask of the Network Load Balancer. IPs must contain valid subnet mask. If user will not provide any IP then the system will generate one IP with /24 subnet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#lb_private_ips Networkloadbalancer#lb_private_ips}
    */
    readonly lbPrivateIps?: string[];
    /**
    * Id of the listening LAN. (inbound)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#listener_lan Networkloadbalancer#listener_lan}
    */
    readonly listenerLan: number;
    /**
    * Specifies the format of the logs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#logging_format Networkloadbalancer#logging_format}
    */
    readonly loggingFormat?: string;
    /**
    * A name of that Network Load Balancer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#name Networkloadbalancer#name}
    */
    readonly name: string;
    /**
    * Id of the balanced private target LAN. (outbound)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#target_lan Networkloadbalancer#target_lan}
    */
    readonly targetLan: number;
    /**
    * flowlog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#flowlog Networkloadbalancer#flowlog}
    */
    readonly flowlog?: NetworkloadbalancerFlowlog;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#timeouts Networkloadbalancer#timeouts}
    */
    readonly timeouts?: NetworkloadbalancerTimeouts;
}
export interface NetworkloadbalancerFlowlog {
    /**
    * Specifies the traffic direction pattern. Valid values: ACCEPTED, REJECTED, ALL. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#action Networkloadbalancer#action}
    */
    readonly action: string;
    /**
    * The bucket name of an existing IONOS Object Storage bucket. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#bucket Networkloadbalancer#bucket}
    */
    readonly bucket: string;
    /**
    * Specifies the traffic direction pattern. Valid values: INGRESS, EGRESS, BIDIRECTIONAL. Immutable, forces re-recreation of the nic resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#direction Networkloadbalancer#direction}
    */
    readonly direction: string;
    /**
    * The resource name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#name Networkloadbalancer#name}
    */
    readonly name: string;
}
export declare function networkloadbalancerFlowlogToTerraform(struct?: NetworkloadbalancerFlowlogOutputReference | NetworkloadbalancerFlowlog): any;
export declare function networkloadbalancerFlowlogToHclTerraform(struct?: NetworkloadbalancerFlowlogOutputReference | NetworkloadbalancerFlowlog): any;
export declare class NetworkloadbalancerFlowlogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkloadbalancerFlowlog | undefined;
    set internalValue(value: NetworkloadbalancerFlowlog | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface NetworkloadbalancerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#create Networkloadbalancer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#default Networkloadbalancer#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#delete Networkloadbalancer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#update Networkloadbalancer#update}
    */
    readonly update?: string;
}
export declare function networkloadbalancerTimeoutsToTerraform(struct?: NetworkloadbalancerTimeouts | cdktf.IResolvable): any;
export declare function networkloadbalancerTimeoutsToHclTerraform(struct?: NetworkloadbalancerTimeouts | cdktf.IResolvable): any;
export declare class NetworkloadbalancerTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkloadbalancerTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkloadbalancerTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer ionoscloud_networkloadbalancer}
*/
export declare class Networkloadbalancer extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_networkloadbalancer";
    /**
    * Generates CDKTF code for importing a Networkloadbalancer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Networkloadbalancer to import
    * @param importFromId The id of the existing Networkloadbalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Networkloadbalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/networkloadbalancer ionoscloud_networkloadbalancer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkloadbalancerConfig
    */
    constructor(scope: Construct, id: string, config: NetworkloadbalancerConfig);
    private _centralLogging?;
    get centralLogging(): boolean | cdktf.IResolvable;
    set centralLogging(value: boolean | cdktf.IResolvable);
    resetCentralLogging(): void;
    get centralLoggingInput(): boolean | cdktf.IResolvable | undefined;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ips?;
    get ips(): string[];
    set ips(value: string[]);
    resetIps(): void;
    get ipsInput(): string[] | undefined;
    private _lbPrivateIps?;
    get lbPrivateIps(): string[];
    set lbPrivateIps(value: string[]);
    resetLbPrivateIps(): void;
    get lbPrivateIpsInput(): string[] | undefined;
    private _listenerLan?;
    get listenerLan(): number;
    set listenerLan(value: number);
    get listenerLanInput(): number | undefined;
    private _loggingFormat?;
    get loggingFormat(): string;
    set loggingFormat(value: string);
    resetLoggingFormat(): void;
    get loggingFormatInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _targetLan?;
    get targetLan(): number;
    set targetLan(value: number);
    get targetLanInput(): number | undefined;
    private _flowlog;
    get flowlog(): NetworkloadbalancerFlowlogOutputReference;
    putFlowlog(value: NetworkloadbalancerFlowlog): void;
    resetFlowlog(): void;
    get flowlogInput(): NetworkloadbalancerFlowlog | undefined;
    private _timeouts;
    get timeouts(): NetworkloadbalancerTimeoutsOutputReference;
    putTimeouts(value: NetworkloadbalancerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | NetworkloadbalancerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
