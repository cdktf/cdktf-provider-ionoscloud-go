/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudVpnWireguardGatewayConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_wireguard_gateway#description DataIonoscloudVpnWireguardGateway#description}
    */
    readonly description?: string;
    /**
    * The ID of the WireGuard Gateway
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_wireguard_gateway#id DataIonoscloudVpnWireguardGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the WireGuard Gateway. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/bhx, gb/lhr, us/ewr, us/las, us/mci, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_wireguard_gateway#location DataIonoscloudVpnWireguardGateway#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_wireguard_gateway#name DataIonoscloudVpnWireguardGateway#name}
    */
    readonly name?: string;
}
export interface DataIonoscloudVpnWireguardGatewayConnections {
}
export declare function dataIonoscloudVpnWireguardGatewayConnectionsToTerraform(struct?: DataIonoscloudVpnWireguardGatewayConnections): any;
export declare function dataIonoscloudVpnWireguardGatewayConnectionsToHclTerraform(struct?: DataIonoscloudVpnWireguardGatewayConnections): any;
export declare class DataIonoscloudVpnWireguardGatewayConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudVpnWireguardGatewayConnections | undefined;
    set internalValue(value: DataIonoscloudVpnWireguardGatewayConnections | undefined);
    get datacenterId(): string;
    get ipv4Cidr(): string;
    get ipv6Cidr(): string;
    get lanId(): string;
}
export declare class DataIonoscloudVpnWireguardGatewayConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudVpnWireguardGatewayConnectionsOutputReference;
}
export interface DataIonoscloudVpnWireguardGatewayMaintenanceWindow {
}
export declare function dataIonoscloudVpnWireguardGatewayMaintenanceWindowToTerraform(struct?: DataIonoscloudVpnWireguardGatewayMaintenanceWindow): any;
export declare function dataIonoscloudVpnWireguardGatewayMaintenanceWindowToHclTerraform(struct?: DataIonoscloudVpnWireguardGatewayMaintenanceWindow): any;
export declare class DataIonoscloudVpnWireguardGatewayMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudVpnWireguardGatewayMaintenanceWindow | undefined;
    set internalValue(value: DataIonoscloudVpnWireguardGatewayMaintenanceWindow | undefined);
    get dayOfTheWeek(): string;
    get time(): string;
}
export declare class DataIonoscloudVpnWireguardGatewayMaintenanceWindowList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudVpnWireguardGatewayMaintenanceWindowOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_wireguard_gateway ionoscloud_vpn_wireguard_gateway}
*/
export declare class DataIonoscloudVpnWireguardGateway extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_vpn_wireguard_gateway";
    /**
    * Generates CDKTF code for importing a DataIonoscloudVpnWireguardGateway resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudVpnWireguardGateway to import
    * @param importFromId The id of the existing DataIonoscloudVpnWireguardGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_wireguard_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudVpnWireguardGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/vpn_wireguard_gateway ionoscloud_vpn_wireguard_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudVpnWireguardGatewayConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudVpnWireguardGatewayConfig);
    private _connections;
    get connections(): DataIonoscloudVpnWireguardGatewayConnectionsList;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get gatewayIp(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get interfaceIpv4Cidr(): string;
    get interfaceIpv6Cidr(): string;
    get listenPort(): number;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataIonoscloudVpnWireguardGatewayMaintenanceWindowList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get publicKey(): string;
    get status(): string;
    get tier(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
