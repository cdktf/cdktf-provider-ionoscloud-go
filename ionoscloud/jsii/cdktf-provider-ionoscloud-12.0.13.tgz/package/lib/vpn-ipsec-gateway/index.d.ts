/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface VpnIpsecGatewayConfig extends cdktf.TerraformMetaArguments {
    /**
    * The human-readable description of your IPSec Gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#description VpnIpsecGateway#description}
    */
    readonly description?: string;
    /**
    * Public IP address to be assigned to the gateway. Note: This must be an IP address in the same datacenter as the connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#gateway_ip VpnIpsecGateway#gateway_ip}
    */
    readonly gatewayIp: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#id VpnIpsecGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the IPSec Gateway. Supported locations: de/fra, de/fra/2, de/txl, es/vit, gb/bhx, gb/lhr, us/ewr, us/las, us/mci, fr/par
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#location VpnIpsecGateway#location}
    */
    readonly location?: string;
    /**
    * The human readable name of your IPSecGateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#name VpnIpsecGateway#name}
    */
    readonly name: string;
    /**
    * Gateway performance options. See the documentation for the available options
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#tier VpnIpsecGateway#tier}
    */
    readonly tier?: string;
    /**
    * The IKE version that is permitted for the VPN tunnels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#version VpnIpsecGateway#version}
    */
    readonly version?: string;
    /**
    * connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#connections VpnIpsecGateway#connections}
    */
    readonly connections: VpnIpsecGatewayConnections[] | cdktf.IResolvable;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#maintenance_window VpnIpsecGateway#maintenance_window}
    */
    readonly maintenanceWindow?: VpnIpsecGatewayMaintenanceWindow;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#timeouts VpnIpsecGateway#timeouts}
    */
    readonly timeouts?: VpnIpsecGatewayTimeouts;
}
export interface VpnIpsecGatewayConnections {
    /**
    * The datacenter to connect your VPN Gateway to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#datacenter_id VpnIpsecGateway#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * A LAN IPv4 address in CIDR notation that will be assigned to the VPN Gateway. This will be the private gateway address for LAN clients to route traffic over the VPN Gateway, this should be within the subnet already assigned to the LAN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#ipv4_cidr VpnIpsecGateway#ipv4_cidr}
    */
    readonly ipv4Cidr: string;
    /**
    * A LAN IPv6 address in CIDR notation that will be assigned to the VPN Gateway. This will be the private gateway address for LAN clients to route traffic over the VPN Gateway, this should be within the subnet already assigned to the LAN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#ipv6_cidr VpnIpsecGateway#ipv6_cidr}
    */
    readonly ipv6Cidr?: string;
    /**
    * The numeric LAN ID to connect your VPN Gateway to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#lan_id VpnIpsecGateway#lan_id}
    */
    readonly lanId: string;
}
export declare function vpnIpsecGatewayConnectionsToTerraform(struct?: VpnIpsecGatewayConnections | cdktf.IResolvable): any;
export declare function vpnIpsecGatewayConnectionsToHclTerraform(struct?: VpnIpsecGatewayConnections | cdktf.IResolvable): any;
export declare class VpnIpsecGatewayConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VpnIpsecGatewayConnections | cdktf.IResolvable | undefined;
    set internalValue(value: VpnIpsecGatewayConnections | cdktf.IResolvable | undefined);
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _ipv4Cidr?;
    get ipv4Cidr(): string;
    set ipv4Cidr(value: string);
    get ipv4CidrInput(): string | undefined;
    private _ipv6Cidr?;
    get ipv6Cidr(): string;
    set ipv6Cidr(value: string);
    resetIpv6Cidr(): void;
    get ipv6CidrInput(): string | undefined;
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
}
export declare class VpnIpsecGatewayConnectionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: VpnIpsecGatewayConnections[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VpnIpsecGatewayConnectionsOutputReference;
}
export interface VpnIpsecGatewayMaintenanceWindow {
    /**
    * The name of the week day
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#day_of_the_week VpnIpsecGateway#day_of_the_week}
    */
    readonly dayOfTheWeek: string;
    /**
    * Start of the maintenance window in UTC time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#time VpnIpsecGateway#time}
    */
    readonly time: string;
}
export declare function vpnIpsecGatewayMaintenanceWindowToTerraform(struct?: VpnIpsecGatewayMaintenanceWindowOutputReference | VpnIpsecGatewayMaintenanceWindow): any;
export declare function vpnIpsecGatewayMaintenanceWindowToHclTerraform(struct?: VpnIpsecGatewayMaintenanceWindowOutputReference | VpnIpsecGatewayMaintenanceWindow): any;
export declare class VpnIpsecGatewayMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnIpsecGatewayMaintenanceWindow | undefined;
    set internalValue(value: VpnIpsecGatewayMaintenanceWindow | undefined);
    private _dayOfTheWeek?;
    get dayOfTheWeek(): string;
    set dayOfTheWeek(value: string);
    get dayOfTheWeekInput(): string | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
}
export interface VpnIpsecGatewayTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#create VpnIpsecGateway#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#default VpnIpsecGateway#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#delete VpnIpsecGateway#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#update VpnIpsecGateway#update}
    */
    readonly update?: string;
}
export declare function vpnIpsecGatewayTimeoutsToTerraform(struct?: VpnIpsecGatewayTimeouts | cdktf.IResolvable): any;
export declare function vpnIpsecGatewayTimeoutsToHclTerraform(struct?: VpnIpsecGatewayTimeouts | cdktf.IResolvable): any;
export declare class VpnIpsecGatewayTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VpnIpsecGatewayTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: VpnIpsecGatewayTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway ionoscloud_vpn_ipsec_gateway}
*/
export declare class VpnIpsecGateway extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_vpn_ipsec_gateway";
    /**
    * Generates CDKTF code for importing a VpnIpsecGateway resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VpnIpsecGateway to import
    * @param importFromId The id of the existing VpnIpsecGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VpnIpsecGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/vpn_ipsec_gateway ionoscloud_vpn_ipsec_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VpnIpsecGatewayConfig
    */
    constructor(scope: Construct, id: string, config: VpnIpsecGatewayConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _gatewayIp?;
    get gatewayIp(): string;
    set gatewayIp(value: string);
    get gatewayIpInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _connections;
    get connections(): VpnIpsecGatewayConnectionsList;
    putConnections(value: VpnIpsecGatewayConnections[] | cdktf.IResolvable): void;
    get connectionsInput(): cdktf.IResolvable | VpnIpsecGatewayConnections[] | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): VpnIpsecGatewayMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: VpnIpsecGatewayMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): VpnIpsecGatewayMaintenanceWindow | undefined;
    private _timeouts;
    get timeouts(): VpnIpsecGatewayTimeoutsOutputReference;
    putTimeouts(value: VpnIpsecGatewayTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | VpnIpsecGatewayTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
