/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudInmemorydbSnapshotConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#id DataIonoscloudInmemorydbSnapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The location of the snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#location DataIonoscloudInmemorydbSnapshot#location}
    */
    readonly location: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#timeouts DataIonoscloudInmemorydbSnapshot#timeouts}
    */
    readonly timeouts?: DataIonoscloudInmemorydbSnapshotTimeouts;
}
export interface DataIonoscloudInmemorydbSnapshotMetadata {
}
export declare function dataIonoscloudInmemorydbSnapshotMetadataToTerraform(struct?: DataIonoscloudInmemorydbSnapshotMetadata): any;
export declare function dataIonoscloudInmemorydbSnapshotMetadataToHclTerraform(struct?: DataIonoscloudInmemorydbSnapshotMetadata): any;
export declare class DataIonoscloudInmemorydbSnapshotMetadataOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudInmemorydbSnapshotMetadata | undefined;
    set internalValue(value: DataIonoscloudInmemorydbSnapshotMetadata | undefined);
    get createdDate(): string;
    get datacenterId(): string;
    get lastModifiedDate(): string;
    get replicaSetId(): string;
    get snapshotTime(): string;
}
export declare class DataIonoscloudInmemorydbSnapshotMetadataList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudInmemorydbSnapshotMetadataOutputReference;
}
export interface DataIonoscloudInmemorydbSnapshotTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#create DataIonoscloudInmemorydbSnapshot#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#default DataIonoscloudInmemorydbSnapshot#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#delete DataIonoscloudInmemorydbSnapshot#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#update DataIonoscloudInmemorydbSnapshot#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudInmemorydbSnapshotTimeoutsToTerraform(struct?: DataIonoscloudInmemorydbSnapshotTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudInmemorydbSnapshotTimeoutsToHclTerraform(struct?: DataIonoscloudInmemorydbSnapshotTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudInmemorydbSnapshotTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudInmemorydbSnapshotTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudInmemorydbSnapshotTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot ionoscloud_inmemorydb_snapshot}
*/
export declare class DataIonoscloudInmemorydbSnapshot extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_inmemorydb_snapshot";
    /**
    * Generates CDKTF code for importing a DataIonoscloudInmemorydbSnapshot resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudInmemorydbSnapshot to import
    * @param importFromId The id of the existing DataIonoscloudInmemorydbSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudInmemorydbSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/inmemorydb_snapshot ionoscloud_inmemorydb_snapshot} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudInmemorydbSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudInmemorydbSnapshotConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _metadata;
    get metadata(): DataIonoscloudInmemorydbSnapshotMetadataList;
    private _timeouts;
    get timeouts(): DataIonoscloudInmemorydbSnapshotTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudInmemorydbSnapshotTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudInmemorydbSnapshotTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
