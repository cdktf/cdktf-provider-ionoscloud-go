/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface S3ObjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the bucket
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#bucket S3Object#bucket}
    */
    readonly bucket: string;
    /**
    * Can be used to specify caching behavior along the request/reply chain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#cache_control S3Object#cache_control}
    */
    readonly cacheControl?: string;
    /**
    * The utf-8 content of the object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#content S3Object#content}
    */
    readonly content?: string;
    /**
    * Specifies presentational information for the object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#content_disposition S3Object#content_disposition}
    */
    readonly contentDisposition?: string;
    /**
    * Specifies what content encodings have been applied to the object and thus what decoding mechanisms must be applied to obtain the media-type referenced by the Content-Type header field
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#content_encoding S3Object#content_encoding}
    */
    readonly contentEncoding?: string;
    /**
    * The natural language or languages of the intended audience for the object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#content_language S3Object#content_language}
    */
    readonly contentLanguage?: string;
    /**
    * A standard MIME type describing the format of the contents
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#content_type S3Object#content_type}
    */
    readonly contentType?: string;
    /**
    * The date and time at which the object is no longer cacheable
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#expires S3Object#expires}
    */
    readonly expires?: string;
    /**
    * Specifies whether to delete the object even if it has a governance-type Object Lock in place. You must explicitly pass a value of true for this parameter to delete the object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#force_destroy S3Object#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktf.IResolvable;
    /**
    * The key of the object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#key S3Object#key}
    */
    readonly key: string;
    /**
    * A map of metadata to store with the object in IONOS Object Storage Object Storage
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#metadata S3Object#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * The concatenation of the authentication device's serial number, a space, and the value that is displayed on your authentication device. Required to permanently delete a versioned object if versioning is configured with MFA Delete enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#mfa S3Object#mfa}
    */
    readonly mfa?: string;
    /**
    * Specifies whether a legal hold will be applied to this object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#object_lock_legal_hold S3Object#object_lock_legal_hold}
    */
    readonly objectLockLegalHold?: string;
    /**
    * Confirms that the requester knows that they will be charged for the request. Bucket owners need not specify this parameter in their requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#object_lock_mode S3Object#object_lock_mode}
    */
    readonly objectLockMode?: string;
    /**
    *  The date and time when you want this object's Object Lock to expire. Must be formatted as a timestamp parameter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#object_lock_retain_until_date S3Object#object_lock_retain_until_date}
    */
    readonly objectLockRetainUntilDate?: string;
    /**
    * Confirms that the requester knows that they will be charged for the request. Bucket owners need not specify this parameter in their requests.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#request_payer S3Object#request_payer}
    */
    readonly requestPayer?: string;
    /**
    * The server-side encryption algorithm used when storing this object in IONOS Object Storage Object Storage (AES256).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#server_side_encryption S3Object#server_side_encryption}
    */
    readonly serverSideEncryption?: string;
    /**
    *  Specifies the IONOS Object Storage Object Storage Encryption Context to use for object encryption. The value of this header is a base64-encoded UTF-8 string holding JSON with the encryption context key-value pairs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#server_side_encryption_context S3Object#server_side_encryption_context}
    */
    readonly serverSideEncryptionContext?: string;
    /**
    * Specifies the algorithm to use to when encrypting the object (e.g., AES256).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#server_side_encryption_customer_algorithm S3Object#server_side_encryption_customer_algorithm}
    */
    readonly serverSideEncryptionCustomerAlgorithm?: string;
    /**
    * Specifies the 256-bit, base64-encoded encryption key to use to encrypt and decrypt your data
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#server_side_encryption_customer_key S3Object#server_side_encryption_customer_key}
    */
    readonly serverSideEncryptionCustomerKey?: string;
    /**
    * Specifies the 128-bit MD5 digest of the encryption key according to RFC 1321. IONOS Object Storage Object Storage uses this header for a message integrity check  to ensure that the encryption key was transmitted without error
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#server_side_encryption_customer_key_md5 S3Object#server_side_encryption_customer_key_md5}
    */
    readonly serverSideEncryptionCustomerKeyMd5?: string;
    /**
    * The path to the file to upload
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#source S3Object#source}
    */
    readonly source?: string;
    /**
    * The storage class of the object. Valid value is 'STANDARD'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#storage_class S3Object#storage_class}
    */
    readonly storageClass?: string;
    /**
    * The tag-set for the object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#tags S3Object#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * If the bucket is configured as a website, redirects requests for this object to another object in the same bucket or to an external URL. IONOS Object Storage Object Storage stores the value of this header in the object metadata
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#website_redirect S3Object#website_redirect}
    */
    readonly websiteRedirect?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object ionoscloud_s3_object}
*/
export declare class S3Object extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_s3_object";
    /**
    * Generates CDKTF code for importing a S3Object resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the S3Object to import
    * @param importFromId The id of the existing S3Object that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the S3Object to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/s3_object ionoscloud_s3_object} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options S3ObjectConfig
    */
    constructor(scope: Construct, id: string, config: S3ObjectConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _cacheControl?;
    get cacheControl(): string;
    set cacheControl(value: string);
    resetCacheControl(): void;
    get cacheControlInput(): string | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentDisposition?;
    get contentDisposition(): string;
    set contentDisposition(value: string);
    resetContentDisposition(): void;
    get contentDispositionInput(): string | undefined;
    private _contentEncoding?;
    get contentEncoding(): string;
    set contentEncoding(value: string);
    resetContentEncoding(): void;
    get contentEncodingInput(): string | undefined;
    private _contentLanguage?;
    get contentLanguage(): string;
    set contentLanguage(value: string);
    resetContentLanguage(): void;
    get contentLanguageInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    get etag(): string;
    private _expires?;
    get expires(): string;
    set expires(value: string);
    resetExpires(): void;
    get expiresInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktf.IResolvable;
    set forceDestroy(value: boolean | cdktf.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktf.IResolvable | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _mfa?;
    get mfa(): string;
    set mfa(value: string);
    resetMfa(): void;
    get mfaInput(): string | undefined;
    private _objectLockLegalHold?;
    get objectLockLegalHold(): string;
    set objectLockLegalHold(value: string);
    resetObjectLockLegalHold(): void;
    get objectLockLegalHoldInput(): string | undefined;
    private _objectLockMode?;
    get objectLockMode(): string;
    set objectLockMode(value: string);
    resetObjectLockMode(): void;
    get objectLockModeInput(): string | undefined;
    private _objectLockRetainUntilDate?;
    get objectLockRetainUntilDate(): string;
    set objectLockRetainUntilDate(value: string);
    resetObjectLockRetainUntilDate(): void;
    get objectLockRetainUntilDateInput(): string | undefined;
    private _requestPayer?;
    get requestPayer(): string;
    set requestPayer(value: string);
    resetRequestPayer(): void;
    get requestPayerInput(): string | undefined;
    private _serverSideEncryption?;
    get serverSideEncryption(): string;
    set serverSideEncryption(value: string);
    resetServerSideEncryption(): void;
    get serverSideEncryptionInput(): string | undefined;
    private _serverSideEncryptionContext?;
    get serverSideEncryptionContext(): string;
    set serverSideEncryptionContext(value: string);
    resetServerSideEncryptionContext(): void;
    get serverSideEncryptionContextInput(): string | undefined;
    private _serverSideEncryptionCustomerAlgorithm?;
    get serverSideEncryptionCustomerAlgorithm(): string;
    set serverSideEncryptionCustomerAlgorithm(value: string);
    resetServerSideEncryptionCustomerAlgorithm(): void;
    get serverSideEncryptionCustomerAlgorithmInput(): string | undefined;
    private _serverSideEncryptionCustomerKey?;
    get serverSideEncryptionCustomerKey(): string;
    set serverSideEncryptionCustomerKey(value: string);
    resetServerSideEncryptionCustomerKey(): void;
    get serverSideEncryptionCustomerKeyInput(): string | undefined;
    private _serverSideEncryptionCustomerKeyMd5?;
    get serverSideEncryptionCustomerKeyMd5(): string;
    set serverSideEncryptionCustomerKeyMd5(value: string);
    resetServerSideEncryptionCustomerKeyMd5(): void;
    get serverSideEncryptionCustomerKeyMd5Input(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _storageClass?;
    get storageClass(): string;
    set storageClass(value: string);
    resetStorageClass(): void;
    get storageClassInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get versionId(): string;
    private _websiteRedirect?;
    get websiteRedirect(): string;
    set websiteRedirect(value: string);
    resetWebsiteRedirect(): void;
    get websiteRedirectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
