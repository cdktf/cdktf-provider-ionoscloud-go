/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerBootDeviceSelectionConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the entity to set as primary boot device. Possible boot devices are CDROM Images and Volumes. If omitted, server will boot from PXE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#boot_device_id ServerBootDeviceSelection#boot_device_id}
    */
    readonly bootDeviceId?: string;
    /**
    * ID of the Datacenter that holds the server for which the boot volume is selected
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#datacenter_id ServerBootDeviceSelection#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#id ServerBootDeviceSelection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * ID of the Server for which the boot device will be selected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#server_id ServerBootDeviceSelection#server_id}
    */
    readonly serverId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#timeouts ServerBootDeviceSelection#timeouts}
    */
    readonly timeouts?: ServerBootDeviceSelectionTimeouts;
}
export interface ServerBootDeviceSelectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#create ServerBootDeviceSelection#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#default ServerBootDeviceSelection#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#delete ServerBootDeviceSelection#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#update ServerBootDeviceSelection#update}
    */
    readonly update?: string;
}
export declare function serverBootDeviceSelectionTimeoutsToTerraform(struct?: ServerBootDeviceSelectionTimeouts | cdktf.IResolvable): any;
export declare function serverBootDeviceSelectionTimeoutsToHclTerraform(struct?: ServerBootDeviceSelectionTimeouts | cdktf.IResolvable): any;
export declare class ServerBootDeviceSelectionTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServerBootDeviceSelectionTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: ServerBootDeviceSelectionTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection ionoscloud_server_boot_device_selection}
*/
export declare class ServerBootDeviceSelection extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_server_boot_device_selection";
    /**
    * Generates CDKTF code for importing a ServerBootDeviceSelection resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerBootDeviceSelection to import
    * @param importFromId The id of the existing ServerBootDeviceSelection that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerBootDeviceSelection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/server_boot_device_selection ionoscloud_server_boot_device_selection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerBootDeviceSelectionConfig
    */
    constructor(scope: Construct, id: string, config: ServerBootDeviceSelectionConfig);
    private _bootDeviceId?;
    get bootDeviceId(): string;
    set bootDeviceId(value: string);
    resetBootDeviceId(): void;
    get bootDeviceIdInput(): string | undefined;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    get defaultBootVolumeId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ServerBootDeviceSelectionTimeoutsOutputReference;
    putTimeouts(value: ServerBootDeviceSelectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | ServerBootDeviceSelectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
