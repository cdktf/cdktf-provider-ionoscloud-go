/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudContractsConfig extends cdktf.TerraformMetaArguments {
}
export interface DataIonoscloudContractsContractsResourceLimits {
}
export declare function dataIonoscloudContractsContractsResourceLimitsToTerraform(struct?: DataIonoscloudContractsContractsResourceLimits): any;
export declare function dataIonoscloudContractsContractsResourceLimitsToHclTerraform(struct?: DataIonoscloudContractsContractsResourceLimits): any;
export declare class DataIonoscloudContractsContractsResourceLimitsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudContractsContractsResourceLimits | undefined;
    set internalValue(value: DataIonoscloudContractsContractsResourceLimits | undefined);
    get coresPerContract(): number;
    get coresPerServer(): number;
    get coresProvisioned(): number;
    get dasVolumeProvisioned(): number;
    get hddLimitPerContract(): number;
    get hddLimitPerVolume(): number;
    get hddVolumeProvisioned(): number;
    get k8SClusterLimitTotal(): number;
    get k8SClustersProvisioned(): number;
    get natGatewayLimitTotal(): number;
    get natGatewayProvisioned(): number;
    get nlbLimitTotal(): number;
    get nlbProvisioned(): number;
    get ramPerContract(): number;
    get ramPerServer(): number;
    get ramProvisioned(): number;
    get reservableIps(): number;
    get reservedIpsInUse(): number;
    get reservedIpsOnContract(): number;
    get rulesPerSecurityGroup(): number;
    get securityGroupsPerResource(): number;
    get securityGroupsPerVdc(): number;
    get ssdLimitPerContract(): number;
    get ssdLimitPerVolume(): number;
    get ssdVolumeProvisioned(): number;
}
export interface DataIonoscloudContractsContracts {
}
export declare function dataIonoscloudContractsContractsToTerraform(struct?: DataIonoscloudContractsContracts): any;
export declare function dataIonoscloudContractsContractsToHclTerraform(struct?: DataIonoscloudContractsContracts): any;
export declare class DataIonoscloudContractsContractsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudContractsContracts | undefined;
    set internalValue(value: DataIonoscloudContractsContracts | undefined);
    get contractNumber(): number;
    get owner(): string;
    get regDomain(): string;
    private _resourceLimits;
    get resourceLimits(): DataIonoscloudContractsContractsResourceLimitsOutputReference;
    get status(): string;
}
export declare class DataIonoscloudContractsContractsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudContractsContractsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/contracts ionoscloud_contracts}
*/
export declare class DataIonoscloudContracts extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_contracts";
    /**
    * Generates CDKTF code for importing a DataIonoscloudContracts resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudContracts to import
    * @param importFromId The id of the existing DataIonoscloudContracts that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/contracts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudContracts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/contracts ionoscloud_contracts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudContractsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataIonoscloudContractsConfig);
    private _contracts;
    get contracts(): DataIonoscloudContractsContractsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
