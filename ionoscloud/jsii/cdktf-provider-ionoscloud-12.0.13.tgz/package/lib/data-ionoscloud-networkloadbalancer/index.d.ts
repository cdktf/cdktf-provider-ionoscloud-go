/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataIonoscloudNetworkloadbalancerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#datacenter_id DataIonoscloudNetworkloadbalancer#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#id DataIonoscloudNetworkloadbalancer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#name DataIonoscloudNetworkloadbalancer#name}
    */
    readonly name?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#timeouts DataIonoscloudNetworkloadbalancer#timeouts}
    */
    readonly timeouts?: DataIonoscloudNetworkloadbalancerTimeouts;
}
export interface DataIonoscloudNetworkloadbalancerFlowlog {
}
export declare function dataIonoscloudNetworkloadbalancerFlowlogToTerraform(struct?: DataIonoscloudNetworkloadbalancerFlowlog): any;
export declare function dataIonoscloudNetworkloadbalancerFlowlogToHclTerraform(struct?: DataIonoscloudNetworkloadbalancerFlowlog): any;
export declare class DataIonoscloudNetworkloadbalancerFlowlogOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataIonoscloudNetworkloadbalancerFlowlog | undefined;
    set internalValue(value: DataIonoscloudNetworkloadbalancerFlowlog | undefined);
    get action(): string;
    get bucket(): string;
    get direction(): string;
    get id(): string;
    get name(): string;
}
export declare class DataIonoscloudNetworkloadbalancerFlowlogList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataIonoscloudNetworkloadbalancerFlowlogOutputReference;
}
export interface DataIonoscloudNetworkloadbalancerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#create DataIonoscloudNetworkloadbalancer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#default DataIonoscloudNetworkloadbalancer#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#delete DataIonoscloudNetworkloadbalancer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#update DataIonoscloudNetworkloadbalancer#update}
    */
    readonly update?: string;
}
export declare function dataIonoscloudNetworkloadbalancerTimeoutsToTerraform(struct?: DataIonoscloudNetworkloadbalancerTimeouts | cdktf.IResolvable): any;
export declare function dataIonoscloudNetworkloadbalancerTimeoutsToHclTerraform(struct?: DataIonoscloudNetworkloadbalancerTimeouts | cdktf.IResolvable): any;
export declare class DataIonoscloudNetworkloadbalancerTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataIonoscloudNetworkloadbalancerTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataIonoscloudNetworkloadbalancerTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer ionoscloud_networkloadbalancer}
*/
export declare class DataIonoscloudNetworkloadbalancer extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "ionoscloud_networkloadbalancer";
    /**
    * Generates CDKTF code for importing a DataIonoscloudNetworkloadbalancer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataIonoscloudNetworkloadbalancer to import
    * @param importFromId The id of the existing DataIonoscloudNetworkloadbalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataIonoscloudNetworkloadbalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/data-sources/networkloadbalancer ionoscloud_networkloadbalancer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataIonoscloudNetworkloadbalancerConfig
    */
    constructor(scope: Construct, id: string, config: DataIonoscloudNetworkloadbalancerConfig);
    get centralLogging(): cdktf.IResolvable;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _flowlog;
    get flowlog(): DataIonoscloudNetworkloadbalancerFlowlogList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ips(): string[];
    get lbPrivateIps(): string[];
    get listenerLan(): number;
    get loggingFormat(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get targetLan(): number;
    private _timeouts;
    get timeouts(): DataIonoscloudNetworkloadbalancerTimeoutsOutputReference;
    putTimeouts(value: DataIonoscloudNetworkloadbalancerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataIonoscloudNetworkloadbalancerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
