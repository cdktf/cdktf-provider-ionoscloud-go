/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface InmemorydbReplicasetConfig extends cdktf.TerraformMetaArguments {
    /**
    * The human readable name of your replica set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#display_name InmemorydbReplicaset#display_name}
    */
    readonly displayName: string;
    /**
    * The eviction policy for the replica set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#eviction_policy InmemorydbReplicaset#eviction_policy}
    */
    readonly evictionPolicy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#id InmemorydbReplicaset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of a snapshot to restore the replica set from. If set, the replica set will be created from the snapshot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#initial_snapshot_id InmemorydbReplicaset#initial_snapshot_id}
    */
    readonly initialSnapshotId?: string;
    /**
    * The replica set location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#location InmemorydbReplicaset#location}
    */
    readonly location?: string;
    /**
    * Specifies How and If data is persisted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#persistence_mode InmemorydbReplicaset#persistence_mode}
    */
    readonly persistenceMode: string;
    /**
    * The total number of replicas in the replica set (one active and n-1 passive). In case of a standalone instance, the value is 1. In all other cases, the value is > 1. The replicas will not be available as read replicas, they are only standby for a failure of the active instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#replicas InmemorydbReplicaset#replicas}
    */
    readonly replicas: number;
    /**
    * The InMemoryDB version of your replica set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#version InmemorydbReplicaset#version}
    */
    readonly version: string;
    /**
    * connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#connections InmemorydbReplicaset#connections}
    */
    readonly connections: InmemorydbReplicasetConnections;
    /**
    * credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#credentials InmemorydbReplicaset#credentials}
    */
    readonly credentials: InmemorydbReplicasetCredentials;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#maintenance_window InmemorydbReplicaset#maintenance_window}
    */
    readonly maintenanceWindow?: InmemorydbReplicasetMaintenanceWindow;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#resources InmemorydbReplicaset#resources}
    */
    readonly resources: InmemorydbReplicasetResources;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#timeouts InmemorydbReplicaset#timeouts}
    */
    readonly timeouts?: InmemorydbReplicasetTimeouts;
}
export interface InmemorydbReplicasetConnections {
    /**
    * The IP and subnet for your instance. Note the following unavailable IP ranges: 10.233.64.0/18, 10.233.0.0/18, 10.233.114.0/24
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#cidr InmemorydbReplicaset#cidr}
    */
    readonly cidr: string;
    /**
    * The datacenter to connect your instance to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#datacenter_id InmemorydbReplicaset#datacenter_id}
    */
    readonly datacenterId: string;
    /**
    * The numeric LAN ID to connect your instance to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#lan_id InmemorydbReplicaset#lan_id}
    */
    readonly lanId: string;
}
export declare function inmemorydbReplicasetConnectionsToTerraform(struct?: InmemorydbReplicasetConnectionsOutputReference | InmemorydbReplicasetConnections): any;
export declare function inmemorydbReplicasetConnectionsToHclTerraform(struct?: InmemorydbReplicasetConnectionsOutputReference | InmemorydbReplicasetConnections): any;
export declare class InmemorydbReplicasetConnectionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InmemorydbReplicasetConnections | undefined;
    set internalValue(value: InmemorydbReplicasetConnections | undefined);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    get cidrInput(): string | undefined;
    private _datacenterId?;
    get datacenterId(): string;
    set datacenterId(value: string);
    get datacenterIdInput(): string | undefined;
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
}
export interface InmemorydbReplicasetCredentialsHashedPassword {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#algorithm InmemorydbReplicaset#algorithm}
    */
    readonly algorithm: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#hash InmemorydbReplicaset#hash}
    */
    readonly hash: string;
}
export declare function inmemorydbReplicasetCredentialsHashedPasswordToTerraform(struct?: InmemorydbReplicasetCredentialsHashedPasswordOutputReference | InmemorydbReplicasetCredentialsHashedPassword): any;
export declare function inmemorydbReplicasetCredentialsHashedPasswordToHclTerraform(struct?: InmemorydbReplicasetCredentialsHashedPasswordOutputReference | InmemorydbReplicasetCredentialsHashedPassword): any;
export declare class InmemorydbReplicasetCredentialsHashedPasswordOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InmemorydbReplicasetCredentialsHashedPassword | undefined;
    set internalValue(value: InmemorydbReplicasetCredentialsHashedPassword | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    private _hash?;
    get hash(): string;
    set hash(value: string);
    get hashInput(): string | undefined;
}
export interface InmemorydbReplicasetCredentials {
    /**
    * The password for a InMemoryDB user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#plain_text_password InmemorydbReplicaset#plain_text_password}
    */
    readonly plainTextPassword?: string;
    /**
    * The username for the initial InMemoryDB user. Some system usernames are restricted (e.g. 'admin', 'standby').
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#username InmemorydbReplicaset#username}
    */
    readonly username: string;
    /**
    * hashed_password block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#hashed_password InmemorydbReplicaset#hashed_password}
    */
    readonly hashedPassword?: InmemorydbReplicasetCredentialsHashedPassword;
}
export declare function inmemorydbReplicasetCredentialsToTerraform(struct?: InmemorydbReplicasetCredentialsOutputReference | InmemorydbReplicasetCredentials): any;
export declare function inmemorydbReplicasetCredentialsToHclTerraform(struct?: InmemorydbReplicasetCredentialsOutputReference | InmemorydbReplicasetCredentials): any;
export declare class InmemorydbReplicasetCredentialsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InmemorydbReplicasetCredentials | undefined;
    set internalValue(value: InmemorydbReplicasetCredentials | undefined);
    private _plainTextPassword?;
    get plainTextPassword(): string;
    set plainTextPassword(value: string);
    resetPlainTextPassword(): void;
    get plainTextPasswordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _hashedPassword;
    get hashedPassword(): InmemorydbReplicasetCredentialsHashedPasswordOutputReference;
    putHashedPassword(value: InmemorydbReplicasetCredentialsHashedPassword): void;
    resetHashedPassword(): void;
    get hashedPasswordInput(): InmemorydbReplicasetCredentialsHashedPassword | undefined;
}
export interface InmemorydbReplicasetMaintenanceWindow {
    /**
    * The name of the week day.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#day_of_the_week InmemorydbReplicaset#day_of_the_week}
    */
    readonly dayOfTheWeek: string;
    /**
    * Start of the maintenance window in UTC time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#time InmemorydbReplicaset#time}
    */
    readonly time: string;
}
export declare function inmemorydbReplicasetMaintenanceWindowToTerraform(struct?: InmemorydbReplicasetMaintenanceWindowOutputReference | InmemorydbReplicasetMaintenanceWindow): any;
export declare function inmemorydbReplicasetMaintenanceWindowToHclTerraform(struct?: InmemorydbReplicasetMaintenanceWindowOutputReference | InmemorydbReplicasetMaintenanceWindow): any;
export declare class InmemorydbReplicasetMaintenanceWindowOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InmemorydbReplicasetMaintenanceWindow | undefined;
    set internalValue(value: InmemorydbReplicasetMaintenanceWindow | undefined);
    private _dayOfTheWeek?;
    get dayOfTheWeek(): string;
    set dayOfTheWeek(value: string);
    get dayOfTheWeekInput(): string | undefined;
    private _time?;
    get time(): string;
    set time(value: string);
    get timeInput(): string | undefined;
}
export interface InmemorydbReplicasetResources {
    /**
    * The number of CPU cores per instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#cores InmemorydbReplicaset#cores}
    */
    readonly cores: number;
    /**
    * The amount of memory per instance in gigabytes (GB).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#ram InmemorydbReplicaset#ram}
    */
    readonly ram: number;
}
export declare function inmemorydbReplicasetResourcesToTerraform(struct?: InmemorydbReplicasetResourcesOutputReference | InmemorydbReplicasetResources): any;
export declare function inmemorydbReplicasetResourcesToHclTerraform(struct?: InmemorydbReplicasetResourcesOutputReference | InmemorydbReplicasetResources): any;
export declare class InmemorydbReplicasetResourcesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InmemorydbReplicasetResources | undefined;
    set internalValue(value: InmemorydbReplicasetResources | undefined);
    private _cores?;
    get cores(): number;
    set cores(value: number);
    get coresInput(): number | undefined;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    get ramInput(): number | undefined;
    get storage(): number;
}
export interface InmemorydbReplicasetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#create InmemorydbReplicaset#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#default InmemorydbReplicaset#default}
    */
    readonly default?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#delete InmemorydbReplicaset#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#update InmemorydbReplicaset#update}
    */
    readonly update?: string;
}
export declare function inmemorydbReplicasetTimeoutsToTerraform(struct?: InmemorydbReplicasetTimeouts | cdktf.IResolvable): any;
export declare function inmemorydbReplicasetTimeoutsToHclTerraform(struct?: InmemorydbReplicasetTimeouts | cdktf.IResolvable): any;
export declare class InmemorydbReplicasetTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InmemorydbReplicasetTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: InmemorydbReplicasetTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset ionoscloud_inmemorydb_replicaset}
*/
export declare class InmemorydbReplicaset extends cdktf.TerraformResource {
    static readonly tfResourceType = "ionoscloud_inmemorydb_replicaset";
    /**
    * Generates CDKTF code for importing a InmemorydbReplicaset resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the InmemorydbReplicaset to import
    * @param importFromId The id of the existing InmemorydbReplicaset that should be imported. Refer to the {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the InmemorydbReplicaset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/ionos-cloud/ionoscloud/6.7.20/docs/resources/inmemorydb_replicaset ionoscloud_inmemorydb_replicaset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options InmemorydbReplicasetConfig
    */
    constructor(scope: Construct, id: string, config: InmemorydbReplicasetConfig);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get dnsName(): string;
    private _evictionPolicy?;
    get evictionPolicy(): string;
    set evictionPolicy(value: string);
    get evictionPolicyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialSnapshotId?;
    get initialSnapshotId(): string;
    set initialSnapshotId(value: string);
    resetInitialSnapshotId(): void;
    get initialSnapshotIdInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _persistenceMode?;
    get persistenceMode(): string;
    set persistenceMode(value: string);
    get persistenceModeInput(): string | undefined;
    private _replicas?;
    get replicas(): number;
    set replicas(value: number);
    get replicasInput(): number | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _connections;
    get connections(): InmemorydbReplicasetConnectionsOutputReference;
    putConnections(value: InmemorydbReplicasetConnections): void;
    get connectionsInput(): InmemorydbReplicasetConnections | undefined;
    private _credentials;
    get credentials(): InmemorydbReplicasetCredentialsOutputReference;
    putCredentials(value: InmemorydbReplicasetCredentials): void;
    get credentialsInput(): InmemorydbReplicasetCredentials | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): InmemorydbReplicasetMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: InmemorydbReplicasetMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): InmemorydbReplicasetMaintenanceWindow | undefined;
    private _resources;
    get resources(): InmemorydbReplicasetResourcesOutputReference;
    putResources(value: InmemorydbReplicasetResources): void;
    get resourcesInput(): InmemorydbReplicasetResources | undefined;
    private _timeouts;
    get timeouts(): InmemorydbReplicasetTimeoutsOutputReference;
    putTimeouts(value: InmemorydbReplicasetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | InmemorydbReplicasetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
